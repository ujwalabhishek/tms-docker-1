<?php

/*
  * This is the Model class for Login  
  * Author : Jaison Jose
  * Date created : 24 July 2014
  * Modified by: Mani
  */

class Login_Model extends CI_Model {
    
    public function __construct() {
        parent::__construct();        
        $this->load->helper('common');
        $this->load->library('bcrypt');
    }
        /* 
         * This method validates the user credentials and checks if the user is active
	 */
	public function check_user_valid() { 
            $user_name = $this->input->post('username');    
            $password = $this->input->post('password');
            
            $this->db->select('usr.password, usr.user_id, usr.tenant_id, usr.registered_email_id, '
                    . 'role.role_id,usr.user_name, pers.first_name, pers.last_name');
            $this->db->from('tms_users usr');
            $this->db->join('internal_user_role role', 'usr.user_id = role.user_id AND usr.tenant_id = role.tenant_id');
            $this->db->join('tms_users_pers pers', 'usr.user_id = pers.user_id AND usr.tenant_id = pers.tenant_id');
            $this->db->where('usr.user_name', $user_name);
            $this->db->where_in('usr.account_type', array('INTUSR', 'COMUSR'));
            $this->db->where('usr.account_status', 'ACTIVE');
            $result = $this->db->get()->row();
            if ($this->bcrypt->check_password($password, $result->password)) {
                unset($result->password);
                return $result;
            }
            else {
                return FALSE;
            }
        }   
    /**
     * Validate the email Id and DOB and get the username and password
     * @param type $forgot_param
     * @param type $email_id
     * @param type $dob
     * @author Bineesh M
     * @Created on: Aug 05 2014
     */     
    public function validate_forgot_pwd($forgot_param, $to_email_id, $dob, $encrypted_password, $password){   
        //for decrypting the pwd        
        $dob=formated_date($dob,'/');
        $this->db->select("usr.user_id, usr.user_name , usr.password,  pers.first_name, pers.last_name, pers.gender");
        $this->db->from("tms_users  usr, tms_users_pers pers");
        $this->db->where("usr.user_id = pers.user_id");
        $this->db->where("usr.tenant_id = pers.tenant_id");
        $this->db->where("usr.registered_email_id",$to_email_id);
        $this->db->where("pers.dob",$dob);
        $qry = $this->db->get(); 
        //echo $this->db->last_query();exit;
        if($qry->num_rows()>0){            
            if ($forgot_param =='Username'){
                $mail_subject= "Your User Name";
                $data=$qry->row('user_name');
            }else{
                $update_array=array('password'=>$encrypted_password);
                $this->db->where('user_id', $qry->row('user_id'));
                $this->db->update('tms_users',$update_array);
                $mail_subject= "Your New Password";
                $data=$password;
            }
            $mail_body =  $this->get_mail_body($data,$qry->row('first_name'),$qry->row('last_name'),$qry->row('gender'),$forgot_param);            
            //send mail
            $cc_email_id = "";
           return send_mail($to_email_id,$cc_email_id,$mail_subject,$mail_body);
            
        }else{
            return false;
        }
    }
     /**
      * This method generates the mail body for sending user name
       * @param type $user_name
      * @param type $first_name
      * @param type $last_name
      * @param type $gender
      * @author Bineesh M
      * @Created on: Aug 05 2014
      */
    private function get_mail_body($data, $first_name, $last_name, $gender,$forgot_param){ 
        
        if ($gender == 'MALE'){
            $mail_body="Dear Mr.".$first_name.' '.$last_name.',';
        }else{
             $mail_body="Dear Ms.".$first_name.' '.$last_name.',';            
        }
        $mail_body.= "<br/><br/>&nbsp;&nbsp;<strong>Your $forgot_param for TMS login is: </strong>".$data."<br/><br/>";
        $mail_body .= FORGOT_PWD_MAIL_FOOTER;             
        return $mail_body;
    }
    
    public function fetch_tenant_details($tenant_id = NULL) {
    if (empty($tenant_id)) {
        return FALSE;
    }
    $this->db->select('ten.tenant_id, ten.logo, ten.copyrighttext, ten.currency, ten.country,ten.applicationname');
    $this->db->from('tenant_master ten');
    $this->db->where('ten.tenant_id', $tenant_id);
    $this->db->limit(1);
    
    return $this->db->get()->row();
}
}   