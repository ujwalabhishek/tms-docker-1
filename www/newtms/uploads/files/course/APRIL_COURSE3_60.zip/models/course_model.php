<?php
/*
  * This is the Model class for Course
  * Author : Jaison Jose
  * Date created : 25 July 2014
  */
class Course_Model extends CI_Model {    
    /* 
     * This method gets the Active  Course list for a tenant
     * @Author: Sankar
     * @Date: Aug 12 2014
     */
    public function get_active_course_list_by_tenant($tenantId) {              
        $this->db->select('course_id, crse_name');
        $this->db->from('course');
        $this->db->where('tenant_id',$tenantId);
        $this->db->where('crse_status','ACTIVE');        
        $query = $this->db->get();        
        $tenant_active_courses = array();
        foreach($query->result() as $item) {
            $tenant_active_courses[$item->course_id] = $item->crse_name;
        }
        return $tenant_active_courses;
    }
    
    /* 
     * This method gets the Course list for a tenant
     * @Author: Jaison Jose
     */
    public function get_course_list_by_tenant($tenant_id) {              
        $this->db->select("course_id, crse_name, crse_type, class_type, language, pre_requisite, certi_level");
        $this->db->from("course");
        $this->db->where("tenant_id",$tenant_id);
        $result=$this->db->get();                
        $tenant_courses = array();
        foreach($result->result() as $item) {
            $tenant_courses[$item->course_id] = $item->crse_name;
        }
        return $tenant_courses;
    }        
    /* 
    * This method gets the internal user list for a tenant by their role
    * This method can be moved to a generic class - Course Manager and Sales Executives for 
    * the course
    * @Author: Jaison Jose
    */
    public function get_tenant_users_by_role($tenant_id, $role_id) {      
        $this->db->select("pers.user_id, pers.first_name, pers.last_name, rl.role_id");
        $this->db->from("tms_users_pers pers");
        $this->db->join("internal_user_role rl","pers.tenant_id = rl.tenant_id and pers.user_id = rl.user_id");
        $this->db->where("pers.tenant_id",$tenant_id);
        $this->db->where("rl.role_id",$role_id);
        $result=$this->db->get();            
        $tenant_users = array();
        foreach($result->result() as $item) {
            $tenant_users[$item->user_id] = $item->first_name . ' ' . $item->last_name; 
        }        
        return $tenant_users;
    }
    /*
     * For filtering the Multi select box
     * Author: Bineesh
     * Date: 12/08/2014
     */
    private function course_filter($item_array) {
        $new_array=array();
        foreach ($item_array as $item):
            if($item!='multiselect-all'){
                array_push($new_array,$item);
            }
        endforeach;
        return $new_array;
    }
    /**
      * This method creates a new course for the tenant
      * Author: Bineesh
      * Created: Aug 08 2014
      * @param type $tenantId
      * @param type $user_id
    */
    public function create_new_course_by_tenant($tenant_id,$user_id) {        
        extract($_POST);        
        $pre_requisites_value='';
        $language_value='';
        $crse_manager_value='';
        if(count($pre_requisites)>0){
            $pre_requisites=$this->course_filter($pre_requisites);
            $pre_requisites_value = implode(",",$pre_requisites);
        }        
        if(count($languages)>0){
            $languages=$this->course_filter($languages);
            $language_value = implode(",", $languages);
        }
        if(count($course_manager)>0){
            $course_manager=$this->course_filter($course_manager);
            $crse_manager_value = implode(",", $course_manager);
        }         
        // inserting into course table.    
        $data=array('tenant_id'=>$tenant_id,'crse_name'=>strtoupper($course_name),
            'pre_requisite'=>$pre_requisites_value,'language'=>$language_value,
            'crse_type'=>$course_types,'class_type'=>$class_types,
            'crse_duration'=>$course_duration,'reference_num'=>strtoupper($course_reference_num),
            'competency_code'=>strtoupper($course_competency_code),'certi_level'=>$certification_code,
            'crse_manager'=>$crse_manager_value,'description'=>$course_description,
            'crse_cert_validity'=>$validity,'display_on_portal'=>$display_in_landing_page,
            'crse_status'=>'ACTIVE','acti_date_time'=>date('Y-m-d H:i:s'),
            'created_by'=>$user_id,'created_on'=>date('Y-m-d H:i:s'),
            'gst_on_off' => $gst_rules,'subsidy_after_before' => $subsidy);                        
        $this->db->insert('course', $data);
        // inserting into course_sales_exec table.    
        $course_id = $this->db->insert_id();
        if($course_id){
            for($i=0;$i<count($sales_executives);$i++){
                $exec_data=array('tenant_id'=>$tenant_id,'course_id'=>$course_id,
                    'user_id'=>$sales_executives[$i],'commission_rate'=>$sales_exec_commission_rates[$i],
                    'status'=>'ACTIVE','acti_date_time'=>date('Y-m-d H:i:s'),
                    'assigned_on'=>date('Y-m-d H:i:s'),'assigned_by'=>$user_id);
                $this->db->insert('course_sales_exec', $exec_data); 
            }
            return TRUE;
        }else{
            return FALSE;
        }        
        /*
            INSERT INTO `course` (`tenant_id`, `course_id - PK`, `crse_name`, `pre_requisite`,
         *  `language`, `crse_type`, `class_type`, `crse_duration`, `reference_num`, `competency_code`,
         *   `certi_level`, `crse_manager`, `description`, `crse_cert_validity`, `display_on_portal`, 
         *   `crse_content_path`, `crse_icon`,`crse_statu - ACTIVE`, 
         *  `acti_date_time - Todays date and time`, `created_by - $user_id`, `created_on - todays date`, 
         *   ) 
         *  VALUES
         * ($tenantId, ''),
            Get course Id and then insert into course_sales_exec - sales executive data
         *    user_id is the id of the  sales executive selected 
         * 
         */       
        
    }
    /**
     * This method lists all the courses offered by a tenant
     * Author: Bineesh
     * Created: Aug 08 2014
     * @param string $tenant_id
     * @param int $limit
     * @param int $offset
     * @param string $sort_by
     * @param string $sort_order
     * @param string $course_name
     * @param string $course_code
     * @param string $filter_status
     * @return array
    */
    public function list_all_course_by_tenant($tenant_id, $limit = NULL, $offset = NULL, $sort_by = NULL, $sort_order = NULL,
        $course_name='',$course_code='',$filter_status='') {         
        if ($offset <= 0 || empty($tenant_id)) {
            return;
        }
        $this->db->select("course_id, crse_name, crse_manager, crse_type, class_type, certi_level, language, pre_requisite,crse_status");
        $this->db->from('course');
        $this->db->where('tenant_id',$tenant_id);
        //searching
        if($course_name!=""){
                $this->db->like('crse_name', $course_name);
        }
        if($course_code!=""){
            $this->db->where('course_id', $course_code);            
        }
        if($filter_status!="" && $filter_status != 'Select' && $filter_status != 'All' ){
            $this->db->where('crse_status', $filter_status);
        }
        //ordering
        if($sort_by) {  
            $this->db->order_by($sort_by, $sort_order);  
        }else {
            $this->db->order_by('course_id', 'DESC'); 
        }    
        if ($limit == $offset) {
            $this->db->limit($offset); 
        }
        else if($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);  
        }
        $query = $this->db->get();     
        return $query->result_array();
    }  
    /*
     * This function is used to export all the course list for a tenant displayed in the list view
     * Author : Bineesh
     * @param int $tenant_id
     * @param int $type 
     * Aug 11 2014
     */
    public function get_course_list_export($tenant_id) {
        $this->db->select("*");
        $this->db->from("course");
        $this->db->where("tenant_id",$tenant_id);
        $this->db->order_by("course_id", "desc");
        return $this->db->get();       
    }
    /*
     * This function is used to export all the internal users for a tenant displayed in the list view
     * Author : Bineesh
     * @param int $tenant_id
     * @param int $type 
     * Aug 11 2014
     */
    public function get_sales_rate_export($tenant_id) {
        $this->db->select("crse.course_id, crse.crse_name, usr.user_id, usr.first_name, usr.last_name , sales.commission_rate,sales.user_id as sales_user_id");
        $this->db->from("course crse");
        $this->db->join("course_sales_exec sales","crse.tenant_id = sales.tenant_id"
                . " AND crse.course_id = sales.course_id");
        $this->db->join("tms_users_pers usr","sales.tenant_id = usr.tenant_id"
                . " AND sales.user_id = usr.user_id");
        $this->db->where('usr.tenant_id',$tenant_id);
        $this->db->order_by('course_id', 'DESC');
        $this->db->order_by('first_name', 'ASC');
        $result = $this->db->get();
        return $result->result();
    }
   /*
    * This Method for course name search
    * Author: Bineesh
    * 11/08/2014
    */ 
    public function get_course_list($tenant_id) {
        if($tenant_id=="")
            return FALSE;
        else{
            $this->db->distinct();
            $this->db->select("crse_name");
            $this->db->from("course");
            $this->db->where("tenant_id",$tenant_id);
            $this->db->order_by("created_on","desc");
            $result = $this->db->get();            
            return $result->result();
        }    
    }
    /* 
     * This Method for getting the managers names from coma separated values
     * Author:Bineesh
     * Date:11/08/2014
     * @param char $manager_ids
     * @retun $mgr_name
     */    
    public function get_managers($manager_ids) {
        $mgr_name="";
        if($manager_ids==""){
            $mgr_name="";
        }else{
            $manager_ids_array = explode(",", $manager_ids);
            $this->db->select("first_name,last_name");
            $this->db->from("tms_users_pers");
            $this->db->where_in("user_id",$manager_ids_array);
            $result=$this->db->get()->result();                        
            foreach ($result as $row){
                $mgr_name .=$row->first_name." ".$row->last_name.', ';
            }        
        }
        return $mgr_name;
    }
    /* 
     * This Method for getting the Pre- names from coma separated values
     * Author:Bineesh
     * Date:11/08/2014
     * @param char $get_pre_requisite_id(coma separetd value)
     */    
    public function get_pre_requisite($get_pre_requisite_id) {
        $pre_requisites_name="";        
        if($get_pre_requisite_id==""){
            $pre_requisites_name="";
        }else{ 
            $get_pre_requisite_id_array = explode(",", $get_pre_requisite_id);
            $this->db->distinct();
            $this->db->select("crse_name");
            $this->db->from("course");
            $this->db->where_in('course_id', $get_pre_requisite_id_array);
            $reuslt = $this->db->get()->result();            
            foreach ($reuslt as $row){
                $pre_requisites_name .=$row->crse_name.', ';
            }        
        }
        return $pre_requisites_name;
    }    
    /* 
     * This Method for getting the coma separated values from metadata_values table.
     * Author: Bineesh
     * Date:11/08/2014
     * @param char $course_type
     */
    public function get_metadata_on_parameter_id($course_type) {                
        $category_names="";
        if($course_type==""){
            $category_names="";
        }else{
            $metaparams=explode(',',$course_type);        
            for($i=0;$i<count($metaparams);$i++){ 
                $parameter_id=trim($metaparams[$i]);
                $this->db->select("category_name");
                $this->db->from("metadata_values");
                $this->db->where("parameter_id",$parameter_id);
                $category_name = $this->db->get()->row('category_name');                
                $category_names .=$category_name.", ";                 
            }
        }
        return $category_names;        
    }
    /*
     * This MEthod for getting the total count of course for course pagination
     * Author: Bineesh
     * @param int $tenant_id
     * @param int $course_name
     * @param int $course_code
     * @param var $filter_status
     * date:11/08/2014
     */
    public function get_all_course_count_by_tenant_id($tenant_id,$course_name,$course_code,$filter_status) {
        if (empty($tenant_id)) {
            return 0;
        }
        
        $this->db->select('count(*) as totalrows');
        $this->db->from('course ');        
        $this->db->where('tenant_id', $tenant_id);
        if($course_name!=""){
            $this->db->like('crse_name', $course_name);
        }
        if($course_code!=""){
            $this->db->where('course_id', $course_code);            
        }
        if($filter_status!="" && $filter_status != 'Select' && $filter_status != 'All' ){
            $this->db->where('crse_status', $filter_status);
        }

        $result = $this->db->get()->result();

        return $result[0]->totalrows;
    }
    /*
     * This Method For getting the Course details for View Couses.
     * Author:Bineesh.
     * date:11/08/2014.
     * @param int $id.
     */
    public function get_course_detailse($id) {
        if($id!=''){
            $this->db->select('*');
            $this->db->from('course');
            $this->db->where('course_id',$id);
            $result = $this->db->get()->row();
            return $result;
        }else{
            return FALSE;
        }         
    }
    /*
     * This Method For getting the sales executive names(commition) for View Couses.
     * Author:Bineesh.
     * @param int $id.
     * date:11/08/2014.
     */
    public function get_sales_exec_detailse($course_id) {
        if($course_id!=''){
            $this->db->select('*');
            $this->db->from('course_sales_exec');
            $this->db->where('course_id',$course_id);
            $result = $this->db->get()->result();            
            if($result){
                $sales_exec_name='';                
                foreach($result as $row){
                    $sales_name=$this->get_managers($row->user_id);                                        
                    $sales_name=rtrim($sales_name,', ');
                    $sales_exec_name .=$sales_name.'('.$row->commission_rate.'%),';
                }
                $sales_exec_name=rtrim($sales_exec_name,',');                                
            }
            return $sales_exec_name;
        }else{
            return FALSE;
        }
    }
    /*
     * This Method For getting the sales executive names(commition) for View Couses.
     * Author:Bineesh.
     * @param int $course_id
     * date:11/08/2014.
     */
    public function get_sales_exec_detailse_obj($course_id) {
        if($course_id!=''){
            $this->db->select('*');
            $this->db->from('course_sales_exec');
            $this->db->where('course_id',$course_id);
            $result = $this->db->get()->result();                        
            if($result){
                $sales_exec_name=array();                                
                for($i=0;$i<count($result);$i++){
                    $sales_name=$this->get_managers($result[$i]->user_id);
                    $sales_name=rtrim($sales_name,', ');
                    $sales_exec_name[$i][0]=$sales_name;
                    $sales_exec_name[$i][1]=$result[$i]->commission_rate;                  
                    $sales_exec_name[$i][2]=$result[$i]->user_id;
                }                
                return $sales_exec_name;
            }
        }else{
            return FALSE;
        }
    }
    /*
     * This Method for course code auto complete in course list
     * Author: Bineesh
     * Date:12/08/2014
     */
    public function course_list_autocomplete($search_course_code = NULL) {
        $matches = array();        
        if (!empty($search_course_code)) {
            $user = $this->session->userdata('userDetails');
            $tenant_id = $user->tenant_id;                
            $this->db->select('course_id');
            $this->db->from('course');            
            $this->db->where('tenant_id',$tenant_id);
            $this->db->like('course_id', $search_course_code, 'both');
            $results = $this->db->get()->result();
            $i=0;
            foreach ($results as $result) {
                $matches[$i] = $result->course_id;
                $i++;
            }
        }
        return $matches;
    }
    /*
     * This Method for course name auto complete in copy course
     * Author: Bineesh
     * Date:12/08/2014
     */
    public function course_name_list_autocomplete($search_course_code = NULL) {
        $matches = array();        
        if (!empty($search_course_code)) {
            $user = $this->session->userdata('userDetails');
            $tenant_id = $user->tenant_id;
            $this->db->select('crse_name,course_id');
            $this->db->from('course');            
            $this->db->where('tenant_id',$tenant_id);
            $this->db->where_not_in('crse_status','INACTIV');
            $this->db->like('crse_name', $search_course_code, 'both');
            $results = $this->db->get()->result();
            $i=0;
            foreach ($results as $result) {
                $matches[$i] = $result->crse_name.' ('.$result->course_id.')';
                $i++;
            }
        }
        return $matches;
    }
    /*
     * This Method for course name auto complete in duplicate course
     * Author: Bineesh
     * Date:12/08/2014
     */
    public function course_name_autocomplete($search_course_code = NULL) {
        $matches = array();        
        if (!empty($search_course_code)) {
            $user = $this->session->userdata('userDetails');
            $tenant_id = $user->tenant_id;
            $this->db->select('crse_name,course_id');
            $this->db->from('course');            
            $this->db->where('tenant_id',$tenant_id);
            $this->db->where_not_in('crse_status','INACTIV');
            $this->db->like('crse_name', $search_course_code, 'both');
            $results = $this->db->get()->result();
            $i=0;
            foreach ($results as $result) {
                $matches[$i] = $result->crse_name;
                $i++;
            }
        }
        return $matches;
    }

    public function get_course_by_id($course_id) {
        $this->db->select('*');
        $this->db->from('course');
        $this->db->where('course_id', $course_id);
        $query = $this->db->get();
        $results = $query->result();
        return count($results) > 0 ? $results[0] : null;
    }
    /*
     * This function for duplicating the course
     * Author: Bineesh
     * Date:16/08/2014
     */    
    public function duplicate_course() {
        extract($_POST);
        $couse_name=  strtoupper($couse_name);
        if($reason_copy_course == 'OTHERS'){
            $reason_copy_course = $reason_copy_course.','.$other_reason_copy_course;
        }
        $course_details=$this->get_course_by_id($course_id);
        //inserting into course table.    
        if($course_details){
            $user = $this->session->userdata('userDetails');
            $tenant_id = $user->tenant_id;
            
            $course_data=array('tenant_id'=>$course_details->tenant_id, 'crse_name'=>$couse_name
                , 'crse_type'=>$course_details->crse_type, 'class_type'=>$course_details->class_type
                , 'crse_duration'=>$course_details->crse_duration, 'competency_code'=>$course_details->competency_code
                , 'reference_num'=>$course_details->reference_num, 'certi_level'=>$course_details->certi_level
                , 'description'=>$course_details->description, 'crse_cert_validity'=>$course_details->crse_cert_validity
                , 'display_on_portal'=>$course_details->display_on_portal, 'crse_content_path'=>$course_details->crse_content_path
                , 'crse_icon'=>$course_details->crse_icon, 'pre_requisite'=>$course_details->pre_requisite
                , 'language'=>$course_details->language, 'crse_manager'=>$course_details->crse_manager
                , 'crse_status'=>$course_details->crse_status, 'acti_date_time'=>$course_details->acti_date_time 
                , 'deacti_date_time'=>$course_details->deacti_date_time, 'deacti_reason'=>$course_details->deacti_reason
                , 'deacti_reason_oth'=>$course_details->deacti_reason_oth, 'deacti_by'=>$course_details->deacti_by
                , 'created_by'=>$course_details->created_by, 'created_on'=>$course_details->created_on
                , 'last_modified_by'=>$course_details->last_modified_by, 'last_modified_on'=>$course_details->last_modified_on
                , 'subsidy_after_before'=>$course_details->subsidy_after_before, 'gst_on_off'=>$course_details->gst_on_off
                , 'copy_reason'=>$reason_copy_course, 'copied_from_id'=>$course_id
                , 'copied_on'=>date('Y-m-d H:i:s'), 'copied_by'=>$user->user_id
                , 'gst_on_off' => $course_details->gst_on_off,'subsidy_after_before' => $course_details->subsidy_after_before);
            $couser_result=$this->db->insert('course', $course_data);
            $new_course_id=$this->db->insert_id();
            //inserting into course_sales_exec.
            if($couser_result){
                $this->db->select('*');
                $this->db->from('course_sales_exec');
                $this->db->where('course_id',$course_id);
                $sales_exec_result = $this->db->get()->result();                        
                if($sales_exec_result){
                    foreach ($sales_exec_result as $result) {                                            
                        $course_sales_exec_data=array('tenant_id'=>$result->tenant_id, 'course_id'=>$new_course_id
                            , 'user_id'=>$result->user_id, 'commission_rate'=>$result->commission_rate
                            , 'status'=>$result->status, 'acti_date_time'=>$result->acti_date_time
                            , 'deacti_date_time'=>$result->deacti_date_time, 'deacti_reason'=>$result->deacti_reason
                            , 'deacti_reason_oth'=>$result->deacti_reason_oth, 'deacti_by'=>$result->deacti_by
                            , 'assigned_on'=>$result->assigned_on, 'assigned_by'=>$result->assigned_by
                            , 'last_modified_by'=>$result->last_modified_by, 'last_modified_on'=>$result->last_modified_on);
                        $sales_exec_insert=$this->db->insert('`course_sales_exec', $course_sales_exec_data);
                    }
                    if($sales_exec_insert){
                        return TRUE;
                    }else{
                        return FALSE;
                    }
                }else{
                    return FALSE;
                }                
            }else{
                return FALSE;
            }
        }else{
            return FALSE;
        }
    }
    /*
     * This function will check unique couse name.
     * Author: Bineesh.
     * Date: 13/08/2014.
     */
    public function check_course_name($course_name) {
        $this->db->select('course_id');
        $this->db->from('course');
        $this->db->where('crse_name', $course_name);
        $query = $this->db->get();
        return $query->num_rows();
    }
    /**
     * This method edit a  course for the tenant
     * Author: Bineesh
     * Created: Aug 18 2014
     * @param type $tenantId
     * @param type $user_id
     */
    public function edit_course_by_tenant($tenant_id,$user_id) {
        extract($_POST); 
        if($course_id){
            $pre_requisites_value='';
            $language_value='';
            $crse_manager_value='';
            if(count($pre_requisites)>0){
                $pre_requisites=$this->course_filter($pre_requisites);
                $pre_requisites_value = implode(",",$pre_requisites);
            }        
            if(count($languages)>0){
                $languages=$this->course_filter($languages);
                $language_value = implode(",", $languages);
            }
            if(count($course_manager)>0){
                $course_manager=$this->course_filter($course_manager);
                $crse_manager_value = implode(",", $course_manager);
            }
            if($validity_period=='No'){
                $validity=0;
            }
            //updating the course table.    
            $data=array('tenant_id'=>$tenant_id,'crse_name'=>strtoupper($course_name),
                'pre_requisite'=>$pre_requisites_value,'language'=>$language_value,
                'crse_type'=>$course_types,'class_type'=>$class_types,
                'crse_duration'=>$course_duration,'reference_num'=>strtoupper($course_reference_num),
                'competency_code'=>strtoupper($course_competency_code),'certi_level'=>$certification_code,
                'crse_manager'=>$crse_manager_value,'description'=>$course_description,
                'crse_cert_validity'=>$validity,'display_on_portal'=>$display_in_landing_page,            
                'last_modified_by'=>$user_id,'last_modified_on'=>date('Y-m-d H:i:s'),
                'gst_on_off' => $gst_rules,'subsidy_after_before' => $subsidy);
            $this->db->where('tenant_id', $tenant_id);
            $this->db->where('course_id',$course_id);
            $update_result=$this->db->update('course', $data);
            // updating the course_sales_exec table.            
            if($update_result){
            // deleting from course_sales_exec table.            
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('course_id', $course_id);
                $delete_result=$this->db->delete('course_sales_exec'); 
            // inserting into course_sales_exec table.            
                if($delete_result){
                    for($i=0;$i<count($sales_executives);$i++){
                        $exec_data=array('tenant_id'=>$tenant_id,'course_id'=>$course_id,
                            'user_id'=>$sales_executives[$i],'commission_rate'=>$sales_exec_commission_rates[$i],
                            'status'=>'ACTIVE','acti_date_time'=>date('Y-m-d H:i:s'),
                            'assigned_on'=>date('Y-m-d H:i:s'),'assigned_by'=>$user_id);
                        $this->db->insert('course_sales_exec', $exec_data); 
                    }
                    return TRUE;
                }else{
                    return FALSE;
                }
            }else{
                return FALSE;
            }
        }else{
            return FALSE;
        }
    }
    /*
     * ucrine code.
     */
    public function get_sales_exec_for_course($course_id) {
        $this->db->select("up.user_id, concat(up.first_name,' ',up.last_name) as name, cse.commission_rate",FALSE);
        $this->db->from("course_sales_exec cse");
        $this->db->join("tms_users_pers up","cse.user_id=up.user_id");
        $this->db->where("cse.course_id",$course_id);
        return $this->db->get();        
    }

    public function get_classes_for_course($courseId) {
        $this->db->select("*");
        $this->db->from("course_class");
        $this->db->where("course_id",$courseId);
        return $this->db->get();
    }
    /*
     * This function deactivates the course selectd.
     * Author: Bineesh
     * Date:18/08/2014.
     */
    public function deactivate_course($course_id){
        $this->load->helper('common');
        foreach($this->input->post() as $key=>$value) {
            $$key = $value;
        }            
        if($reason_for_deactivation != 'OTHERS') {
            $other_reason_for_deactivation = '';
        }
        $user = $this->session->userdata('userDetails');        
            
        $deactivation_date=formated_date($deactivation_date,'/');
        $data = array(
        'crse_status' => 'INACTIV',
        'deacti_date_time' => $deactivation_date,
        'deacti_reason' => $reason_for_deactivation,
        'deacti_reason_oth' => $other_reason_for_deactivation,
        'deacti_by' => $user->user_id,
        );
        $this->db->where('tenant_id', $user->tenant_id);
        $this->db->where('course_id', $course_id);
        $this->db->update('course', $data);            
    }
    /*
     * This function for getting sales commission rate list count.
     * Author: Bineesh
     * Date: 19/08/2014
     */     
    public function get_sales_commission_list_count($tenant_id) {
        $this->db->select("crse.course_id, crse.crse_name, usr.user_id, usr.first_name, usr.last_name , sales.commission_rate");
        $this->db->from("course crse");
        $this->db->join("course_sales_exec sales","crse.tenant_id = sales.tenant_id"
                . " AND crse.course_id = sales.course_id");
        $this->db->join("tms_users_pers usr","sales.tenant_id = usr.tenant_id"
                . " AND sales.user_id = usr.user_id");
        $this->db->where('usr.tenant_id',$tenant_id);
        
        //searching
        if ($this->input->server('REQUEST_METHOD') === 'POST'){
            extract($_POST);
            if($course_name!="" && $sales_executives!=""){
                $this->db->where("crse.course_id",$course_name);
                $this->db->where("usr.user_id",$sales_executives);
            }else if($course_name!=""){
                $this->db->where("crse.course_id",$course_name);
            }else if($sales_executives!=""){
                $this->db->where("usr.user_id",$sales_executives);
            }            
        }
        $query = $this->db->get();       
        return $query->num_rows();
    }
    /*
     * This function for getting sales commission rate list
     * Author: Bineesh
     * Date: 19/08/2014
     */
    public function get_sales_commission_list($tenant_id,$limit = NULL, $offset = NULL, $sort_by = NULL, $sort_order = NULL) {    
        /**
         * select crse.course_id, crse.crse_name, usr.user_id, concat(usr.first_name, ' ', usr.last_name) salesexecname, sales.commission_rate
            from course crse, tms_users_pers usr, course_sales_exec sales
            where
            crse.tenant_id = sales. tenant_id and sales.tenant_id = usr.tenant_id and
            crse.course_id = sales.course_id  and
            sales.user_id = usr.user_id and
            usr.tenant_id='T01'  and crse.course_id='1' and usr.user_id=''
            order by crse.course_id,  usr.user_id
         */
        if ($offset <= 0 || empty($tenant_id)) {
            return;
        }
        $this->db->select("crse.course_id, crse.crse_name, usr.user_id, usr.first_name, usr.last_name , sales.commission_rate,sales.user_id as sales_user_id");
        $this->db->from("course crse");
        $this->db->join("course_sales_exec sales","crse.tenant_id = sales.tenant_id"
                . " AND crse.course_id = sales.course_id");
        $this->db->join("tms_users_pers usr","sales.tenant_id = usr.tenant_id"
                . " AND sales.user_id = usr.user_id");
        $this->db->where('usr.tenant_id',$tenant_id);
        
        //searching
        if ($this->input->server('REQUEST_METHOD') === 'POST'){
            extract($_POST);
            if($course_name!="" && $sales_executives!=""){
                $this->db->where("crse.course_id",$course_name);
                $this->db->where("usr.user_id",$sales_executives);
            }else if($course_name!=""){
                $this->db->where("crse.course_id",$course_name);
            }else if($sales_executives!=""){
                $this->db->where("usr.user_id",$sales_executives);
            }            
        }
        //ordering
        if($sort_by) {  
            $this->db->order_by($sort_by, $sort_order);  
        }else {
            $this->db->order_by('course_id', 'DESC'); 
        }    
        if ($limit == $offset) {
            $this->db->limit($offset); 
        }
        else if($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);  
        }
        $query = $this->db->get();
        
        return $query->result();       
    }
    /*
     * This function for updating the sales executive commition.
     * Author: Bineesh
     * Date: Aug 19 2014
     */
    public function update_sales_exec_rate($tenant_id) {
        extract($_POST);        
        if($new_sales_commition_rate!="" && $course_id!="" && $sales_exec_id!=""){
            $data=array('commission_rate'=>$new_sales_commition_rate);
            $this->db->where('course_id',$course_id);
            $this->db->where('user_id',$sales_exec_id);
            $this->db->where('tenant_id',$tenant_id);
            $result=$this->db->update('course_sales_exec',$data);            
            if($result){
                return TRUE;
            }else{
                return TRUE;
            }
        }else{
            return FALSE;
        }
    }
    /* This Function for getting the sales exec based on course_id
     * Auther: Bineesh.
     * date:Aug 19 2014.
     */
    public function get_sales_exec_detailse_array($tenant_id) {
        extract($_POST);
        if($course_id){
            $query=$this->get_sales_exec_for_course($course_id);
            $result=$query->result();            
            if($result){
                $new_sales_exec=array();
                foreach ($result as $row ){
                    $new_sales_exec[]=array('key'=>$row->user_id, 'value'=>$row->name);
                }                
                return $new_sales_exec;
            }
        }else{
            $user = $this->session->userdata('userDetails');
            $result = $this->get_tenant_users_by_role($user->tenant_id, 'SLEXEC');
            if($result){
                $new_sales_exec=array();
                foreach ($result as $key => $value ){
                    $new_sales_exec[]=array('key'=>$key, 'value'=>$value);
                }                
                return $new_sales_exec;
            }
        }
    }
    
}   
    
 
