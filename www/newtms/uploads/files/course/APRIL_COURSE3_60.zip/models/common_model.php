<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * Author: Balwant singh
 * Date: 30-7-2014
 * Use: A Model class for Common functions helper.
 */

class Common_Model extends CI_Model{
    
    
    public function fetch_compnies(){
        
      $this->db->select('cm.company_id, cm.company_name');
      $this->db->from('company_master cm');
      $this->db->join('tenant_company tc', "cm.company_id = tc.company_id and tc.comp_status='ACTIVE'");  
      $this->db->where('tc.tenant_id', $this->session->userdata('userDetails')->tenant_id);
      $query = $this->db->get();
      return $query->result_array();
    }

    public function fetch_courses(){
        
      $this->db->select('course_id, crse_name');
      $this->db->from('course');     
      $query = $this->db->get();
      $data = array();

      return $query->result_array();
    }
    
    public function fetch_classes_by_couseid($couseid){
        
      $this->db->select('class_id, class_name');
      $this->db->from('course_class');    
      $this->db->where('course_id', $couseid);
      $query = $this->db->get();

      return $query->result_array();
    }
    
    public function get_param_value($param_id){
            return $this->db->select('category_name')->where('parameter_id',$param_id)->get('metadata_values')->row();
        }
    public function get_companyname($company_id){
      $this->db->select('company_name');
      $this->db->from('company_master'); 
      $this->db->where('company_id', $company_id);
      $query = $this->db->get();
      return $query->result_array();
    }
        
}

