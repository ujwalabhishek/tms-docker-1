<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports_Model extends CI_Model
{

    /**
     * This method gets trainee feedbacks for some class
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @author Anastasiya Tarasenko
     */
    public function get_trainee_feedbacks($tenant_id, $course_id, $class_id){
        $this->db->select("distinct tf.tenant_id, tf.course_id, tf.class_id, tf.user_id, CONCAT(tup.first_name,' ',tup.last_name) as name, tu.tax_code, tu.tax_code_type, date(ce.trainee_fdbck_on) as feedback_date, IF(mv.category_name is null, null , tf.feedback_answer) as other_remarks", FALSE);
        $this->db->from('trainee_feedback tf');
        $this->db->join('metadata_values mv', "tf.feedback_question_id = mv.parameter_id and mv.parameter_id = 'OTHERREMARK'", 'left');
        $this->db->join('tms_users tu', 'tf.user_id = tu.user_id and tf.tenant_id = tu.tenant_id');
        $this->db->join('tms_users_pers tup', 'tf.user_id = tup.user_id and tf.tenant_id = tu.tenant_id');
        $this->db->join('class_enrol ce', 'tf.user_id = ce.user_id and tf.class_id = ce.class_id and tf.tenant_id = ce.tenant_id and tf.course_id = ce.course_id');

        $array = array('tf.tenant_id' => $tenant_id, 'tf.course_id' => $course_id, 'tf.class_id' => $class_id);

        $this->db->where($array);

        $query = $this->db->get();

        $result = $query->result_array();

        $grouped_by_user = array();
        foreach($result as $res){
            $user = $res['user_id'];
//            if (!isset($grouped_by_user[$user])){
//                $grouped_by_user[$user] = array();
//            }
            $grouped_by_user[$user] = $res;
        }
        return $grouped_by_user;
    }

    /**
     * This method gets trainee feedbacks for some class nad user
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @param $user_id
     * @author Anastasiya Tarasenko
     */
    public function get_trainee_feedback_by_user_id($tenant_id, $course_id, $class_id, $user_id){
        $this->db->select('tf.*, mv.category_name, mv.parameter_id');
        $this->db->from('metadata_values mv');
        $this->db->join('trainee_feedback tf', 'tf.feedback_question_id = mv.parameter_id and tf.class_id = ' . $class_id . ' and tf.user_id =' . $user_id .
            ' and tf.course_id =' . $course_id, 'left');

        $this->db->like('mv.category_id', 'CAT32_01', 'after');

        $query = $this->db->get();

        $result = $query->result_array();

        $grouped_by_question = array();
        foreach($result as $res){
            $grouped_by_question[$res['parameter_id']] = $res;
        }
        return $grouped_by_question;
    }

    /**
     * This method gets trainee feedbacks for some class for xls report
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @author Anastasiya Tarasenko
     */
    public function get_trainee_feedback_for_report($tenant_id, $course_id, $class_id){
        $this->db->select("sum(CAST(feedback_answer AS UNSIGNED))/count(*) as rating, CONCAT(tup.first_name,' ',tup.last_name) as name, date(ce.trainee_fdbck_on) as feedback_date, tu.tax_code, tf.user_id", FALSE);

        $this->db->from('trainee_feedback tf');
        $this->db->join('tms_users tu', 'tf.user_id = tu.user_id and tf.tenant_id = tu.tenant_id');
        $this->db->join('tms_users_pers tup', 'tf.user_id = tup.user_id and tf.tenant_id = tup.tenant_id');
        $this->db->join('class_enrol ce', 'tf.user_id = ce.user_id and tf.class_id = ce.class_id and tf.tenant_id = ce.tenant_id and tf.course_id = ce.course_id');

        $array = array('tf.tenant_id' => $tenant_id, 'tf.course_id' => $course_id, 'tf.class_id' => $class_id);

        $this->db->where($array);

        $this->db->group_by("tf.user_id");

        $query = $this->db->get();

        return $query->result_array();
    }

    public function get_wda_report_data($tenant_id, $course_id, $class_id, $trainee_name, $tax_code, $start_date, $end_date, $sort_field, $sort_order, $offset)
    {
        if (empty($offset)) $offset=0;

        $sql="select SQL_CALC_FOUND_ROWS u.user_id, ce.class_id,
concat(u.tax_code_type, ' - ',u.tax_code) as tax_code,
concat(up.first_name, ' ', up.last_name) as name,
u.account_type,
concat(up.personal_address_bldg, ' ', up.personal_address_city, ' ', up.personal_address_state, ' ', up.personal_address_zip, ' ', up.personal_address_country) as address,
concat('Contact Number: ', up.contact_number, ' Email Id: ', u.registered_email_Id) as contact_details,
cc.class_start_datetime, assmnt.assmnt_date, pymnt.amount_recd
from tms_users u
join tms_users_pers up on u.user_id=up.user_id
join class_enrol ce on ce.user_id = u.user_id
join course_class cc on cc.class_id=ce.class_id
left join class_assmnt_trainee assmnt on (assmnt.class_id=cc.class_id and assmnt.user_id=u.user_id)
left join enrol_pymnt_due due on due.user_id = u.user_id
left join enrol_invoice inv on inv.pymnt_due_id=due.pymnt_due_id
left join enrol_paymnt_recd pymnt on pymnt.invoice_id=inv.invoice_id
where u.tenant_id=".$this->db->escape($tenant_id); //TODO replace left join with join

        if (!empty($start_date))
            $sql .= " AND class_end_datetime >=".$this->db->escape(date_format_mysql($start_date));
        if (!empty($end_date))
            $sql .= " AND class_end_datetime <=".$this->db->escape(date_format_mysql($end_date));
        if (!empty($course_id))
            $sql .= " AND cc.course_id=".$this->db->escape($course_id);
        if (!empty($class_id))
            $sql .= " AND cc.class_id=".$this->db->escape($class_id);
        if (!empty($trainee_name))
            $sql .= " AND (up.first_name like '".$this->db->escape_like_str($trainee_name)."%' OR up.last_name like '".$this->db->escape_like_str($trainee_name)."%') ";
        if (!empty($tax_code))
            $sql .= " AND u.tax_code=".$this->db->escape($tax_code); ;

        if (!empty($sort_field))
            $sql .= " ORDER BY ".$sort_field." ".$sort_order;

        if ($offset>-1) //for export
            $sql .= " LIMIT ".$offset.",".RECORDS_PER_PAGE;

        $query = $this->db->query($sql);

        $count = $this->db->query('select FOUND_ROWS() AS count')->row()->count;
        return array('query'=>$query, 'count'=>$count ) ;

    }

    /**
     * This method gets certifications report
     * Author: Vasyl Shvaliuk
     * Date: 29 Aug 2014
     *
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @param $trainee_name
     * @param $status
     * @param $start_date
     * @param $end_date
     * @param $sort_field
     * @param $sort_order
     * @param $offset
     */
    public function get_cert_report_data($tenant_id, $course_id, $class_id, $trainee_name, $status, $start_date, $end_date, $sort_field, $sort_order, $offset)
    {
        if (empty($offset)) $offset=0;

        $sql="SELECT SQL_CALC_FOUND_ROWS * from (
		SELECT
	c.crse_name,
	cc.class_name,
	CONCAT(u.tax_code_type, ' - ',u.tax_code) AS tax_code,
	CONCAT(up.first_name, ' ', up.last_name) AS name,
	cc.class_end_datetime,
	ce.certificate_coll_on,
    CASE
		WHEN IFNULL(c.crse_cert_validity, 0) = 0 THEN 'PENDCOLL'
		WHEN DATEDIFF(ADDDATE(cc.class_end_datetime, c.crse_cert_validity - 30), CURDATE()) <= 0 THEN 'DUECOLL'
		WHEN DATEDIFF(ADDDATE(cc.class_end_datetime, c.crse_cert_validity), CURDATE()) > 0
			OR DATEDIFF(cc.class_end_datetime, CURDATE()) < 0 THEN 'EXPIRD'
		ELSE ''
END 
AS status
FROM tms_users u
JOIN tms_users_pers up ON u.user_id=up.user_id
JOIN class_enrol ce ON ce.user_id = u.user_id
JOIN course_class cc ON cc.class_id = ce.class_id
JOIN course c ON c.course_id = cc.course_id
	WHERE u.tenant_id = ".$this->db->escape($tenant_id);

        if (!empty($start_date))
            $sql .= " AND class_end_datetime >=".$this->db->escape(date_format_mysql($start_date));
        if (!empty($end_date))
            $sql .= " AND class_end_datetime <=".$this->db->escape(date_format_mysql($end_date));
        if (!empty($course_id))
            $sql .= " AND cc.course_id=".$this->db->escape($course_id);
        if (!empty($class_id))
            $sql .= " AND cc.class_id=".$this->db->escape($class_id);
        if (!empty($trainee_name))
            $sql .= " AND (up.first_name like '".$this->db->escape_like_str($trainee_name)."%' OR up.last_name like '".$this->db->escape_like_str($trainee_name)."%') ";

        $sql .= ")T";

        if (!empty($status))
            $sql .= " WHERE status in ($status)" ;

        if (!empty($sort_field))
            $sql .= " ORDER BY ".$sort_field." ".$sort_order;

        if ($offset>-1) //for export
            $sql .= " LIMIT ".$offset.",".RECORDS_PER_PAGE;

        $query = $this->db->query($sql);
		
        $count = $this->db->query('select FOUND_ROWS() AS count')->row()->count;
        return array('query'=>$query, 'count'=>$count ) ;
    }

	
	
    public function get_enrolments_for_sales($tenant_id, $sales_id, $start_date =  null, $end_date = null, $sort_by = null, $sort_order = null, $offset = null, $limit = null){
        $this->db->select("SQL_CALC_FOUND_ROWS c.crse_name, cc.class_name, tu.tax_code, CONCAT(tup.first_name,' ',tup.last_name) as name, date(ce.enrolled_on) as enrolment_date, CONCAT(tup.contact_number,', ', tu.registered_email_id) as contact, date(ce.enrolled_on) as enrolment_date, tu.country_of_residence as country", FALSE);

        $this->db->from('class_enrol ce');
        $this->db->join('tms_users tu', 'ce.user_id = tu.user_id and ce.tenant_id = tu.tenant_id');
        $this->db->join('tms_users_pers tup', 'ce.user_id = tup.user_id and ce.tenant_id = tup.tenant_id');
        $this->db->join('course c', 'ce.course_id = c.course_id and c.tenant_id = ce.tenant_id');
        $this->db->join('course_class cc', 'cc.class_id = ce.class_id and cc.course_id = ce.course_id and cc.tenant_id = ce.tenant_id');

        $array = array('ce.tenant_id' => $tenant_id, 'ce.sales_executive_id' => $sales_id);
        $this->db->where($array);

        if (!empty($start_date)){
            $this->db->where('date(ce.enrolled_on)>=', $start_date);
        }

        if (!empty($end_date)){
            $this->db->where('date(ce.enrolled_on)<=', $end_date);
        }

        if($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        } else {
            $this->db->order_by('c.crse_name, cc.class_name', 'asc');
        }

        if ($offset != null && $limit != null){
            if ($limit == $offset) {
                $this->db->limit($offset);
            }
            else if($limit > 0) {
                $limitvalue = $offset - $limit;
                $this->db->limit($limit, $limitvalue);
            }
        }

        $query = $this->db->get();

        $result = $query->result_array();
        $count = $this->db->query('select FOUND_ROWS() AS count')->row()->count;

        return array($result, $count);
    }

}