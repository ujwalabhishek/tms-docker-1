<?php

/*
 * This is the Model class for Class
 * Author : Jaison Jose
 * Date created : 25 July 2014
 */

class Class_Model extends CI_Model {

    /**
     * This method gets the sales executives who can sell this course
     * @param type $tenantId
     * @param type $courseId
     * @author Sankara
     * @date Aug 13 2014
     */
    public function get_course_salesexec($tenantId, $courseId) {
        /*         * SELECT sales.user_id, usr.first_name, usr.last_name
          FROM course_sales_exec sales, tms_users_pers usr
          WHERE usr.tenant_id = sales.tenant_id
          AND usr.user_id = sales.user_id
          AND sales.tenant_id = '$tenantId'
          AND sales.course_id ='$courseId' * */
        $query = $this->db->query("SELECT sales.user_id, usr.first_name, usr.last_name
          FROM course_sales_exec sales, tms_users_pers usr
          WHERE usr.tenant_id = sales.tenant_id
          AND usr.user_id = sales.user_id
          AND sales.tenant_id = '$tenantId'
          AND sales.course_id ='$courseId'");
//        $this->db->select('sales.user_id, usr.first_name, usr.last_name');
//        $this->db->from('course_sales_exec sales, tms_users_pers usr');
//        $this->db->where('usr.tenant_id', 'sales.tenant_id');
//        $this->db->where('usr.user_id', 'sales.user_id');
//        $this->db->where('sales.tenant_id', $tenantId);
//        $this->db->where('sales.course_id', $courseId);
//        $query = $this->db->get();
        return $query->result();
    }

    /**
     * function to get commission payment due
     * Author: Sankar
     * Date: 24 Aug 2014
     */
    public function get_commission_payment_due($tenant_id, $salesexec_id) {
        $result = $this->db->select('comm_period_mth, comm_period_yr, course_id, comm_amount')
                        ->from('sales_comm_due')->where('tenant_id', $tenant_id)
                        ->where('sales_exec_id', $salesexec_id)->where('pymnt_status', 'NOTPAID')
                        ->order_by('course_id', 'ASC')->order_by('comm_period_yr', 'ASC')
                        ->order_by('comm_period_mth', 'ASC')->get()->result_object();
        return $result;
    }

    /**
     * function to post commission values
     * Author: Sankar
     * Date: 24 Aug 2014
     */
    public function update_commission_post($tenant_id, $user_id) {
        extract($_POST);
        $payment_due_id = $this->db->select('pymnt_due_id')->from('sales_comm_due')->where('tenant_id', $tenant_id)
                        ->where('sales_exec_id', $salesexec)->where('pymnt_status', 'NOTPAID')->order_by('pymnt_due_id', 'DESC')
                        ->get()->row()->pymnt_due_id;
        if (!empty($payment_due_id)) {
            if ($payment_type == 'CASH') {
                $data = array(
                    'pymnt_due_id' => $payment_due_id,
                    'paid_on' => date('Y-m-d H:i:S', strtotime($cashpaid_on)),
                    'mode_of_payment' => $payment_type,
                    'amount_paid' => $cash_amount,
                    'cheque_number' => NULL,
                    'cheque_date' => NULL,
                    'bank_name' => NULL,
                    'updated_by' => $user_id,
                    'updated_on' => date('Y-m-d')
                );
            } elseif ($payment_type == 'CHQ') {
                $data = array(
                    'pymnt_due_id' => $payment_due_id,
                    'paid_on' => date('Y-m-d H:i:S', strtotime($paid_on)),
                    'mode_of_payment' => $payment_type,
                    'amount_paid' => $cheque_amount,
                    'cheque_number' => $cheque_number,
                    'cheque_date' => date('Y-m-d', strtotime($cheque_date)),
                    'bank_name' => $bank_name,
                    'updated_by' => $user_id,
                    'updated_on' => date('Y-m-d')
                );
            }
            $this->db->insert('sales_comm_pymnt', $data);
            $data = array('pymnt_status' => 'PAID');
            $this->db->where('tenant_id', $tenant_id);
            $this->db->where('sales_exec_id', $salesexec);
            $this->db->update('sales_comm_due', $data);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * function to get commission paid to sales executive
     * Author: Sankar
     * Date: 24 Aug 2014
     */
    public function get_commission_payment($tenant_id, $salesexec_id) {
        $result = $this->db->select('c.crse_name as course, p.paid_on, m.category_name,p.mode_of_payment, p.cheque_number, p.cheque_date, p.amount_paid')
                        ->from('sales_comm_due d')
                        ->join('sales_comm_pymnt p', 'p.pymnt_due_id=d.pymnt_due_id')
                        ->join('course c', 'c.course_id=d.course_id')
                        ->join('metadata_values m', 'm.parameter_id=p.mode_of_payment')
                        ->where('d.tenant_id', $tenant_id)
                        ->where('d.sales_exec_id', $salesexec_id)->where('d.pymnt_status', 'PAID')
                        ->order_by('p.pymnt_due_id', 'ASC')->get()->result_object();
        return $result;
    }

    /**
     * function to get all the sales executive
     * Author: Sankar
     * Date: 23 Aug 2014
     */
    public function get_all_sales_exec($tenant_id) {
        $result = $this->db->select('prs.user_id, prs.first_name, prs.last_name')
                        ->from('internal_user_role iur')->join('tms_users_pers prs', 'prs.user_id=iur.user_id')
                        ->where('iur.role_id', 'SLEXEC')
                        ->where('iur.tenant_id', $tenant_id)
                        ->order_by('prs.first_name', 'ASC')->get()->result_object();
        return $result;
    }

    /**
     * function to get all the sales executive
     * Author: Sankar
     * Date: 23 Aug 2014
     */
    public function get_sales_exec_name($tenant_id, $user_id) {
        $result = $this->db->select('prs.user_id, prs.first_name, prs.last_name')
                        ->from('internal_user_role iur')->join('tms_users_pers prs', 'prs.user_id=iur.user_id')
                        ->where('iur.role_id', 'SLEXEC')
                        ->where('iur.tenant_id', $tenant_id)
                        ->where('iur.user_id', $user_id)
                        ->order_by('prs.first_name', 'ASC')->get()->row();
        return $result->first_name . ' ' . $result->last_name;
    }

    /**
     * function to deactivate class
     * Author: Sankar
     * Date: 22 Aug 2014
     */
    function deactivate_class($class_id) {
        $this->load->helper('common');
        foreach ($this->input->post() as $key => $value) {
            $$key = $value;
        }
//        $deactivation_date = date('Y-m-d', strtotime($deactivation_date));
        $deactivate_date = date('Y-m-d');
        $data = array(
            'class_status' => 'INACTIV',
            'deacti_date_time' => $deactivation_date,
            'deacti_reason' => $reason_for_deactivation,
            'deacti_reason_oth' => $other_reason_for_deactivation,
            'deacti_by' => $this->session->userdata('userDetails')->user_id,
        );
        $this->db->where('tenant_id', $this->session->userdata('userDetails')->tenant_id);
        $this->db->where('class_id', $class_id);
        $this->db->update('course_class', $data);
    }

    /**
     * this function to get all the class details by class_id
     */
    public function get_class_details($tenant_id, $class_id) {
        $this->db->select('*');
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenant_id);
        $this->db->where('class_id', $class_id);
        $result = $this->db->get()->row();
        return $result;
    }

    /**
     * this function is to get the total count in class list page
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function get_all_class_count_by_tenant_id($tenant_id, $course_id, $class_id, $class_status) {
        $cur_date = date('Y-m-d H:i:s');
        if (empty($tenant_id)) {
            return 0;
        }
        $this->db->select('count(*) as totalrows');
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenant_id);
        if (!empty($course_id)) {
            $this->db->where('course_id', $course_id);
        }
        if (!empty($class_id)) {
            $this->db->where('class_id', $class_id);
        }
        if (!empty($class_status)) {
            switch ($class_status) {
                case 'IN_PROG':
                    $this->db->where('class_start_datetime <=', $cur_date);
                    $this->db->where('class_end_datetime >=', $cur_date);
                    break;

                case 'COMPLTD':
                    $this->db->where('class_end_datetime <', $cur_date);
                    break;

                case 'YTOSTRT':
                    $this->db->where('class_start_datetime >', $cur_date);
                    break;

                default:
                    break;
            }
        }

        $result = $this->db->get()->result();

        return $result[0]->totalrows;
    }

    /**
     * function to get active enrollments booked
     * Author: Sankar
     * Date: 22 Aug 2014
     */
    public function get_class_booked($course_id, $class_id, $tenant_id) {
        $this->db->select('count(*) as count');
        $this->db->from('class_enrol');
        $this->db->where('tenant_id', $tenant_id);
        $this->db->where('class_id', $class_id);
        $this->db->where('course_id', $course_id);
        $this->db->where('enrol_status', 'ENRLACT');
        return $this->db->get()->row()->count;
    }

    /**
     * function to export all booked seats
     * Author: Sankar
     * Date: 22 aug 2014
     */
    public function export_all_booked_seats($tenant_id, $class_id, $sort_order, $sort_by) {
        $this->db->select('usrs.tax_code,prs.first_name, prs.last_name, usrs.account_type, 
        usrs.country_of_residence,enrol.enrolled_on, prs.dob, enrol.payment_status');
        $this->db->from('class_enrol enrol');
        $this->db->join('tms_users usrs', 'usrs.user_id=enrol.user_id');
        $this->db->join('tms_users_pers prs', 'prs.user_id=usrs.user_id');
        $this->db->where('enrol.tenant_id', $tenant_id);
        $this->db->where('enrol.class_id', $class_id);
        $this->db->where('enrol.enrol_status', 'ENRLACT');
        if ($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        } else {
            $this->db->order_by('usrs.user_id', 'DESC');
        }
        $query = $this->db->get();
        return $query->result_object();
    }

    /**
     * function to get table data of booked seats
     * Author: Sankar
     * Date: 22 Aug 2014
     */
    public function list_all_booked_seats($tenant_id, $limit = NULL, $offset = NULL, $sort_by = NULL, $sort_order = NULL, $class_id) {
        $this->db->select('usrs.tax_code,prs.first_name, prs.last_name, usrs.account_type, 
        usrs.country_of_residence,enrol.enrolled_on, prs.dob, enrol.payment_status, usrs.user_id');
        $this->db->from('class_enrol enrol');
        $this->db->join('tms_users usrs', 'usrs.user_id=enrol.user_id');
        $this->db->join('tms_users_pers prs', 'prs.user_id=usrs.user_id');
        $this->db->where('enrol.tenant_id', $tenant_id);
        $this->db->where('enrol.class_id', $class_id);
        $this->db->where('enrol.enrol_status', 'ENRLACT');
        if ($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        } else {
            $this->db->order_by('usrs.user_id', 'DESC');
        }
        if ($limit == $offset) {
            $this->db->limit($offset);
        } else if ($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);
        }
        $query = $this->db->get();
        return $query->result_object();
    }

    /**
     * this function to get the classses list 
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function list_all_class_by_tenant_id($tenant_id, $limit = NULL, $offset = NULL, $sort_by = NULL, $sort_order = NULL, $course_id = '', $class_id = '', $class_status = '') {
        $cur_date = date('Y-m-d H:i:s');
        if ($offset <= 0 || empty($tenant_id)) {
            return;
        }
        $this->db->select("class_id, course_id, class_name, class_start_datetime, class_end_datetime, classroom_trainer, class_language, total_seats, class_status");
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenant_id);
        if (!empty($course_id)) {
            $this->db->where('course_id', $course_id);
        }
        if (!empty($class_id)) {
            $this->db->where('class_id', $class_id);
        }
        if (!empty($class_status)) {
            switch ($class_status) {
                case 'IN_PROG':
                    $this->db->where('class_start_datetime <=', $cur_date);
                    $this->db->where('class_end_datetime >=', $cur_date);
                    break;

                case 'COMPLTD':
                    $this->db->where('class_end_datetime <', $cur_date);
                    break;

                case 'YTOSTRT':
                    $this->db->where('class_start_datetime >', $cur_date);
                    break;
            }
            $this->db->where_not_in('class_status', 'INACTIV');
        }
        if ($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        } else {
            $this->db->order_by('class_id', 'DESC');
        }
        if ($limit == $offset) {
            $this->db->limit($offset);
        } else if ($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);
        }

        $query = $this->db->get();        
        return $query->result_array();
    }

    /**
     * this function to get the class status by its start and end date
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function get_class_status($cid, $status) {
        if (!empty($status)) {
            switch ($status) {
                case 'IN_PROG':
                    return 'In-Progress';
                    break;
                case 'COMPLTD':
                    return 'Completed';
                    break;
                case 'YTOSTRT':
                    return 'Yet to Start';
                    break;
            }
        }
        $cur_date = time();

        $data = $this->db->select('class_status,class_start_datetime as start,class_end_datetime as end')
                        ->from('course_class')->where('class_id', $cid)->get()->row(0);
        $start = strtotime($data->start);
        $end = strtotime($data->end);
        if ($data->class_status == 'INACTIV') {
            return 'Inactive';
        } elseif ($start > $cur_date) {
            return 'Yet to Start';
        } elseif ($end < $cur_date) {
            return 'Completed';
        } else { //if ($start <= $cur_date && $end >= $cur_date)
            return 'In-Progress';
        }
    }

    /**
     * this function get autocomplete course name
     * Author: Sankar
     * Date: 20 Aug 2014
     */
    function get_course_autocomplete($tenant_id, $search_course_code) {
        if (!empty($search_course_code)) {
            $this->db->select('crse_name as label,course_id as id');
            $this->db->from('course');
            $this->db->where('tenant_id', $tenant_id);
            $this->db->where_not_in('crse_status', 'INACTIV');
            $this->db->like('crse_name', $search_course_code, 'after');
            $results = $this->db->get()->result_object();
            return $results;
        }
    }

    /**
     * this function to export class page fields
     * Author:Sankar
     * Date: 21 Aug 2014
     */
    public function get_class_list_export($tenant_id) {
        $cur_date = date('Y-m-d H:i:s');
        $course_id = $this->input->get('course_id');
        $class_id = $this->input->get('class_id');
        $class_status = $this->input->get('class_status');
        $sort_order = $this->input->get('0');
        $sort_by = $this->input->get('f');
        $this->db->select('*')->from('course_class')->where('tenant_id', $tenant_id);
        if (!empty($course_id)) {
            $this->db->where('course_id', $course_id);
        }
        if (!empty($class_id)) {
            $this->db->where('class_id', $class_id);
        }
        if (!empty($class_status)) {
            switch ($class_status) {
                case 'IN_PROG':
                    $this->db->where('class_start_datetime <=', $cur_date);
                    $this->db->where('class_end_datetime >=', $cur_date);
                    break;

                case 'COMPLTD':
                    $this->db->where('class_end_datetime <', $cur_date);
                    break;

                case 'YTOSTRT':
                    $this->db->where('class_start_datetime >', $cur_date);
                    break;

                default:
                    break;
            }
            $this->db->where_not_in('class_status', 'INACTIV');
        }
        if ($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        } else {
            $this->db->order_by('class_id', 'DESC');
        }
        $result = $this->db->get()->result_object();
        return $result;
    }

    /**
     * this function gets the default assessment schedule for class id
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function get_def_assessment($tenant_id, $class_id) {
        $result = $this->db->select('*')->from('class_assmnt_schld')->where('tenant_id', $tenant_id)
                        ->where('class_id', $class_id)->get()->row();
        return $result;
    }

    /**
     * this function to get all class schedules
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function get_all_class_schedule($tenant_id, $cid) {
//        $result = $this->db->select('class_date, session_type_id, session_start_time,session_end_time')
//                ->from('class_schld')->where('tenant_id',$tenant_id)->where('class_id',$cid)
//                ->orderby('class_date','DESC')->orderby('session_start_time','ASC')->get();
        $result = $this->db->query("select class_date, session_type_id, session_start_time,session_end_time
                from class_schld where tenant_id='$tenant_id' and class_id='$cid'
                order by class_date DESC, session_start_time ASC");
        return $result->result_array();
    }

    /**
     * class sales executive details
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    function get_class_salesexec($tenant_id, $course_id, $ids) {
        $result = $this->db->query("select pers.first_name, pers.last_name, sales.commission_rate
                from tms_users_pers pers
                inner join course_sales_exec sales on sales.user_id=pers.user_id 
                where pers.user_id IN ($ids) and pers.tenant_id='$tenant_id' and sales.course_id='$course_id'");
        return $result->result_array();
    }

    /**
     * this function to get trainer names
     * Author: Sankar
     * Date: 19 Aug 2014
     */
    public function get_trainer_names($trainer_id) {
        $tenantId = $this->session->userdata('userDetails')->tenant_id;
        $tids = explode(',', $trainer_id);
        if (!empty($tids)) {
            $this->load->model('course_model', 'course');
            $trainer_name = '';
            foreach ($tids as $tid) {
                $sql = "SELECT pers.user_id, pers.first_name, pers.last_name, rl.role_id FROM `tms_users_pers` pers, internal_user_role rl
        WHERE pers.tenant_id = rl.tenant_id AND pers.user_id = rl.user_id AND pers.tenant_id = '$tenantId' AND rl.role_id='TRAINER' AND rl.user_id='$tid'";
                $query = $this->db->query($sql);

                $data = $query->row(0);
                $trainer = $data->first_name . ' ' . $data->last_name;

                $trainer_name .="$trainer,";
            }
            return rtrim($trainer_name, ',');
        }
    }

    /**
     * this function get classes in a course for edit
     * Author: Sankar
     * Date: 18 Aug 2014
     */
    public function get_course_class_for_edit($tenantId, $courseId) {
        $cur_date = date('Y-m-d H:i:s');
        $this->db->select('class_id,class_name');
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenantId);
        $this->db->where('course_id', $courseId);
        $this->db->where('class_end_datetime >=', $cur_date);
        $this->db->where_not_in('class_status', 'INACTIV');
        $query = $this->db->get();
        $result = array();
        foreach ($query->result() as $row) {
            $result[$row->class_id] = $row->class_name;
        }
        return $result;
    }

    /**
     * this function get classes in a course
     * Author: Sankar
     * Date: 18 Aug 2014
     */
    public function get_course_class($tenantId, $courseId) {
        $this->db->select('class_id,class_name');
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenantId);
        $this->db->where('course_id', $courseId);
//        $this->db->where_not_in('class_status', 'INACTIV');
        $query = $this->db->get();
        $result = array();
        foreach ($query->result() as $row) {
            $result[$row->class_id] = $row->class_name;
        }
        return $result;
    }

    /**
     * This method gets the languages in a course
     * @param type $tenantId
     * @param type $courseId
     * @author Sankar
     * @date Aug 13 2014
     */
    public function get_course_language($tenantId, $courseId) {
        //SELECT language FROM `course` where tenant_id = $tenantId and course_id = $courseId;
        $this->db->select('language');
        $this->db->from('course');
        $this->db->where('tenant_id', $tenantId);
        $this->db->where('course_id', $courseId);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $languageIds = explode(',', $query->row()->language);
            if (!empty($languageIds)) {
                $course_language = array();
                foreach ($languageIds as $languageId) {
                    $languageId = trim($languageId);
                    $this->db->select('category_name');
                    $this->db->from('metadata_values');
                    $this->db->where('parameter_id', $languageId);
                    $languageText = $this->db->get()->row('category_name');
                    $course_language[$languageId] = $languageText;
                }
                return $course_language;
            }
        }
    }

    /**
     * function to get class by classid, tenantid using in seats booked page
     * Author: Sankar
     * Date: 22 Aug 2014
     */
    public function get_class_by_classid($tenant_id, $class_id) {
        $data = $this->db->select('*')->from('course_class')
                        ->where('tenant_id', $tenant_id)->where('class_id', $class_id)->get()->row_array();
        return $data;
    }

    /**
     * this function to copy class
     * Author: Sankar
     * Date: 20 Aug 2014
     */
    public function copy_classes($tenantId, $user_id) {
        extract($_POST);
        $class_name = $class_name;
        $start_date_timestamp = date('Y-m-d H:i:s', strtotime($start_date));
        $end_date_timestamp = date('Y-m-d H:i:s', strtotime($end_date));
        $data = $this->db->select('*')->from('course_class')
                        ->where('tenant_id', $tenantId)->where('class_id', $class_hid)->get()->row_array();
        $data['class_id'] = '';
        $data['class_name'] = $class_name;
        $data['class_start_datetime'] = $start_date_timestamp;
        $data['class_end_datetime'] = $end_date_timestamp;
        $data['created_by'] = $user_id;
        $data['class_copied_from'] = $class_hid;
        $data['copied_by'] = $user_id;
        $data['copied_reason'] = $copy_reason;
        $data['copied_reason_oth'] = $other_reason;
        $data['created_on'] = date('Y-m-d H:i:s');
        $data['last_modified_on'] = date('Y-m-d H:i:s');
        $course_class = $this->db->insert('course_class', $data);
        if ($course_class) {
            $class_id = $this->db->insert_id();
            if (empty($class_name)) {
                $this->db->where('class_id', $class_id);
                $this->db->update('course_class', array('class_name' => $class_id));
            }
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * This method updates a class for a course
     * @param type $tenantId
     * @param type $userId
     * @param type $courseId
     * @author Sankara
     * @date Aug 14 2014
     */
    public function update_class($tenantId, $userId) {

        /**
         * 1. Insert into table course_class (if class name empty - use course ID)
         * 2. Get the class ID
         * 3. if class name empty the - the update class with course ID - classID
         * 4. if class schedule present -  insert into class_schld
         * 5. if default assessment present then insert into class_assmnt_schld (one row)
         */
        $display_class = 0;
        $control_4 = '';
        $control_5 = '';
        $control_6 = '';
        $control_7 = '';
        $control_3 = '';
        extract($_POST);
        $class_id = $class_hid;
        $start_date_timestamp = date('Y-m-d H:i:s', strtotime($start_date));
        $end_date_timestamp = date('Y-m-d H:i:s', strtotime($end_date));
        $coll_date = date('Y-m-d', strtotime($coll_date));
        $description = htmlspecialchars($description, ENT_QUOTES);
        if (!empty($control_4)) {
            $control_4 = implode(",", $control_4);
        }
        if (!empty($control_5)) {
            $control_5 = implode(",", $control_5);
        }
        if (!empty($control_6)) {
            $control_6 = implode(",", $control_6);
        }
        if (!empty($control_7)) {
            $control_7 = implode(",", $control_7);
        }
        if (!empty($control_3)) {
            $control_3 = implode(",", $control_3);
        }
        // inserting into course_class table.    
        $data = array(
            'tenant_id' => $tenantId,
            'class_name' => $class_name,
            'class_start_datetime' => $start_date_timestamp,
            'class_end_datetime' => $end_date_timestamp,
            'total_seats' => $total_seats,
            'total_classroom_duration' => $cls_duration,
            'total_lab_duration' => $lab_duration,
            'class_fees' => $fees,
            'class_discount' => $class_discount,
            'certi_coll_date' => $coll_date,
            'class_session_day' => $sessions_perday,
            'class_pymnt_enrol' => $payment_details,
            'classroom_location' => $cls_venue,
            'lab_location' => $lab_venue,
            'class_language' => $languages,
            'description' => $description,
            'display_class_public' => $display_class,
            'min_reqd_students' => $minimum_students,
            'min_reqd_noti_freq1' => $reminder1,
            'min_reqd_noti_freq2' => $reminder2,
            'min_reqd_noti_freq3' => $reminder3,
            'classroom_trainer' => $control_5,
            'lab_trainer' => $control_6,
            'assessor' => $control_7,
            'training_aide' => $control_3,
            'sales_executive' => $control_4,
            'last_modified_by' => $userId,
            'last_modified_on' => date('Y-m-d H:i:s')
        );
        $this->db->where('tenant_id', $tenantId);
        $this->db->where('class_id', $class_id);
        $update_result = $this->db->update('course_class', $data);
        if ($update_result) {
            //class name generation if not
            if (empty($class_name)) {
                $this->db->where('class_id', $class_id);
                $this->db->update('course_class', array('class_name' => $class_id));
            }
            //sending mail to already enrolled trainees
            $totalbooked = $this->get_class_booked($course_id, $class_id, $tenantId);
            if (!empty($totalbooked)) {
                //get mails
                $this->db->select('usrs.registered_email_id');
                $this->db->from('class_enrol enrol');
                $this->db->join('tms_users usrs', 'usrs.user_id=enrol.user_id');
                $this->db->where('enrol.tenant_id', $tenantId);
                $this->db->where('enrol.class_id', $class_id);
                $this->db->where('enrol.enrol_status', 'ENRLACT');
                $emails = $this->db->get()->result_object();
//                print_r($emails);
//                die;
            }
            //class_schld insert query
            $this->db->where('tenant_id', $tenantId);
            $this->db->where('class_id', $class_id);
            $delete_result = $this->db->delete('class_schld');
            if (!empty($schlded_date)) {
                foreach ($schlded_date as $k => $v) {
                    $class_date = date('Y-m-d', strtotime($schlded_date[$k]));
//                    $session_start_time = date('Y-m-d', strtotime('0000-00-00 ' . $schlded_start_time[$k] . ':00'));
//                    $session_end_time = date('Y-m-d', strtotime($schlded_date[$k] . ' ' . $schlded_end_time[$k] . ':00'));
                    $session_start_time = $schlded_start_time[$k] . ':00';
                    $session_end_time = $schlded_end_time[$k] . ':00';
                    $class_schld_data = array(
                        'tenant_id' => $tenantId,
                        'course_id' => $course_id,
                        'class_id' => $class_id,
                        'class_date' => $class_date,
                        'session_type_id' => $schlded_session_type[$k],
                        'session_start_time' => $session_start_time,
                        'session_end_time' => $session_end_time
                    );
                    $this->db->insert('class_schld', $class_schld_data);
                }
            }
            //class_assmnt_schld insert query
            $this->db->where('tenant_id', $tenantId);
            $this->db->where('class_id', $class_id);
            $delete_result = $this->db->delete('class_assmnt_schld');
            if (isset($def_schlded_date)) {
                $assmnt_date = date('Y-m-d', strtotime($def_schlded_date));
//                $assmnt_start_time = date('Y-m-d', strtotime($def_schlded_date . ' ' . $def_schlded_start_time . ':00'));
//                $assmnt_end_time = date('Y-m-d', strtotime($def_schlded_date . ' ' . $def_schlded_end_time . ':00'));
                $assmnt_start_time = $def_schlded_start_time . ':00';
                $assmnt_end_time = $def_schlded_end_time . ':00';
                $class_assmnt_data = array(
                    'tenant_id' => $tenantId,
                    'course_id' => $course_id,
                    'class_id' => $class_id,
                    'assmnt_date' => $assmnt_date,
                    'assmnt_start_time' => $assmnt_start_time,
                    'assmnt_end_time' => $assmnt_end_time,
                    'assessor_id' => $def_schlded_assessor,
                    'assmnt_venue' => $def_schlded_venue,
                    'assmnt_type' => ''
                );
                $this->db->insert('class_assmnt_schld', $class_assmnt_data);
            }
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * This method creates a class for a course
     * @param type $tenantId
     * @param type $userId
     * @param type $courseId
     * @author Sankara
     * @date Aug 14 2014
     */
    public function create_class($tenantId, $userId) {

        /**
         * 1. Insert into table course_class (if class name empty - use course ID)
         * 2. Get the class ID
         * 3. if class name empty the - the update class with course ID - classID
         * 4. if class schedule present -  insert into class_schld
         * 5. if default assessment present then insert into class_assmnt_schld (one row)
         */
        $display_class = 0;
        $control_4 = '';
        $control_5 = '';
        $control_6 = '';
        $control_7 = '';
        $control_3 = '';
        extract($_POST);
        $start_date_timestamp = date('Y-m-d H:i:s', strtotime($start_date));
        $end_date_timestamp = date('Y-m-d H:i:s', strtotime($end_date));
        $coll_date = date('Y-m-d', strtotime($coll_date));
        $description = htmlspecialchars($description, ENT_QUOTES);
        if (!empty($control_4)) {
            $control_4 = implode(",", $control_4);
        }
        if (!empty($control_5)) {
            $control_5 = implode(",", $control_5);
        }
        if (!empty($control_6)) {
            $control_6 = implode(",", $control_6);
        }
        if (!empty($control_7)) {
            $control_7 = implode(",", $control_7);
        }
        if (!empty($control_3)) {
            $control_3 = implode(",", $control_3);
        }
        // inserting into course_class table.    
        $data = array(
            'tenant_id' => $tenantId,
            'course_id' => $class_course,
            'class_name' => $class_name,
            'class_start_datetime' => $start_date_timestamp,
            'class_end_datetime' => $end_date_timestamp,
            'total_seats' => $total_seats,
            'total_classroom_duration' => $cls_duration,
            'total_lab_duration' => $lab_duration,
            'class_fees' => $fees,
            'class_discount' => $class_discount,
            'certi_coll_date' => $coll_date,
            'class_session_day' => $sessions_perday,
            'class_pymnt_enrol' => $payment_details,
            'classroom_location' => $cls_venue,
            'lab_location' => $lab_venue,
            'class_language' => $languages,
            'description' => $description,
            'display_class_public' => $display_class,
            'min_reqd_students' => $minimum_students,
            'min_reqd_noti_freq1' => $reminder1,
            'min_reqd_noti_freq2' => $reminder2,
            'min_reqd_noti_freq3' => $reminder3,
            'classroom_trainer' => $control_5,
            'lab_trainer' => $control_6,
            'assessor' => $control_7,
            'training_aide' => $control_3,
            'sales_executive' => $control_4,
            'class_status' => 'YTOSTRT',
            'created_by' => $userId,
            'created_on' => date('Y-m-d H:i:s'),
            'last_modified_on' => date('Y-m-d H:i:s')
        );
        $this->db->insert('course_class', $data);
        $class_id = $this->db->insert_id();
        if ($class_id) {
            //class name generation if not
            if (empty($class_name)) {
                $this->db->where('class_id', $class_id);
                $this->db->update('course_class', array('class_name' => $class_id));
            }
            //class_schld insert query
            if (!empty($schlded_date)) {
                foreach ($schlded_date as $k => $v) {
                    $class_date = date('Y-m-d', strtotime($schlded_date[$k]));
//                    $session_start_time = date('Y-m-d', strtotime('0000-00-00 ' . $schlded_start_time[$k] . ':00'));
//                    $session_end_time = date('Y-m-d', strtotime($schlded_date[$k] . ' ' . $schlded_end_time[$k] . ':00'));
                    $session_start_time = $schlded_start_time[$k] . ':00';
                    $session_end_time = $schlded_end_time[$k] . ':00';
                    $class_schld_data = array(
                        'tenant_id' => $tenantId,
                        'course_id' => $class_course,
                        'class_id' => $class_id,
                        'class_date' => $class_date,
                        'session_type_id' => $schlded_session_type[$k],
                        'session_start_time' => $session_start_time,
                        'session_end_time' => $session_end_time
                    );
                    $this->db->insert('class_schld', $class_schld_data);
                }
            }
            //class_assmnt_schld insert query
            if (isset($def_schlded_date)) {
                $assmnt_date = date('Y-m-d', strtotime($def_schlded_date));
//                $assmnt_start_time = date('Y-m-d', strtotime($def_schlded_date . ' ' . $def_schlded_start_time . ':00'));
//                $assmnt_end_time = date('Y-m-d', strtotime($def_schlded_date . ' ' . $def_schlded_end_time . ':00'));
                $assmnt_start_time = $def_schlded_start_time . ':00';
                $assmnt_end_time = $def_schlded_end_time . ':00';
                $class_assmnt_data = array(
                    'tenant_id' => $tenantId,
                    'course_id' => $class_course,
                    'class_id' => $class_id,
                    'assmnt_date' => $assmnt_date,
                    'assmnt_start_time' => $assmnt_start_time,
                    'assmnt_end_time' => $assmnt_end_time,
                    'assessor_id' => $def_schlded_assessor,
                    'assmnt_venue' => $def_schlded_venue,
                    'assmnt_type' => ''
                );
                $this->db->insert('class_assmnt_schld', $class_assmnt_data);
            }
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * this function to get payment details of trainee enrolled
     * Author: Sankar
     * Date: 23 Aug 2014
     */
    public function get_payment_received($tenant_id, $class_id, $user_id) {
        $this->db->select('epr.recd_on, prs.first_name, prs.last_name, epr.mode_of_pymnt, cc.class_fees, cc.class_discount, ei.total_inv_discnt,
            ei.total_inv_subsdy, ei.total_gst, ei.gst_rate, ei.total_inv_amount, epr.amount_recd, cc.class_name');
        $this->db->from('class_enrol ce');
        $this->db->join('tms_users_pers prs', 'prs.user_id=ce.user_id');
        $this->db->join('course_class cc', 'cc.class_id=ce.class_id');
        $this->db->join('enrol_pymnt_due epd', 'ce.pymnt_due_id =epd.pymnt_due_id');
        $this->db->join('enrol_invoice ei', 'ei.pymnt_due_id =ce.pymnt_due_id');
        $this->db->join('enrol_paymnt_recd epr', 'epr.invoice_id =ei.invoice_id');
        $this->db->where('ce.tenant_id', $tenant_id);
        $this->db->where('ce.class_id', $class_id);
        $this->db->where('ce.user_id', $user_id);
        $this->db->where('ce.enrol_status', 'ENRLACT');
        return $this->db->get()->row_array();
    }

    /*
     * This method gets the Class list for a courses of a tenant
     */

    public function get_class_list($tenantId, $courseId) {

        $this->db->select('class_id, class_name, class_start_datetime, class_end_datetime');
        $this->db->from('course_class');
        $this->db->where('tenant_id', $tenantId);
        $this->db->where('course_id', $courseId);

        $query = $this->db->get();

        $result = $query->result_array();

        $classes = array();
        foreach ($result as $item) {
            $classes[$item['class_id']] = $item['class_name'];
        }

        return $classes;
    }

    /**
     * This method gets the class details
     * @param type $tenant_id
     * @param type $course_id
     * @param type $class_id
     * @return type
     */
    public function get_class_by_id($tenant_id, $course_id, $class_id) {

        $this->db->select('*');
        $this->db->from('course_class');

        $array = array('tenant_id' => $tenant_id, 'course_id' => $course_id, 'class_id' => $class_id);
        $this->db->where($array);

        $query = $this->db->get();

        $results = $query->result();
        return count($results) > 0 ? $results[0] : null;
    }

    /**
     * This method gets class details for pdf reports
     * @param $class_id
     * @author Anastasiya Tarasenko
     */
    public function get_class_details_for_report($tenant_id, $course_id, $class_id) {
        $this->db->select('cc.class_session_day, cc.course_id, cc.class_name, cc.classroom_trainer, cc.assessor, cc.lab_trainer, c.crse_name, tm.tenant_name as company_name, cc.class_start_datetime, cc.class_end_datetime, c.crse_manager, c.competency_code, cc.total_seats');
        $this->db->from('course_class cc');

        $this->db->join('course c', 'cc.course_id = c.course_id and cc.tenant_id = c.tenant_id');
        $this->db->join('tenant_master tm', 'tm.tenant_id = cc.tenant_id');

        $array = array('cc.tenant_id' => $tenant_id, 'cc.course_id' => $course_id, 'cc.class_id' => $class_id);
        $this->db->where($array);

        $query = $this->db->get();

        $results = $query->result();
        $details = count($results) > 0 ? $results[0] : null;
        if ($details != null) {
            $assessor = $details->assessor;
            $assessor_names = "";
            $assessor_ids = explode(",", $assessor);

            $classroom_trainer = $details->classroom_trainer;
            $classroom_trainer_names = "";
            $classroom_trainer_ids = explode(",", $classroom_trainer);

            $crse_manager = $details->crse_manager;
            $crse_manager_names = "";
            $crse_manager_ids = explode(",", $crse_manager);

            $lab_trainer = $details->lab_trainer;
            $lab_trainer_names = "";
            $lab_trainer_ids = explode(",", $lab_trainer);

            $this->db->select("user_id, concat(first_name, ' ', last_name) as name", FALSE);
            $this->db->from('tms_users_pers');
            $this->db->where('tenant_id', $tenant_id);
            $this->db->where_in('user_id', array_merge($assessor_ids, $classroom_trainer_ids, $crse_manager_ids, $lab_trainer_ids));
            $query = $this->db->get();
            $results = $query->result_array();
            foreach ($results as $res) {
                $user_id = $res['user_id'];
                if (in_array($user_id, $assessor_ids)) {
                    $assessor_names .= $res['name'] . ", ";
                }
                if (in_array($user_id, $classroom_trainer_ids)) {
                    $classroom_trainer_names .= $res['name'] . ", ";
                }
                if (in_array($user_id, $crse_manager_ids)) {
                    $crse_manager_names .= $res['name'] . ", ";
                }
                if (in_array($user_id, $lab_trainer_ids)) {
                    $lab_trainer_names .= $res['name'] . ", ";
                }
            }
            $assessor_names = rtrim($assessor_names, ", ");
            $classroom_trainer_names = rtrim($classroom_trainer_names, ", ");
            $lab_trainer_names = rtrim($lab_trainer_names, ", ");
            $crse_manager_names = rtrim($crse_manager_names, ", ");

            $details->assessor = $assessor_names;
            $details->classroom_trainer = $classroom_trainer_names;
            $details->crse_manager = $crse_manager_names;
            $details->lab_trainer = $lab_trainer_names;
        }
        return $details;
    }

    public function get_class_booked_seats_count($class_id) {
        return $this->db->query("select count(*) as cnt from class_enrol where class_id = ?", $class_id)->row()->cnt;
    }

}

?>