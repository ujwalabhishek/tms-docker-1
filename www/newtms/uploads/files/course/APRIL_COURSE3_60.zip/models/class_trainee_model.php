<?php

/*
 * This is the Model class for Class Trainee
 * Author : Jaison Jose
 * Date created : 25 July 2014
 */

class Class_Trainee_Model extends CI_Model {
    /*
     * ???? params???
     */

    public function get_class_trainee_list($tenant_id, $course_id, $class_id) {


        $this->db->select('tu.tax_code, tup.first_name, cc.class_session_day, ce.class_id, ce.course_id, ce.user_id');
        $this->db->from('class_enrol ce');
        $this->db->join('tms_users tu', 'ce.user_id = tu.user_id');
        $this->db->join('tms_users_pers tup', 'ce.user_id = tup.user_id');
        $this->db->join('course_class cc', 'cc.class_id = ce.class_id');


// from tms_users usr, tms_users_pers pers, course crse, course_class clss, class_enrol enrol where usr.tenant_id = pers.tenant_id and


        if (!empty($tax_code)) {
            $this->db->where('tu.tax_code', $tax_code);
        }

// usr.user_id = pers.user_id and



        if (!empty($trainee_name)) {
            $this->db->where('tup.first_name', $trainee_name);
        }

// usr.user_id = enrol.user_id and
// enrol.class_id = clss.class_id and
        // $this->db->select('concat(usr.tax_code_type,'  ',usr.tax_code)  as  taxcode, concat(pers.first_name, ' ',pers.last_name) as name, crse.crse_name courseName, clss.class_name className, concat( clss.class_start_datetime, '-- ', clss.class_end_datetime) classDuration, clss.class_status, enrol.enrolment_type enrolmentType, enrol.payment_status pymntStatus');
        // $this->db->from('tms_users usr');
        // $this->db->join('tms_users_pers usr', 'usr.user_id = pers.user_id');
        // $this->db->join('course crse', 'usr.user_id = pers.user_id');        
        // $this->db->join('course_class clss', 'cc.class_id = ce.class_id');
        // $this->db->join('class_enrol enrol', 'ca.user_id = ce.user_id', 'left');
        // $array = array('ce.tenant_id' => $tenantId, 'ce.course_id' => $courseId, 'ce.class_id' => $classId);
        // $this->db->where($array);
        // if (!empty($tax_code)){
        //     $this->db->where('tu.tax_code', $tax_code);
        // }
        // if (!empty($trainee_name)){
        //     $this->db->where('tup.first_name', $trainee_name);
        // }
        // //$this->db->where("(ca.class_assmnt_date >= '$dateFrom' or ca.class_assmnt_date is null)");
        // $query = $this->db->get();
        // //echo $this->db->last_query();
        // $result = $query->result_array();
    }

    public function record_count($tenantId, $courseId, $classId) {

        $this->db->select('tu.tax_code, tup.first_name, ca.session_01, ca.session_02, ca.class_assmnt_date, cc.class_session_day, ce.class_id, ce.course_id, ce.user_id');
        $this->db->from('class_enrol ce');
        $this->db->join('tms_users tu', 'ce.user_id = tu.user_id');
        $this->db->join('tms_users_pers tup', 'ce.user_id = tup.user_id');
        $this->db->join('course_class cc', 'cc.class_id = ce.class_id');
        $this->db->join('class_attendance ca', 'ca.user_id = ce.user_id', 'left');

        $array = array('ce.tenant_id' => $tenantId, 'ce.course_id' => $courseId, 'ce.class_id' => $classId);

        $this->db->where($array);

        if (!empty($tax_code)) {
            $this->db->where('tu.tax_code', $tax_code);
        }

        if (!empty($trainee_name)) {
            $this->db->where('tup.first_name', $trainee_name);
        }

        $this->db->where("(ca.class_assmnt_date >= '$dateFrom' or ca.class_assmnt_date is null)");

        $result = $this->db->get()->result();
        //echo $this->db->last_query();
        //die;

        return $result[0]->totalrows;
    }

    /**
     * This method gets class trainee list with attendance grouped by user and date
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @param $from_date
     * @param $to_date
     * @param $sort_by
     * @param $sort_order
     * @author Anastasiya Tarasenko
     */
    public function get_class_trainee_list_for_attendance($tenant_id, $course_id, $class_id, $from_date, $to_date, $sort_by, $sort_order) {

        $date_from = $from_date->format('Y-m-d');
        $date_to = $to_date->format('Y-m-d');

        $this->db->select("tu.tax_code, tu.country_of_residence, CONCAT(tup.first_name,' ',tup.last_name) as name, ca.session_01, ca.session_02, ca.class_assmnt_date, cc.class_session_day, ce.class_id, ce.course_id, ce.user_id", FALSE);
        $this->db->from('class_enrol ce');
        $this->db->join('tms_users tu', 'ce.tenant_id = tu.tenant_id and ce.user_id = tu.user_id');
        $this->db->join('tms_users_pers tup', 'ce.tenant_id = tup.tenant_id and ce.user_id = tup.user_id');
        $this->db->join('course_class cc', 'cc.tenant_id = ce.tenant_id and cc.course_id = ce.course_id and cc.class_id = ce.class_id');
        $this->db->join('class_attendance ca', "ca.tenant_id = ce.tenant_id and ca.course_id = ce.course_id and ca.class_id = ce.class_id and ca.user_id = ce.user_id and ca.class_assmnt_date >= '$date_from' and ca.class_assmnt_date <= '$date_to'", 'left');

        $array = array('ce.tenant_id' => $tenant_id, 'ce.course_id' => $course_id, 'ce.class_id' => $class_id);

        $this->db->where($array);

        if ($sort_by) {
            $this->db->order_by($sort_by, $sort_order);
        }

        $query = $this->db->get();

        $result = $query->result_array();

        $grouped_by_trainee = array();
        foreach ($result as $res) {
            $trainee = $res['user_id'];
            $date = $res['class_assmnt_date'];
            if (!isset($grouped_by_trainee[$trainee])) {
                $grouped_by_trainee[$trainee] = array();
                $grouped_by_trainee[$trainee]['record'] = $res;
            }
            if (!empty($date)) {
                $grouped_by_trainee[$trainee][$date]['session_01'] = $res['session_01'];
                $grouped_by_trainee[$trainee][$date]['session_02'] = $res['session_02'];
            }
        }
        return $grouped_by_trainee;
    }

    /**
     * Update attendance for some class
     * @param $tenant_id
     * @param $course_id
     * @param $class_id
     * @param $data_table
     * @author Anastasiya Tarasenko
     */
    public function update_for_mark_attendance($tenant_id, $course_id, $class_id, $data_table) {
        $is_updated = false;
        $is_inserted = false;

        if (count($data_table) > 0) {

            $insert_array = array();

            foreach ($data_table as $trainee_id => $data_row) {
                foreach ($data_row as $date => $data) {
                    if (isset($data['session_01']) || isset($data['session_02'])) {
                        $exists = $this->is_attandance_exists($class_id, $trainee_id, $date);

                        $update_data = array();

                        if (isset($data['session_01'])) {
                            $update_data['session_01'] = $data['session_01'];
                        }

                        if (isset($data['session_02'])) {
                            $update_data['session_02'] = $data['session_02'];
                        }

                        $this->db->where('class_id', $class_id);
                        $this->db->where('course_id', $course_id);
                        $this->db->where('tenant_id', $tenant_id);
                        $this->db->where('user_id', $trainee_id);
                        $this->db->where('class_assmnt_date', $date);

                        if ($exists) {
                            $this->db->update('class_attendance', $update_data);
                            $is_updated = true;
                        } else {
                            $insert_array[] = array(
                                'tenant_id' => $tenant_id,
                                'course_id' => $course_id,
                                'class_id' => $class_id,
                                'user_id' => $trainee_id,
                                'class_assmnt_date' => $date,
                                'session_01' => $data['session_01'],
                                'session_02' => $data['session_02']
                            );
                        }
                    }
                }
            }

            if (count($insert_array) > 0) {
                $is_inserted = $this->db->insert_batch('class_attendance', $insert_array);
            }
        }
        return $is_inserted || $is_updated;
    }

    public function is_attandance_exists($class_id, $user_id, $assmnt_date) {
        $cnt = $this->db->query("select count(*) as cnt from class_attendance where class_id = ? and user_id = ? and class_assmnt_date = ?", array($class_id, $user_id, $assmnt_date))->row()->cnt;
        return $cnt > 0;
    }

    public function trainee_user_list_autocomplete($tax_code = NULL) {
        $matches = array();

        if (!empty($tax_code)) {

            $this->db->select('pers.user_id, usr.user_name, pers.first_name, pers.last_name, usr.tax_code');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr', 'usr.user_id=pers.user_id');
            $this->db->where('usr.account_type', 'INTUSR');
            $this->db->where('usr.tenant_id', $this->session->userdata('tenantDetails')->tenant_id);
            $this->db->like('usr.tax_code', $tax_code, 'both');
            $results = $this->db->get()->result();
            //echo $this->db->last_query();

            foreach ($results as $result) {
                $matches[$result->tax_code] = $result->user_name . '(' . $result->tax_code . ')';
            }
        }
        return $matches;
    }

    public function get_trainee_details($taxcode) {
        if ($taxcode) {
            $this->db->select('pers.user_id, pers.first_name, pers.last_name, pers.gender, pers.dob, usr.registration_date');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr', 'usr.user_id=pers.user_id');
            $this->db->where('usr.account_type', 'TRAINE');
            $this->db->where('usr.tenant_id', $this->session->userdata('tenantDetails')->tenant_id);
            $this->db->where('usr.tax_code', $taxcode);
            $results = $this->db->get()->result_array();
            return $results[0];
        }
    }

    /**
     * Function to get all trainee details
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function get_all_trainee_details($tenant_id, $taxcode, $class_id) {
        $this->db->select('pers.user_id, pers.first_name, pers.last_name, pers.gender, pers.dob, usr.registration_date, usr.tax_code');
        $this->db->from('tms_users_pers pers');
        $this->db->join('tms_users usr', 'usr.user_id=pers.user_id');
        if ($taxcode) {
            $this->db->like('usr.tax_code', $taxcode, 'both');
        }
        if ($class_id) {
            $this->db->join('class_enrol ce', 'ce.user_id=pers.user_id');
            $this->db->where('ce.class_id', $class_id);
            $this->db->where('ce.enrol_status', 'ENRLACT');
        }
        $this->db->where('usr.account_type', 'TRAINE');
        $this->db->where('usr.tenant_id', $tenant_id);
        $results = $this->db->get()->result_object();
        return $results;
    }

    /**
     * function to get all the class details
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function get_active_class_enrol($tenant_id, $course_id, $trainee_id) {
        $cur_date = date('Y-m-d H:i:s');
        $this->db->select('cc.class_name, cc.class_id, c.crse_name, c.course_id, c.crse_name, cc.class_start_datetime, cc.class_end_datetime')
                ->from('class_enrol ce')->join('course_class cc', 'cc.class_id=ce.class_id')
                ->join('course c', 'c.course_id=cc.course_id')->where('cc.class_end_datetime >=', $cur_date)
                ->where('ce.tenant_id', $tenant_id);
        if (!empty($trainee_id)) {
            $this->db->where('ce.user_id', $trainee_id);
            $this->db->where('ce.enrol_status', 'ENRLACT');
        }
        if (!empty($course_id)) {
            $this->db->where('cc.course_id', $course_id);
        }
        $result = $this->db->get()->result_object();
        return $result;
    }

    /**
     * function to get reschedule class details
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function get_reschedule_class_enrol($tenant_id, $course_id, $active_ids) {
        $cur_date = date('Y-m-d H:i:s');
        $this->db->select('cc.class_name, cc.class_id, c.crse_name, c.course_id, c.crse_name, cc.class_start_datetime, cc.class_end_datetime')
                ->from('course_class cc')
                ->join('course c', 'c.course_id=cc.course_id')
                ->where('cc.class_start_datetime >', $cur_date)
                ->where('c.tenant_id', $tenant_id);
        if (!empty($active_ids)) {
            $this->db->where_not_in('cc.class_id', $active_ids);
        }
        if (!empty($course_id)) {
            $this->db->where('cc.course_id', $course_id);
        }
        $result = $this->db->get()->result_object();
        return $result;
    }

    public function get_class_details($classid) {
        if ($classid) {
            $this->db->select('pers.user_id, pers.first_name, pers.last_name, pers.gender, pers.dob, usr.registration_date');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr', 'usr.user_id=pers.user_id');
            $this->db->where('usr.account_type', 'TRAINE');
            $this->db->where('usr.tenant_id', $this->tenant_id);
            $this->db->where('usr.tax_code', $taxcode);
            $results = $this->db->get()->result_array();
            return $results[0];
        }
    }

    /*
     * This method gets the user details for a user based on the tenant
     * Author : Sankar
     * Date: 25 Aug 2014
     */

    public function get_user_details($tenant_id, $user_id) {
        $this->db->select('*');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers', 'usr.user_id = pers.user_id and usr.tenant_id=pers.tenant_id');
        $this->db->where_in('usr.user_id', $user_id);
        $this->db->where('usr.tenant_id', $tenant_id);
        $qry = $this->db->get();
        return $qry->row();
    }

    /**
     * function to get  all invoice
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_invoice($tenant_id, $invoice) {
        $this->db->select('ei.invoice_id,tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->like('ei.invoice_id', $invoice, 'both');
        return $this->db->get()->result_object();
    }

    /**
     * function to get not paid invoice
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_notpaid_invoice($tenant_id, $invoice) {
        $this->db->select('ei.invoice_id,tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where_not_in('ce.payment_status', 'PAID')
                ->like('ei.invoice_id', $invoice, 'both');
        return $this->db->get()->result_object();
    }

    /**
     * function to get not paid invoice
     * author: sankar
     * date: 28 aug 2014
     */
    public function get_paid_invoice($tenant_id, $invoice) {

        $this->db->select('ei.invoice_id,tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->join('enrol_pymnt_due epd', 'epd.pymnt_due_id=ei.pymnt_due_id')
                ->join('enrol_paymnt_recd epr', 'epr.invoice_id=ei.invoice_id')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where('ce.payment_status', 'PAID')
                ->like('ei.invoice_id', $invoice, 'both');
        $this->db->group_by('tup.user_id');
        return $this->db->get()->result_object();
    }

    /* (*
     * function created to get trainee name
     * Author: Sankar
     * date: 27 Aug 2014
     */

    public function get_trainee_name($invoice_id, $taxcode_id, $trainee_id, $tenant_id) {
        $this->db->select('tup.first_name as first, tup.last_name as last')
                ->from('class_enrol ce')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('tu.account_type', 'TRAINE');
        if ($invoice_id) {
            $this->db->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id');
            $this->db->where('ei.invoice_id', $invoice_id);
        }
        if ($taxcode_id) {
            if (empty($invoice_id)) {
                $this->db->where('tu.user_id', $taxcode_id);
            } else {
                $this->db->or_where('tu.user_id', $taxcode_id);
            }
        }
        if ($trainee_id) {
            if (empty($invoice_id) && empty($taxcode_id)) {
                $this->db->where('tu.user_id', $trainee_id);
            } else {
                $this->db->or_where('tu.user_id', $trainee_id);
            }
        }
        return $this->db->get()->row();
    }

    /**
     * function to get current gst
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function get_gst_current() {
        $result = $this->db->select('gst_rate')->from('gst_rates')->where('is_current', 1)->get()->row()->gst_rate;
        return $result;
    }

    /**
     * function to get discount calculation
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function calculate_discount_for_userid($trainee_id, $payid) {
        //calculating the discount
        if ($trainee_id) {
            //Discount priority- individual, company, class
            $individual = $this->db->select('individual_discount')->from('tms_users_pers')->where('user_id', $trainee_id)
                            ->get()->row()->individual_discount;
            $company = $this->db->select('tc.comp_discount')->from('tenant_company_users tcu')
                            ->join('tenant_company tc', 'tc.company_id=tcu.company_id')->where('tcu.user_id', $trainee_id)
                            ->get()->row()->comp_discount;
            $class = $this->db->select('cc.class_discount')->from('class_enrol ce')
                            ->join('course_class cc', 'cc.class_id=ce.class_id')
                            ->where('ce.user_id', $trainee_id)->where('ce.pymnt_due_id', $payid)
                            ->get()->row()->class_discount;
            if (!empty($individual)) {
                return array('discount_label' => 'Individual', 'discount_rate' => $individual);
            } elseif (!empty($company)) {
                return array('discount_label' => 'Company', 'discount_rate' => $company);
            } elseif (!empty($class)) {
                return array('discount_label' => 'class', 'discount_rate' => $class);
            }
        }
    }

    /**
     * function to get not paid invoice
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_user($tenant_id, $taxcode, $username) {
        $this->db->select('tup.user_id, tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where('tu.account_type', 'TRAINE');
        if (!empty($taxcode)) {
            $this->db->like('tu.tax_code', $taxcode, 'both');
        } elseif (!empty($username)) {
            $this->db->like('tup.first_name', $username, 'both');
        }
        $this->db->group_by('tup.user_id');
        return $this->db->get()->result_object();
    }

    /**
     * function to get not paid invoice
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_notpaid_user($tenant_id, $taxcode, $username) {
        $this->db->select('tup.user_id, tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where_not_in('ce.payment_status', 'PAID')
                ->where('tu.account_type', 'TRAINE');
        if (!empty($taxcode)) {
            $this->db->like('tu.tax_code', $taxcode, 'both');
        } elseif (!empty($username)) {
            $this->db->like('tup.first_name', $username, 'both');
        }
        $this->db->group_by('tup.user_id');
        return $this->db->get()->result_object();
    }

    /**
     * function to get not paid invoice
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_paid_user($tenant_id, $taxcode, $username) {
        $this->db->select('tup.user_id, tup.first_name, tup.last_name, tu.tax_code')
                ->from('class_enrol ce')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->join('enrol_paymnt_recd epr', 'epr.invoice_id=ei.invoice_id')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where('ce.payment_status', 'PAID')
                ->where('tu.account_type', 'TRAINE');
        if (!empty($taxcode)) {
            $this->db->like('tu.tax_code', $taxcode, 'both');
        } elseif (!empty($username)) {
            $this->db->like('tup.first_name', $username, 'both');
        }
        $this->db->group_by('tup.user_id');
        return $this->db->get()->result_object();
    }

    /**
     * calculate Net Due
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function calculate_net_due($gst_onoff, $subsidy_after_before, $feesdue, $subsidy, $gst_rate) {
        if ($gst_onoff == 1) {
            if ($subsidy_after_before == 'GSTBSD') {//
                //deduct subsidy before applying goods and services tax
                return (($feesdue + ($feesdue * $gst_rate)) - $subsidy);
            } else {
                //deduct subsidy after applying goods and services tax
                $feesduetemp = ($feesdue - $subsidy);
                return ( $feesduetemp + ($feesduetemp * $gst_rate));
            }
        }
    }

    /**
     * Get GST Amount
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function calculate_gst($gst_onoff, $subsidy_after_before, $feesdue, $subsidy, $gst_rate) {
        return $feesdue;
        if ($gst_onoff == 1) {
            if ($subsidy_after_before == 'GSTBSD') {//
                //deduct subsidy before applying goods and services tax
                return ($feesdue * $gst_rate );
            } else {
                //deduct subsidy after applying goods and services tax
                $feesduetemp = ($feesdue - $subsidy);
                return ($feesduetemp * $gst_rate);
            }
        }
    }

    /**
     * get enrol_invoice ##enrollment
     * author: sankar
     * date: 27 aug 2014
     */
    public function get_enroll_invoice($payid) {
        $result = $this->db->select('*')->
                        from('enrol_invoice ei')
                        ->join('class_enrol ce', 'ce.pymnt_due_id=ei.pymnt_due_id')
                        ->join('enrol_pymnt_due epd', 'epd.pymnt_due_id=ce.pymnt_due_id')
                        ->join('course_class cc', 'cc.class_id=ce.class_id')
                        ->join('course c', 'c.course_id=cc.course_id')
                        ->join('tms_users tu', 'tu.user_id=ce.user_id')
                        ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                        ->join('tenant_company_users tcu', 'tcu.user_id=tup.user_id')
                        ->join('tenant_master tm', 'tm.tenant_id=ce.tenant_id')
                        ->where('ei.pymnt_due_id', $payid)
                        ->get()->row();
        return $result;
    }

    /**
     * function to get trainee paid details
     * Author: Sankar
     * Date: 27 aug 2014
     */
    public function get_invoice_paid_details($invoice_id) {
        $result = $this->db->select('epr.recd_on, epr.mode_of_pymnt,epr.amount_recd, epr.cheque_number, epr.cheque_date')
                        ->from('enrol_paymnt_recd epr')
                        ->where('epr.invoice_id', $invoice_id)->get()->result_object();
        return $result;
    }

    /**
     * function to get trainee paid details
     * Author: Sankar
     * Date: 27 aug 2014
     */
    public function get_refund_paid_details($invoice_id) {
        $result = $this->db->select('er.refund_on, er.mode_of_refund, er.amount_refund, er.cheque_number, er.cheque_date')
                        ->from('enrol_refund er')
                        ->where('er.invoice_id', $invoice_id)->get()->result_object();
        return $result;
    }

    /**
     * function to get trainee id from payment_due_id
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function get_trainee_by_pymnt_due_id($payment_due_id) {
        $result = $this->db->select('epd.user_id, tup.first_name, tup.last_name, tup.gender')
                ->from('enrol_pymnt_due epd')
                ->join('tms_users_pers tup', 'tup.user_id=epd.user_id')
                ->where('epd.pymnt_due_id', $payment_due_id)->get()
                ->row();
        return $result;
    }

    /**
     * function to post refund payment for a trainee
     * Author: Sankar
     * Date: 29 Aug 2014
     */
    public function refund_payment_post($tenant_id, $user_id) {
        extract($_POST);
        $invoice_id = $this->db->select('invoice_id')->from('enrol_invoice')->where('pymnt_due_id', $payment_due_id)->get()->row()->invoice_id;
        if (!empty($invoice_id)) {
            if ($payment_type == 'CASH') {
                $data = array(
                    'invoice_id' => $invoice_id,
                    'refund_on' => date('Y-m-d H:i:S', strtotime($refund_date)),
                    'mode_of_refund' => $payment_type,
                    'amount_refund' => $cash_amount,
                    'cheque_number' => NULL,
                    'cheque_date' => NULL,
                    'bank_name' => NULL,
                    'refnd_reason' => $refund_reason,
                    'refnd_reason_ot' => $other_reason,
                    'refund_by' => $user_id,
                );
            } elseif ($payment_type == 'CHQ') {
                $data = array(
                    'invoice_id' => $invoice_id,
                    'refund_on' => date('Y-m-d H:i:S', strtotime($refund_date)),
                    'mode_of_refund' => $payment_type,
                    'amount_refund' => $cheque_amount,
                    'cheque_number' => $cheque_number,
                    'cheque_date' => date('Y-m-d', strtotime($cheque_date)),
                    'bank_name' => $bank_name,
                    'refnd_reason' => $refund_reason,
                    'refnd_reason_ot' => $other_reason,
                    'refund_by' => $user_id,
                );
            }
            $this->db->insert('enrol_refund', $data);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * function to update the posted Payment values
     * Author: Sankar
     * Date: 27 Aug 2014
     */
    public function update_payment_post($tenant_id, $user_id) {
        extract($_POST);
        $invoice_id = $this->db->select('invoice_id')->from('enrol_invoice')->where('pymnt_due_id', $payment_due_id)->get()->row()->invoice_id;
        $trainee_id = $this->get_trainee_by_pymnt_due_id($payment_due_id)->user_id;
        if (!empty($invoice_id)) {
            if ($payment_type == 'CASH') {
                $data = array(
                    'invoice_id' => $invoice_id,
                    'recd_on' => date('Y-m-d H:i:S', strtotime($cashpaid_on)),
                    'mode_of_pymnt' => $payment_type,
                    'amount_recd' => $cash_amount,
                    'cheque_number' => NULL,
                    'cheque_date' => NULL,
                    'bank_name' => NULL,
                    'recd_by' => $user_id,
                );
                $breakup_data = array(
                    'invoice_id' => $invoice_id,
                    'user_id' => $trainee_id,
                    'amount_recd' => $cash_amount
                );
            } elseif ($payment_type == 'CHQ') {
                $data = array(
                    'invoice_id' => $invoice_id,
                    'recd_on' => date('Y-m-d H:i:S', strtotime($paid_on)),
                    'mode_of_pymnt' => $payment_type,
                    'amount_recd' => $cheque_amount,
                    'cheque_number' => $cheque_number,
                    'cheque_date' => date('Y-m-d', strtotime($cheque_date)),
                    'bank_name' => $bank_name,
                    'recd_by' => $user_id,
                );
                $breakup_data = array(
                    'invoice_id' => $invoice_id,
                    'user_id' => $trainee_id,
                    'amount_recd' => $cheque_amount
                );
            }
            $this->db->insert('enrol_paymnt_recd', $data);
            $this->db->insert('enrol_pymnt_brkup_dt', $breakup_data);
            $data = array('payment_status' => 'PAID');
            $this->db->where('tenant_id', $tenant_id);
            $this->db->where('pymnt_due_id', $payment_due_id);
            $this->db->update('class_enrol', $data);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * this method to search trainee users
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function search_trainee_updatepayment($invoice_id, $taxcode_id, $trainee_id, $tenant_id) {
        $this->db->select('ce.pymnt_due_id as payid, tup.first_name as first, tup.last_name as last,
                ei.total_inv_amount as amountdue,tu.tax_code as taxcode, cc.class_name, c.crse_name')
                ->from('class_enrol ce')
                ->join('course_class cc', 'cc.class_id=ce.class_id')
                ->join('course c', 'c.course_id=cc.course_id')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->join('enrol_pymnt_due epd', 'epd.pymnt_due_id=ei.pymnt_due_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where_not_in('ce.payment_status', 'PAID')
                ->where('tu.account_type', 'TRAINE');
        if ($invoice_id) {
            $this->db->where('ei.invoice_id', $invoice_id);
        }
        if ($taxcode_id) {
            if (empty($invoice_id)) {
                $this->db->where('tu.user_id', $taxcode_id);
            } else {
                $this->db->or_where('tu.user_id', $taxcode_id);
            }
        }
        if ($trainee_id) {
            if (empty($invoice_id) && empty($taxcode_id)) {
                $this->db->where('tu.user_id', $trainee_id);
            } else {
                $this->db->or_where('tu.user_id', $trainee_id);
            }
        }
        return $this->db->get()->result_object();
    }

    /**
     * this method to search trainee invoice
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function search_trainee_invoice($invoice_id, $taxcode_id, $trainee_id, $tenant_id) {
        $this->db->select('ce.pymnt_due_id as payid, tup.first_name as first, tup.last_name as last,
                ei.total_inv_amount as amountdue,tu.tax_code as taxcode, cc.class_name, c.crse_name')
                ->from('class_enrol ce')
                ->join('course_class cc', 'cc.class_id=ce.class_id')
                ->join('course c', 'c.course_id=cc.course_id')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->join('enrol_pymnt_due epd', 'epd.pymnt_due_id=ei.pymnt_due_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where('tu.account_type', 'TRAINE');
        if ($invoice_id) {
            $this->db->where('ei.invoice_id', $invoice_id);
        }
        if ($taxcode_id) {
            if (empty($invoice_id)) {
                $this->db->where('tu.user_id', $taxcode_id);
            } else {
                $this->db->or_where('tu.user_id', $taxcode_id);
            }
        }
        if ($trainee_id) {
            if (empty($invoice_id) && empty($taxcode_id)) {
                $this->db->where('tu.user_id', $trainee_id);
            } else {
                $this->db->or_where('tu.user_id', $trainee_id);
            }
        }
        return $this->db->get()->result_object();
    }

    /**
     * this method to search trainee users
     * Author: Sankar
     * Date: 25 Aug 2014
     */
    public function search_trainee_refundpayment($invoice_id, $taxcode_id, $trainee_id, $tenant_id) {
        $this->db->select('ce.pymnt_due_id as payid, tup.first_name as first, tup.last_name as last,
                ei.total_inv_amount as amountdue,tu.tax_code as taxcode, cc.class_name, c.crse_name')
                ->from('class_enrol ce')
                ->join('course_class cc', 'cc.class_id=ce.class_id')
                ->join('course c', 'c.course_id=cc.course_id')
                ->join('tms_users tu', 'tu.user_id=ce.user_id')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->join('enrol_invoice ei', 'ei.pymnt_due_id=ce.pymnt_due_id')
                ->join('enrol_pymnt_due epd', 'epd.pymnt_due_id=ei.pymnt_due_id')
                ->join('enrol_paymnt_recd epr', 'epr.invoice_id=ei.invoice_id')
                ->where('ce.tenant_id', $tenant_id)
                ->where('ce.enrol_status', 'ENRLACT')
                ->where('ce.payment_status', 'PAID')
                ->where('tu.account_type', 'TRAINE');
        if ($invoice_id) {
            $this->db->where('ei.invoice_id', $invoice_id);
        }
        if ($taxcode_id) {
            if (empty($invoice_id)) {
                $this->db->where('tu.user_id', $taxcode_id);
            } else {
                $this->db->or_where('tu.user_id', $taxcode_id);
            }
        }
        if ($trainee_id) {
            if (empty($invoice_id) && empty($taxcode_id)) {
                $this->db->where('tu.user_id', $trainee_id);
            } else {
                $this->db->or_where('tu.user_id', $trainee_id);
            }
        }
        return $this->db->get()->result_object();
    }

    /*
     * This method gets the user details for a user based on the tenant
     * Author : Sankar
     * Date: 25 Aug 2014
     */

    public function get_users_details($tenant_id, $user_id) {
        $this->db->select('*');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers', 'usr.user_id = pers.user_id and usr.tenant_id=pers.tenant_id');
        $this->db->where_in('usr.user_id', $user_id);
        $this->db->where('usr.tenant_id', $tenant_id);
        $qry = $this->db->get();
        return $qry->result_object();
    }

    /**
     * method to do reschedule
     * Author: Sankar
     * Date: 26 Aug 2014
     */
    public function create_reschedule() {
        $tenant_id = $this->session->userdata('userDetails')->tenant_id;
//        echo "<pre>";
//        print_r($_POST);
//        echo "</pre>";
//        die;
        extract($_POST);
        if ($type == 1) {
            $user_id = $taxcode_id;
            $active_class = $active_class;
            $reschedule_class = $reschedule_class;
        } else {
            echo $user_id = implode(',', $control_6);
//            die;
            $active_class = $course_active_class;
            $reschedule_class = $course_reschedule_class;
        }
        $reschedule_reason = $reschedule_reason;
        $other_reason = $other_reason;
        if (!empty($user_id)) {
            $user = explode(',', $user_id);
            foreach ($user as $row) {
                $data = $this->db->select('*')->from('class_enrol')->where('user_id', $row)->where('tenant_id', $tenant_id)
                                ->where('class_id', $active_class)->get()->row_array();
                $course_id = $this->db->select('course_id')->from('course_class')->where('class_id', $reschedule_class)->get()->row()->course_id;
                $data['course_id'] = $course_id;
                $data['class_id'] = $reschedule_class;
                $data['enrol_status'] = 'ENRLACT';
                $data['rescheduled_class_id'] = '';
                $data['rescheduled_reason'] = '';
                $data['rescheduled_reason_oth'] = '';
                $this->db->insert('class_enrol', $data);

                $this->db->where('user_id', $row);
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('class_id', $active_class);
                $resch_arr = array(
                    'rescheduled_reason' => $reschedule_reason,
                    'rescheduled_reason_oth' => $other_reason,
                    'rescheduled_class_id' => $reschedule_class,
                    'enrol_status' => 'RESHLD');
                $this->db->update('class_enrol', $resch_arr);
            }
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * created by sankar
     */
    public function get_trainee_classes($tenant_id, $course, $trainee_id, $taxcode_id) {
        if ($trainee_id) {
            $class_not_in = $this->db->select('class_id')->from('class_enrol')->where('user_id', $trainee_id)->get()->result_array();
        }
        if ($taxcode_id) {
            $class_not_in = $this->db->select('class_id')->from('class_enrol')->where('user_id', $taxcode_id)->get()->result_array();
        }
        $class_arr = array();
        foreach ($class_not_in as $row) {
            $class_arr[] = $row['class_id'];
        }
        $cur_date = date('Y-m-d H:i:s');
        $this->db->select('cc.class_id, cc.class_name')
                ->from('course_class cc')->where('cc.tenant_id', $tenant_id)->where('cc.course_id', $course);
        if ($trainee_id && !empty($class_arr)) {
//            $this->db->join('class_enrol ce', 'ce.class_id=cc.class_id')->where_not_in('ce.user_id', $trainee_id);

            $this->db->where_not_in('cc.class_id', $class_arr);
        }
        if ($taxcode_id && !empty($class_arr)) {
//            $this->db->join('class_enrol ce', 'ce.class_id=cc.class_id')->where_not_in('ce.user_id', $taxcode_id);

            $this->db->where_not_in('cc.class_id', $class_arr);
        }
        $this->db->where('cc.class_start_datetime >', $cur_date);
        return $this->db->group_by('cc.class_id')->get()->result_object();
    }

    /**
     * created by sankar
     */
    public function check_userenroll($user_id, $class) {
        $exists = $this->db->select('class_id')->get_where('class_enrol', array('class_id' => $class, 'user_id' => $user_id), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
    }

    /**
     * created by sankar
     */
    public function get_alluser($tenant_id, $username, $taxcode) {
        $this->db->select('tup.user_id, tup.first_name, tup.last_name, tu.tax_code')
                ->from('tms_users tu')
                ->join('tms_users_pers tup', 'tup.user_id=tu.user_id')
                ->where('tu.tenant_id', $tenant_id)
                ->where('tu.account_type', 'TRAINE');
        if (!empty($taxcode)) {
            $this->db->like('tu.tax_code', $taxcode, 'both');
        } elseif (!empty($username)) {
            $this->db->like('tup.first_name', $username, 'both');
        }
        $this->db->group_by('tup.user_id');
        return $this->db->get()->result_object();
    }

}

?>