<?php

/*
  * This is the Model class for Internal Users
  * Author : Jaison Jose
  * Date created : 24 July 2014
  */

class Internal_User_Model extends CI_Model {
    /* 
         * This method gets count for the internal user list for a tenant (Used in pagination)
         * Author : Mir
	 */    
    public function __construct() {
        parent::__construct();       
        $this->load->library('bcrypt');
        $this->load->helper('common');
    }
    
    public function get_internal_user_count_by_tenant_id($tenant_id){
        if (empty($tenant_id)) {
            return 0;
        }
        $this->db->select('count(*) as totalrows');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
            . 'AND usr.user_id = pers.user_id');
        $this->db->join('internal_user_role irole', 'usr.user_id = irole.user_id');
        $this->db->join('tms_roles role', 'irole.tenant_id = role.tenant_id '
            . 'AND irole.role_id = role.role_id');
        $this->db->where('usr.tenant_id', $tenant_id);
        $this->db->where('usr.account_type', 'INTUSR');

        $result = $this->db->get()->result();

        return $result[0]->totalrows;
    }
    
/**
 * Get the list of internal users
 * @param string $tenant_id
 * @param int $limit
 * @param int $offset
 * @param string $sort_by
 * @param string $sort_order
 * @return array
 * Author : Mir
 */    
public function get_internal_user_list($tenant_id, $limit = NULL, $offset = NULL, $sort_by = NULL, $sort_order = NULL) 
{
    //created  by Bineesh for search option start
        $user_role='';
        $first_last_name='';
        $filter_status='';
        if($this->input->post('user_role')){
            $user_role = $this->input->post('user_role');
        }
        if($this->input->post('first_last_name')){
            $first_last_name = $this->input->post('first_last_name');
        }
        if($this->input->post('filter_status')){
            $filter_status = $this->input->post('filter_status');
        }
    //created  by Bineesh for search option end
        if ($offset <= 0 || empty($tenant_id)) {
            return;
        }
        $this->db->select('usr.user_id, usr.tax_code, usr.account_status, pers.first_name, '
            . 'pers.last_name, role.role_name');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
            . 'AND usr.user_id = pers.user_id');
        $this->db->join('internal_user_role irole', 'usr.user_id = irole.user_id');
        $this->db->join('tms_roles role', 'irole.tenant_id = role.tenant_id '
            . 'AND irole.role_id = role.role_id');
        $this->db->where('usr.tenant_id', $tenant_id);
        $this->db->where('usr.account_type', 'INTUSR');
    //created  by Bineesh for search option start
        if($user_role!=''){
            $this->db->like('role.role_id', $user_role); 
        }
        if($first_last_name!=''){
            $this->db->like('pers.first_name', $first_last_name);  
            $this->db->or_like('pers.last_name', $first_last_name);  
        }
        if($filter_status != '' && $filter_status != 'All' ){
            $this->db->where('usr.account_status', $filter_status);
        }
    //created  by Bineesh for search option end
        if($sort_by) {  
           $this->db->order_by($sort_by, $sort_order);  
        }else {
           $this->db->order_by('usr.last_modified_on', 'DESC'); 
        }
        if ($limit == $offset) {
            $this->db->limit($offset); 
        }
        else if($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);  
        }
        $query = $this->db->get();    
        return $query->result_array();   
}
 
 
 
/*
 * This function is used to export all the internal users for a tenant displayed in the list view
 * Author : Jaison Jose
 * Aug 04 2014
 */

public function get_internal_user_list_export($tenantId) {             
  //Changed by Ukraine    
               $query = "SELECT  *
FROM tms_users usr, tms_users_pers pers, internal_user_role role, tms_roles rl, internal_user_emp_detail
WHERE usr.tenant_id = pers.tenant_id
AND usr.user_id = pers.user_id
AND usr.tenant_id = role.tenant_id
AND usr.user_id = role.user_id
AND usr.user_id = internal_user_emp_detail.user_id
AND role.role_id = rl.role_id
AND role.tenant_id = rl.tenant_id
AND usr.account_type = 'INTUSR' AND usr.tenant_id='$tenantId'" ;

        return $query;
    }
    /*
         * This function is used to get the user role for a tenant.
         * Author: JAISON JOSE
         */    
        public function get_user_role($tenant_id){
            return $this->db->where('tenant_id', $tenant_id)->get('tms_roles')->result();
        }
        
    /**
     * function to save the user data
     * @param object $user logged in user(creator)     
     * @return boolean
     */      
    public function save_user_data($user) {
        foreach($this->input->post() as $key => $value) {
            $$key = $value;
        }

        $dateTime = date('Y-m-d H:i:s');
        $other_identi_type = NULL;
        $other_identi_code = NULL;
        
        if($country_of_residence == 'IND'){
            $tax_code_type = 'PAN';
            $tax_code = $PAN;
        }
        if($country_of_residence == 'SGP'){
            $tax_code_type = $NRIC;
            $tax_code = $NRIC_ID;
            if($NRIC == "OTHERS") {
                $other_identi_type = $NRIC_OTHER;
                $other_identi_code = $tax_code;
            }
        }
        if($country_of_residence == 'USA'){
            $tax_code_type = 'SSN';
            $tax_code = $SSN;
        } 
    // Added by Bineesh - Aug 23 2014
        $password= NULL;
        $encrypted_password=NULL;
        if($activate_user == 'ACTIVE') {
            $password = random_key_generation();
            $encrypted_password = $this->bcrypt->hash_password($password);
            $acct_acti_date_time = $dateTime;
        }else {
            $acct_acti_date_time = '0000-00-00 00:00';            
        }            
        //get db format date
        $pers_dob= formated_date($pers_dob,'/');
        $emp_doj= formated_date($emp_doj,'/');


        $tms_users_data = array(
        'tenant_id' => $user->tenant_id,
        'account_type' => 'INTUSR',
        'registration_mode' => 'INTUSR',
        'friend_id' => NULL,
        'registration_date' => $dateTime,
        'user_name' => $user_name,
        'tenant_org_id' => '',
        'password' => $encrypted_password,
        'acc_activation_type' => 'BPEMAC',
        'activation_key' => NULL,
        'registered_email_id' => $user_registered_email,
        'country_of_residence' => $country_of_residence,
        'tax_code_type' => $tax_code_type,
        'tax_code' => $tax_code,
        'other_identi_type' => $other_identi_type,
        'other_identi_code' => $other_identi_code,
        'other_identi_upload' => '',
        'acct_acti_date_time' => $acct_acti_date_time,
        'acct_deacti_date_time' => NULL,
        'account_status' => $activate_user,
        'deacti_reason' => NULL,
        'deacti_reason_oth' => NULL,
        'deacti_by' => NULL,
        'created_by' => $user->user_id,
        'created_on' => $dateTime,
        'last_modified_by' => NULL,
        'last_modified_on' => $dateTime,
        'last_login_date_time' => NULL,
        'last_ip_used' => NULL,
        'pwd_last_chgd_on' => NULL
        );
        $this->db->insert('tms_users', $tms_users_data);
        $user_id = $this->db->insert_id();

        $tms_users_pers_data = array(
        'tenant_id' => $user->tenant_id,
        'user_id' => $user_id,
        'first_name' => $pers_first_name,
        'last_name' => $pers_last_name,
        'gender' => $pers_gender,
        'dob' => $pers_dob,
        'alternate_email_id' => $pers_alternate_email,
        'contact_number' => $pers_contact_number,
        'alternate_contact_number' => $pers_alternate_contact_number,
        'race' => NULL,
        'salary_range' => NULL,
        'personal_address_bldg' => $pers_personal_address_bldg,
        'personal_address_city' => $pers_city,
        'personal_address_state' => $pers_states,
        'personal_address_country' => $pers_country,
        'personal_address_zip' => $pers_zip,
        'photo_upload_path' => NULL,
        'individual_discount' => NULL,
        'certificate_pick_pref' => NULL,
        'indi_setting_list_size' => NULL
        );
        $this->db->insert('tms_users_pers', $tms_users_pers_data);


        $internal_user_emp_details_data = array(
        'tenant_id' => $user->tenant_id,
        'user_id' => $user_id,
        'company_name' => $emp_company_name,
        'doj' => $emp_doj,
        'designation' => $emp_designation,
        'off_email_id' => $emp_email,
        'off_contact_number' => $emp_contact_number,
        'off_address_bldg' => $emp_address,
        'off_address_city' => $emp_city,
        'off_address_state' => $emp_states,
        'off_address_country' => $emp_country,
        'off_address_zip' => $emp_zip
        );
        $this->db->insert('internal_user_emp_detail', $internal_user_emp_details_data);

        $internal_user_role = array(
        'tenant_id' => $user->tenant_id,
        'user_id' => $user_id,
        'role_id' => $user_role
        );
        $status=$this->db->insert('internal_user_role', $internal_user_role); 
        //Generate account creation mail - Added By Bineesh - Aug 23 2014
        if ($activate_user == 'ACTIVE' && $status){            
            $user_details = array('username' => $user_name, 
                        'email' => $user_registered_email, 'password' => $password,
                        'firstname' => $pers_first_name,'lastname' => $pers_last_name,
                        'gender' => $pers_gender);
            $this->internal_user_send_mail($user_details);            
        }        
        return TRUE;
    }
    /**
     * send mail to the internal user containing password.
     * @param array $user.
     * Author : Bineesh.
     * Date: 23 Aug 2014.
     * return boolean
     */
    public function internal_user_send_mail($user) {        
        if ($user['username'] && $user['password'] && $user['email']) {
            $tenant_details=fetch_tenant_details($this->session->userdata('userDetails')->tenant_id);
            $footer_data=str_replace("<Tenant_Company_Name>", $tenant_details->tenant_name, MAIL_FOOTER);        
            $subject = 'Your Account Creation Acknowledgment'; 
            $body = NULL;
            if ($user['gender'] == 'MALE'){
                $body ="Dear Mr.".$user['firstname'].' '.$user['lastname'].',';
            }else{
                $body ="Dear Ms.".$user['firstname'].' '.$user['lastname'].',';            
            }                  
            $body .=  '<br/><br/>&nbsp;&nbsp;Thank you for registering with us. Your account has been successfully created.<br/><br/>';
            $body .= "<strong>&nbsp;&nbsp;Your username:</strong> ". $user['username'] ."<br/>";
            $body .= "<strong>&nbsp;&nbsp;Your password:</strong> ". $user['password']."<br/><br/>";
            $body .= $footer_data;            
            return send_mail($user['email'], '', $subject, $body);
        }
        
        return FALSE;
    }

        
     /*
         * This function is used to populate the data.
         * Author: siddappa
         */
    public function get_states($country_param){
        $sql = $this->db->where('parameter_id',$country_param)->get('metadata_values')->row();
        if($sql->child_category_id){
            $query = $this->db->where('category_id',$sql->child_category_id)->get('metadata_values');
            return $query->result();
        }else {
            $querys = $this->db->where('parameter_id',$country_param)->get('metadata_values');
            return $querys->result();
        }
    } 
    
    /*
     * This method gets the user details for a user based on the tenant
     * Author : Jaison Jose
     */
    public function get_user_details($tenant_id, $user_id)
    {   
        $this->db->select('*');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers','usr.user_id = pers.user_id and usr.tenant_id = pers.tenant_id');
        $this->db->join('internal_user_emp_detail emp','usr.user_id = emp.user_id and usr.tenant_id = emp.tenant_id');
        $this->db->join('internal_user_role role','usr.user_id = role.user_id and usr.tenant_id = role.tenant_id');        
        $this->db->where('usr.user_id', $user_id);
      //  $this->db->where_not_in('usr.account_status','INACTIV');
        $this->db->where('usr.tenant_id', $tenant_id);        

        $qry = $this->db->get();          
        if($qry->num_rows()>0){
            return $qry->row();
        }else{
            return false;
        }        
    }
    

        /*
         * This function is used to get the role name based on the role ID
         * MOVE to GENERIC CLASS
         * Author: JAISON JOSE
         */
        public function get_user_role_name($role_id){
            return $this->db->select('role_name')->where('role_id', $role_id)->get('tms_roles')->row();
        }    
        
        
        public function internal_user_list_autocomplete($search_firstname = NULL) {
        $matches = array();
        //TO DO:CHECK TENAT ID ALSO IN QRY AND account_type=INTUSR $this->session->userdata('tenantDetails')->tenant_id ************
        if (!empty($search_firstname)) {
            $user = $this->session->userdata('userDetails');
            $tenant_id = $user->tenant_id;
            $this->db->select('usr.tax_code,pers.user_id, pers.first_name, pers.last_name');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr','usr.user_id=pers.user_id');
            $this->db->where('usr.account_type','INTUSR');
            $this->db->where('usr.tenant_id',$tenant_id);
            $this->db->where_not_in('usr.account_status','INACTIV');
            $this->db->like('pers.first_name', $search_firstname, 'both');
            $results = $this->db->get()->result();
                       
            foreach ($results as $result) {
                $matches[$result->user_id] = $result->first_name . ' ' . $result->last_name . '  Taxcode:' .$result->tax_code.'('.$result->user_id.')' ;
            }
        }
        return $matches;
    }
    
    
    
    /*
         * This function is used to update internal data (edit user)
         * Author: JAISON
         */        
        public function update_user_data() {            
            foreach($this->input->post() as $key=>$value) {
                $$key = $value;
            }
            $user = $this->session->userdata('userDetails');            
            
            $dateTime = date('Y-m-d H:i:s');
            $other_identi_type = NULL;
            $other_identi_code = NULL;
            
            if($country_of_residence == 'IND'){
                $tax_code_type = 'PAN';
                $tax_code = $PAN;
            }
            if($country_of_residence == 'SGP'){
//                $tax_code_type = 'NRIC';
//                $tax_code = $NRIC;
                
                $tax_code_type = $NRIC;
                $tax_code = $NRIC_ID;
                if($NRIC == "OTHERS") {
                    $other_identi_type = $NRIC_OTHER;
                    $other_identi_code = $tax_code;
                }
                
            }
            if($country_of_residence == 'USA'){
                $tax_code_type = 'SSN';
                $tax_code = $SSN;
            } 
            
            $tms_users_data = array(
            'registered_email_id' => $user_registered_email,            
            'country_of_residence' => $country_of_residence,
            'tax_code_type' => $tax_code_type,
            'tax_code' => $tax_code,
            'other_identi_type' => $other_identi_type,
            'other_identi_code' => $other_identi_code,
            'other_identi_upload' => '' );
            
            if($activate_user == 'ACTIVE') {                
                $tms_users_data['acct_acti_date_time'] = $dateTime;
                $tms_users_data['account_status'] = $activate_user;                
            }elseif($activate_user == 'PENDACT') {
                $tms_users_data['account_status'] = $activate_user; 
            }
            
            // Added by Bineesh - Aug 23 2014
            $password= NULL;
            $encrypted_password=NULL;
            if($activate_user!=NULL && $activate_user == 'ACTIVE') { // this means user was in pending activation and during edit status was changed to active
                $password = random_key_generation();
                $encrypted_password = $this->bcrypt->hash_password($password);
                //set password in the DB and send account creation mail
                $tms_users_data['password'] = $encrypted_password;                
            }
            
            $tms_users_data['acct_deacti_date_time'] = NULL;
            $tms_users_data['deacti_reason'] = NULL;
            $tms_users_data['deacti_reason_oth'] = NULL;
            $tms_users_data['deacti_by'] = NULL;
            $tms_users_data['last_modified_by'] = $user->user_id;
            $tms_users_data['last_modified_on'] = $dateTime;
            
            $this->db->where('tenant_id', $user->tenant_id);
            $this->db->where('user_id', $edit_user_id);
            $this->db->update('tms_users', $tms_users_data);
           //db_format dob
            $pers_dob=formated_date($pers_dob,'/');
            $tms_users_pers_data = array(
            'first_name' => $pers_first_name,
            'last_name' => $pers_last_name,
            'gender' => $pers_gender,
            'dob' => $pers_dob,
            'alternate_email_id' => $pers_alternate_email,
            'contact_number' => $pers_contact_number,
            'alternate_contact_number' => $pers_alternate_contact_number,
            'personal_address_bldg' => $pers_personal_address_bldg,
            'personal_address_city' => $pers_city,
            'personal_address_state' => $pers_states,
            'personal_address_country' => $pers_country,
            'personal_address_zip' => $pers_zip,
            'photo_upload_path' => NULL
            );
            
            $this->db->where('tenant_id', $user->tenant_id);
            $this->db->where('user_id', $edit_user_id);            
            $this->db->update('tms_users_pers', $tms_users_pers_data);
            //db format $emp_doj
            $emp_doj = formated_date($emp_doj,'/');
            $internal_user_emp_details_data = array(
            'company_name' => $emp_company_name,
            'doj' => $emp_doj,
            'designation' => $emp_designation,
            'off_email_id' => $emp_email,
            'off_contact_number' => $emp_contact_number,
            'off_address_bldg' => $emp_address,
            'off_address_city' => $emp_city,
            'off_address_state' => $emp_states,
            'off_address_country' => $emp_country,
            'off_address_zip' => $emp_zip
            );
            $this->db->where('tenant_id', $user->tenant_id);
            $this->db->where('user_id', $edit_user_id);            
            $this->db->update('internal_user_emp_detail', $internal_user_emp_details_data);

            $internal_user_role = array(
            'role_id' => $user_role
            );
            $this->db->where('tenant_id', $user->tenant_id);
            $this->db->where('user_id', $edit_user_id);            
            $status = $this->db->update('internal_user_role', $internal_user_role);
        //Generate account creation mail - Added By Bineesh - Aug 23 2014            
            if( $activate_user == 'ACTIVE') {                 
                $user_details = array('username' => $user_name, 
                            'email' => $user_registered_email, 'password' => $password,
                            'firstname' => $pers_first_name,'lastname' => $pers_last_name,
                            'gender' => $pers_gender);
                $this->internal_user_send_mail($user_details);            
            }                        
        }    
        
        
        
        /*
         * checks if user name already exists (ADD USER)
         * Author: JAISON
         */
        public function check_duplicate_user_name($username) {
        $exists = $this->db->select('user_id')->get_where('tms_users', array('user_name' => $username), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }
        
        /*
         * checks if user name already exists (EDIT USER)
         * Author: JAISON
         */
        public function check_duplicate_user_name_edit($username, $username_edit) {
        $exists = $this->db->select('user_id')->where('user_name !=', $username_edit)->get_where('tms_users', array('user_name' => $username), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }
        /*
         * checks if user name already exists (ADD USER)
         * Author: JAISON
         */
        public function check_duplicate_user_email($useremail) {
        $exists = $this->db->select('user_id')->get_where('tms_users', array('registered_email_id' => $useremail), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }    
        /*
         * checks if user name already exists (EDIT USER)
         * Author: JAISON
         */
        public function check_duplicate_user_email_edit($useremail, $useremail_edit) {
        $exists = $this->db->select('user_id')->where('registered_email_id !=', $useremail_edit)->get_where('tms_users', array('registered_email_id' => $useremail), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }    
   
    
        /*
         * checks if user tax code already exists (ADD user)
         * Author: JAISON
         */
        public function check_duplicate_user_taxcode($tax_code) {
        $exists = $this->db->select('tax_code')->get_where('tms_users', array('tax_code' => $tax_code), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }    
        /*
         * checks if user tax code already exists (EDIT User)
         * Author: JAISON
         */
        public function check_duplicate_user_taxcode_edit($tax_code, $tax_code_edit) {
        $exists = $this->db->select('tax_code')->where('tax_code !=', $tax_code_edit)->get_where('tms_users', array('tax_code' => $tax_code), 1)->num_rows();
        if ($exists) {
            return FALSE;
        }
        return TRUE;
        
    }  
    
    /*
     * This function deactivates the user selectd.
     * Author: JAISON
     */
    public function deactivate_user($user_id)
    {
            foreach($this->input->post() as $key=>$value) {
                $$key = $value;
            } 
            
            if($reason_for_deactivation != 'OTHERS') {
                $other_reason_for_deactivation = '';
            }
            $user = $this->session->userdata('userDetails');            
            //$deactivation_date=formated_date($deactivation_date,'/');
            $tms_users_data = array(
            'account_status' => 'INACTIV',
            'acct_deacti_date_time' => date('yyy-mm-dd H:i:s'),
            'deacti_reason' => $reason_for_deactivation,
            'deacti_reason_oth' => $other_reason_for_deactivation,
            'deacti_by' => $this->session->userdata('userDetails')->user_id,
            );
            $this->db->where('tenant_id', $user->tenant_id);
            $this->db->where('user_id', $user_id);
            $this->db->update('tms_users', $tms_users_data);            
    }
    /*
     * This function will check the email id exists on the db or not.
     * Author: Bineesh.
     * Date: 13/08/2014.
     */
    public function check_email($email_id){
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('registered_email_id', $email_id);
        $query = $this->db->get();
        return $query->num_rows();
    }
    /*
     * This function will check the email id exists on the db or not.
     * Author: Bineesh.
     * Date: 13/08/2014.
     */
    public function check_pan(){
        extract($_POST);
        $pan_id = trim($pan_id);
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('tax_code', $pan_id);        
        $result = $this->db->get();       
        return $result->num_rows();
    }
    /*
     * This function will check the username exists on the db or not.
     * Author: Bineesh.
     * Date: 13/08/2014.
     */
    public function check_username($user_name){
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('user_name', $user_name);
        $query = $this->db->get();
        return $query->num_rows();   
    }
    /*
     * This Method for Internal user name auto complete in internal user list
     * Author: Bineesh
     * Date:12/08/2014
     */
    public function internal_user_autocomplete($search_course_code = NULL) {
        $matches = array();        
        $tenant_id=$this->session->userdata('userDetails')->tenant_id;
        if (!empty($search_course_code)) {
            $this->db->select('pers.first_name');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr', 'usr.tenant_id = pers.tenant_id '
                . 'AND usr.user_id = pers.user_id');
            $this->db->join('internal_user_role irole', 'usr.user_id = irole.user_id');
            $this->db->join('tms_roles role', 'irole.tenant_id = role.tenant_id '
                . 'AND irole.role_id = role.role_id');
            $this->db->where('usr.tenant_id', $tenant_id);
            $this->db->where('usr.account_type', 'INTUSR');
            $this->db->like('pers.first_name', $search_course_code, 'both'); 
            $results = $this->db->get()->result();              
          $i=0;
            foreach ($results as $result) {
                $matches[$i] = $result->first_name;
                $i++;
            }
        }
        return $matches;
    }

    public function get_users_by_types($types)
    {
        return $this->db->
            select("user_id, registered_email_id")->
            from("tms_users")->
            where("account_status",'ACTIVE')->
            where_in("account_type", $types)->
            get();
    }

    public function get_users_by_ids($user_ids)
    {
        return $this->db->
            select("user_id, registered_email_id")->
            from("tms_users")->
            where("account_status",'ACTIVE')->
            where_in("user_id", $user_ids)->
            get();

    }
    /*
     * This function for updating the password.
     * Author; Bineesh.
     * Date: 20 Aug 2014.
     */
    public function update_password($data){            
        $result=$this->match_old_pwd($data['old_password']);            
        if($result==TRUE){
            $user = $this->session->userdata('userDetails');            
            $update_array=array('password'=>$data['encrypted_password'],'pwd_last_chgd_on' => date('Y-m-d H:i:s'));
            $this->db->where("user_id",$user->user_id);
            $this->db->where("tenant_id",$user->tenant_id);
            $result=$this->db->update("tms_users",$update_array);                 
            if($result){
                return TRUE;
            }else{
                return FALSE;
            }
        }else{
            return FALSE;
        }        
    }
    /*
     * This method for checking the old password with db.
     * Author: Bineesh.
     * Date: 20 Aug 2014.
     */
    private function match_old_pwd($old_password){
        $user = $this->session->userdata('userDetails');            
        $this->db->select("password");
        $this->db->from("tms_users");        
        $this->db->where("user_id",$user->user_id);
        $this->db->where("tenant_id",$user->tenant_id);
        $result=$this->db->get()->row();                         
        if ($this->bcrypt->check_password($old_password, $result->password)) {
            return TRUE;
        }else{
            return FALSE;
        }        
    }

}