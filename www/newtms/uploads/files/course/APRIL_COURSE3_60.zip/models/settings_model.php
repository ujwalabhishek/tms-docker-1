<?php

/*
  * This is the Model class for Settings
  * Author : Jaison Jose
  * Date created : 25 July 2014
  */

class Settings_Model extends CI_Model {
  
    /* 

     * This method gets the gst rate list for a tenant 
     * @param $tenant_id
     * Author: Bineesh M
     * Date: Aug 04 2014

     * This method gets the gst rate list for a tenant 
     * Author: Bineesh M
     * Date: Aug 04 2014

     */
    public function get_gst_rates($tenant_id){        
        $this->db->select("gst.gst_id, gst.gst_rate, gst.updated_on, gst.updated_by, gst.is_current, usr.first_name, usr.last_name");
        $this->db->from("gst_rates gst, tms_users_pers usr");
        $this->db->where("gst.tenant_id = usr.tenant_id");
        $this->db->where("gst.updated_by = usr.user_id");
        $this->db->where("gst.tenant_id", $tenant_id);
        $this->db->order_by('gst.gst_id', 'DESC'); 
        $result = $this->db->get();         
        if($result->num_rows()>0){
            return $result->result();
        }
        else
            return false;

    }
    /**
     * This method inserts the new gst rate and set it to active
     * @param type $tenant_id,$user_id,$gst_rate
     * Author: Bineesh M
     * Date: Aug 04 2014
     */
    private  function insert_new_gst_rate($tenant_id,$user_id,$gst_rate){                      
        $data = array('tenant_id'=>$tenant_id,'gst_rate'=>$gst_rate,'updated_on'=>date('Y-m-d'),'updated_by'=>$user_id,'is_current'=>1);
        $result=$this->db->insert('gst_rates', $data);        
        if($result){
            return true;
        }else {
            return false;
        }
    }
    /** This method gets the active gst rate  for a tenant 
     * Author: Bineesh M
     * Date: Aug 04 2014
     */
    public function get_active_gst_rates($tenant_id){        
        $this->db->select("gst_rate,gst_id");
        $this->db->from("gst_rates");
        $this->db->where("tenant_id",$tenant_id);
        $this->db->where("is_current",1);        
        $result = $this->db->get();        
        if($result->num_rows()>0){
            return $result->row();
        }
        else
            return false;
        
    }
    /*
     * This method updates existing active gst rate to in-active and inserts the new gst rate
     * Author: Bineesh M
     * Date: Aug 04 2014
    */
    public function update_gst_rate($tenant_id,$user_id){
        extract($_POST);
        //Updating active gst to in-active.
        $data=array('is_current'=>0);
        $this->db->where('is_current',1);
        $this->db->where('tenant_id',$tenant_id);
        $this->db->update('gst_rates',$data);
        //Inserting new active gst value
        $result=$this->insert_new_gst_rate($tenant_id,$user_id,$gst_rate);
        return $result;
    }
    /*
     * This function for getting the tenant mater details in settings page.
     * Author : BIneesh
     * Date : 26 Aug 2014
     */
    public function get_tenent_master($tenant_id = NULL){
        if($tenant_id== NULL){
            return FALSE;
        }
        $this->db->select('');
        $this->db->from('tenant_master');
        $this->db->where('tenant_id',$tenant_id);
        $result=$this->db->get();
        if($result) {
            return $result->row();
        }else {
            return FALSE;
        }
    }
   /*
    * This Methord for updating the paypal email id of the tenant.
    * Author: BIneesh
    * Date; 26 Aug 2014.
    */ 
    public function update_paypal_email_id($tenant_id) {
        $paypal_email_id=$this->input->post('paypal_email_id');        
        $data= array('paypal_email_id'=>$paypal_email_id);
        $this->db->where('tenant_id',$tenant_id);
        $result=$this->db->update('tenant_master',$data);
        if($result){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    /*
    * This Methord for updating the Invoice name of the tenant.
    * Author: BIneesh
    * Date; 26 Aug 2014.
    */ 
    public function update_invoice_name($tenant_id) {
        $invoice_name=$this->input->post('invoice_name');      
        $data= array('invoice_name'=>$invoice_name);
        $this->db->where('tenant_id',$tenant_id);
        $result=$this->db->update('tenant_master',$data);
        if($result){
            return TRUE;
        }else{
            return FALSE;
        }
    }

 }   
   