<?php
/*
  * This is the Model class for Trainee
  * Author : Balwant Singh
  * Date created : 13 Aug 2014
  */

class Trainee_Model extends CI_Model {
        /* 
         * This method gets the trainee list for a tenant
	 */
    // added by bineesh for password encrypt. 23 Aug 2014.
    private $user;
    public function __construct() {
        parent::__construct();       
        $this->load->library('bcrypt');
        $this->load->helper('common');
        $this->user = $this->session->userdata('userDetails');
    }
    /**
     * 
     * @return type
      * @Author: Balwant Singh
     * @Date:  Aug 23 2014
    */
public function record_count(){

            $tenantid = $this->session->userdata('userDetails')->tenant_id;
            $username = $this->input->post('pers_first_name');
            $username = explode('(', $username );           
            $username = $username[0];  
            
            $taxcode = $this->input->post('tax_code');  
            $status = $this->input->post('status');
        
            $this->db->select('count(*) as totalrows');
            $this->db->from('tms_users usr');
            $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
                . 'AND usr.user_id = pers.user_id');
            $this->db->where('usr.tenant_id', $tenantid);
            $this->db->where('usr.account_type', 'TRAINE');            
            
            if($this->input->post('pers_first_name'))
                $this->db->like('usr.user_name', $username, 'after');  
            if($this->input->post('tax_code'))
                $this->db->like('usr.tax_code', $taxcode, 'after');  
            if($this->input->post('status') && $status != 'Select' && $status != 'All' )
                $this->db->where('usr.account_status', $status);

            $result = $this->db->get()->result();

        return $result[0]->totalrows;
  }

    
    /**
     * Function to get list of trainees 
     * @param type $tenant_id
     * @param type $limit
     * @param type $offset
     * @param type $sort_by
     * @param type $sort_order
     * @return type
     * @Author: Balwant Singh
     * @Date:  Aug 23 2014
     */
    public function get_trainee_list($tenant_id, $limit, $offset, $sort_by, $sort_order) {           
        $username = $this->input->post('pers_first_name');
        $username = explode('(', $username );           
        $username = $username[0];  
        $taxcode = $this->input->post('tax_code');
        $status = $this->input->post('status');
        $company_id = $this->input->post('off_company_name');

        if ($offset <= 0 OR empty($tenant_id)) {
            return;
        }                

        $this->db->select('usr.user_id, usr.tax_code,usr.country_of_residence, usr.registration_date, '
            . 'pers.first_name traineename, pers.last_name, pers.dob, usr.account_type, usr.account_status,'
                . 'com.company_id,com_mst.company_name');
        $this->db->from('tms_users usr');
        $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
            . 'AND usr.user_id = pers.user_id');
        $this->db->join('tenant_company_users com', 'usr.tenant_id = com.tenant_id '
            . 'AND usr.user_id = com.user_id',"left");
        $this->db->join('company_master com_mst', 'com.company_id = com_mst.company_id',"left");
        $this->db->where('usr.tenant_id', $tenant_id);
        $this->db->where('usr.account_type', 'TRAINE');

        if($this->input->post('pers_first_name')){
            $this->db->like('usr.user_name', $username, 'after'); 
        }
        if($this->input->post('tax_code')){
            $this->db->like('usr.tax_code', $taxcode, 'after');  
        }
        if($this->input->post('status') && $status != 'Select' && $status != 'All' ){
            $this->db->where('usr.account_status', $status);
        }
        if($this->input->post('off_company_name')){
            $this->db->where('usr.tenant_org_id', $company_id);  
        }

        if($sort_by) { 
            $this->db->order_by($sort_by, $sort_order);  
        }else {
            $this->db->order_by('usr.last_modified_on', 'DESC');
        }
        if ($limit == $offset) {
            $this->db->limit($offset); 
        }
        else if($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);  
        }
        $query = $this->db->get();                
        return $query->result_array();
    }
    /**
     * 
     * @return string
     * @Author: Balwant Singh
     * @Date:  Aug 23 2014
     */
/*
    function to get list of trainees for export
    */
    public function get_trainee_list_export(){
        $sql = "SELECT usr.tax_code TAXCODE,usr.country_of_residence COUNTRY,
                usr.registration_date REGISTRATIONDATE, CONCAT(pers.first_name,' ',pers.last_name) NAME, 
                pers.dob DATEOFBIRTH, usr.account_type ACCOUNTTYPE, usr.account_status ACCOUNTSTATUS,
                com.company_id,com_mst.company_name
                        FROM  tms_users_pers pers ,tms_users usr
                        left join tenant_company_users com
                        on usr.tenant_id = com.tenant_id and usr.user_id = com.user_id
                        left join company_master com_mst
                        on com.company_id = com_mst.company_id
                        WHERE usr.tenant_id = pers.tenant_id 
                        AND usr.user_id = pers.user_id 
                        and usr.tenant_id = '".$this->user->tenant_id."' and usr.account_type = 'TRAINE' order by usr.created_on DESC";        
        return $sql;
    }



    /**
     * function to check duplicate username 
     * @param type $username
     * @return boolean
     * @Author: Balwant Singh
     * @Date:  Aug 23 2014
     */
    public function check_duplicate_user_name($username) {
        $exists = $this->db->select('user_id')->get_where('tms_users', array('user_name' => $username), 1)->num_rows();
            if ($exists) {
                return FALSE;
            }
            return TRUE;
        }
    /**
     * This method gets the Trainee Details
     * @param type $user_id
     * @return type
     * @Author: Balwant Singh
     * @Date:  Aug 23 2014
     */
/*
    function to get trainee details
    */

    function get_trainee($user_id){

        $tenantid = $this->session->userdata('userDetails')->tenant_id;
        $data = array();        
      
            $this->db->select('usr.*,  pers.*');
            $this->db->from('tms_users usr');
            $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
                      . 'AND usr.user_id = pers.user_id');
            $this->db->where('usr.user_id', $user_id);
            $this->db->where('usr.tenant_id', $tenantid);
             $this->db->where('usr.account_status', 'ACTIVE');
            $query = $this->db->get();   
            $result = $query->result_array();
            $data[userdetails] = $result[0];
            $userid = $data[userdetails][user_id];

            $this->db->select('educ_id, educ_level, educ_yr_completion, educ_score, educ_remarks');
            $this->db->from('tms_users_educ');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[edudetails] = $query->result_array();
          
            $this->db->select('othr_cert_id, cert_name, yr_completion, valid_till,oth_remarks');
            $this->db->from('tms_users_othr_cert');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[otherdetails] = $query->result_array();
          
            $this->db->select('wrk_exp_id, org_name, emp_from_date, emp_to_date, designation');
            $this->db->from('tms_users_wrk_exp');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[workdetails] = $query->result_array();

        return $data;
    }

/*
    function to get trainee details by tax code
    */

    function get_trainee_taxcode($taxcode){

        $tenantid = $this->session->userdata('userDetails')->tenant_id;
        $data = array();        
      
            $this->db->select('usr.*,  pers.*');
            $this->db->from('tms_users usr');
            $this->db->join('tms_users_pers pers', 'usr.tenant_id = pers.tenant_id '
                      . 'AND usr.user_id = pers.user_id');
            $this->db->where('usr.tax_code', $taxcode);
            $this->db->where('usr.tenant_id', $tenantid);
             $this->db->where('usr.account_status', 'ACTIVE');
            $query = $this->db->get();   
            $result = $query->result_array();
            $data[userdetails] = $result[0];
            $userid = $data[userdetails][user_id];

            $this->db->select('educ_id, educ_level, educ_yr_completion, educ_score, educ_remarks');
            $this->db->from('tms_users_educ');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[edudetails] = $query->result_array();
          
            $this->db->select('othr_cert_id, cert_name, yr_completion, valid_till,oth_remarks');
            $this->db->from('tms_users_othr_cert');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[otherdetails] = $query->result_array();
          
            $this->db->select('wrk_exp_id, org_name, emp_from_date, emp_to_date, designation');
            $this->db->from('tms_users_wrk_exp');
            $this->db->where('tenant_id', $tenantid);
            $this->db->where('user_id', $userid);
            $query = $this->db->get();    
            $data[workdetails] = $query->result_array();

        return $data;
    }
    
   
   
    /**
     * This method creates a Trainee account
     * @param type $activation_key
     * @param type $encrypted_password
     * @return type
     * @Author: Balwant Singh
     * @Date:  Aug 23 2014
     */
    public function save_user_data() {                    
        foreach($this->input->post() as $key=>$value) {
            $$key = $value;
        }   

        $dateTime = date('Y-m-d H:i:s');
        $other_identi_type = NULL;
        $other_identi_code = NULL;

        if($country_of_residence == 'IND'){
            $tax_code_type = 'PAN';
            $tax_code = $PAN;
        }
        if($country_of_residence == 'SGP'){
            $tax_code_type = $NRIC;
            $tax_code = $NRIC_ID;
            if($NRIC == "OTHERS") {
                $other_identi_type = $NRIC_OTHER;
                $other_identi_code = $tax_code;
            }
        }
        if($country_of_residence == 'USA'){
            $tax_code_type = 'SSN';
            $tax_code = $SSN;
        } 
        // Added by Bineesh - Aug 23 2014
        $password= NULL;
        $encrypted_password=NULL;
        $activation_key = NULL;
        $activate_user_status = NULL;

        if($activate_user == 'ACTIVE' && $bypassemail == "EMACRQ") {                
            $activation_key = random_key_generation();
            $activate_user_status = 'PENDACT'; 
        }else{
            $activate_user_status = $activate_user;
        }
        if($activate_user == 'ACTIVE') {                
            $password = random_key_generation();
            $encrypted_password = $this->bcrypt->hash_password($password); 
            $acct_acti_date_time = $dateTime;
        } else {
            $acct_acti_date_time = '0000-00-00 00:00';            
        }
        //inserting on tms_users starts here 
        $tms_users_data = array(
        'tenant_id' => $this->user->tenant_id,
        'account_type' => 'TRAINE',
        'registration_mode' => 'INTUSR',
        'friend_id' => NULL,
        'registration_date' => $dateTime,
        'user_name' => $user_name,
        'tenant_org_id' => $assign_company,
        'password' => $encrypted_password,
        'acc_activation_type' => $bypassemail,
        'activation_key' => $activation_key,
        'registered_email_id' => $user_registered_email,
        'country_of_residence' => $country_of_residence,
        'tax_code_type' => $tax_code_type,
        'tax_code' => $tax_code,
        'other_identi_type' => $other_identi_type,
        'other_identi_code' => $other_identi_code,
        'other_identi_upload' => '',
        'acct_acti_date_time' => $dateTime,
        'acct_deacti_date_time' => $acct_acti_date_time,
        'account_status' => $activate_user_status,
        'deacti_reason' => NULL,
        'deacti_reason_oth' => NULL,
        'deacti_by' => NULL,
        'created_by' => $this->user->user_id,
        'created_on' => $dateTime,
        'last_modified_by' => NULL,
        'last_modified_on' => $dateTime,
        'last_login_date_time' => NULL,
        'last_ip_used' => NULL,
        'pwd_last_chgd_on' => NULL
        );
        $this->db->trans_start();
        $this->db->insert('tms_users', $tms_users_data);
        $user_id = $this->db->insert_id();
        //inserting on tms_users ends here

        //inserting on tenant_company_users starts here            
        if($assign_company != ''){                
            $company_data = array(
                'company_id' => $assign_company,
                'tenant_id' =>  $this->user->tenant_id,
                'user_id' =>  $user_id,
                'user_acct_status' => $activate_user_status,
                'acct_acti_date_time' => $dateTime,
                'acct_deacti_date_time' => '',
                'deacti_reason' => '',
                'deacti_reason_oth' => '',
                'deacti_by' => '',
                'assigned_by' =>  $this->user->user_id,
                'assigned_on'  => $dateTime,
                'last_modified_by' =>  '',
                'last_modified_on' => ''
                );
               $this->db->insert('tenant_company_users', $company_data);
        }
        //inserting on tenant_company_users ends here
        //inserting on tms_users_pers starts here
        //Personal Details
        $tms_users_pers_data = array(
        'tenant_id' => $this->user->tenant_id,
        'user_id' => $user_id,
        'first_name' => $pers_first_name,
        'last_name' => $pers_last_name,
        'gender' => $pers_gender,
        'dob' => date('Y-m-d', strtotime($pers_dob)),
        'alternate_email_id' => $pers_alternate_email,
        'contact_number' => $pers_contact_number,
        'alternate_contact_number' => $pers_alternate_contact_number,
        'race' => $race,
        'salary_range' => $sal_range,
        'personal_address_bldg' => $pers_personal_address_bldg,
        'personal_address_city' => $pers_city,
        'personal_address_state' => $pers_states,
        'personal_address_country' => $pers_country,
        'personal_address_zip' => $pers_zip,
        'photo_upload_path' => NULL,
        'individual_discount' => $individual_discount,
        'certificate_pick_pref' => $certificate_pick_pref,
        'indi_setting_list_size' => NULL
        );
        $this->db->insert('tms_users_pers', $tms_users_pers_data);
        //inserting on tms_users_pers ends here
        //inserting on tms_users_educ starts here
        //Education Level   
        for($i=0;$i<count($edu_level);$i++){
            if($edu_level[$i]){
                $edu = array(
                         'tenant_id' => $this->user->tenant_id,
                         'user_id' => $user_id,
                         'educ_id' => '', 
                         'educ_level' => $edu_level[$i],
                         'educ_yr_completion' => $edu_year_of_comp[$i],
                         'educ_score' => $edu_score_grade[$i],
                         'educ_remarks' => $edu_remarks[$i],
                     );
                $this->db->insert('tms_users_educ', $edu);
            }
        }
        //inserting on tms_users_educ ends here
        //inserting on tms_users_othr_cert starts here
        //Certification            
        for($i=0;$i<count($oth_certi_name);$i++){
            if($oth_certi_name[$i]){
                $other = array(
                        'tenant_id' => $this->user->tenant_id,
                         'user_id' => $user_id,
                         'othr_cert_id' => '',
                         'cert_name' => $oth_certi_name[$i],
                         'yr_completion' => $oth_year_of_certi[$i],
                         'valid_till' => date('Y-m-d', strtotime($oth_validity[$i])),
                         'oth_remarks' => $oth_remarks[$i],
                     );
                $this->db->insert('tms_users_othr_cert', $other);
            }
        }
        //inserting on tms_users_othr_cert ends here
        //inserting on tms_users_wrk_exp starts here
        //Work Experience
        for($i=0;$i<count($work_org_name);$i++){
            if($work_org_name[$i]){
                    $other = array(
                             'tenant_id' => $this->user->tenant_id,
                             'user_id' => $user_id,
                             'wrk_exp_id' => '', //$this->input->post('0', TRUE),
                             'org_name' => $work_org_name[$i],
                             'emp_from_date' => date('Y-m-d', strtotime($work_empfrom[$i])),
                             'emp_to_date' => date('Y-m-d', strtotime($work_empto[$i])),
                             'designation' => $work_designation[$i],
                         );
                    $this->db->insert('tms_users_wrk_exp', $other);     
            }            
        }
        //inserting on tms_users_wrk_exp ends here
        $this->db->trans_complete(); 
        if ($this->db->trans_status() === FALSE) {
            $this->session->set_flashdata('error_message', 'Oops! Sorry, it looks like something went wrong and an error has occurred');
            return FALSE;
        } 
        //Added By Bineesh - Aug 23 2014 - Send Account Actovation mail            
        if($activate_user == 'ACTIVE') {
            $user_details = array('username' => $user_name, 
                    'email' => $user_registered_email, 'password' => $password,
                    'firstname' => $pers_first_name,'lastname' => $pers_last_name,
                    'gender' => $pers_gender); 
            if ($bypassemail == 'BPEMAC'){ //By-Pass Email Activation - send regular account creation mail only	                    
                $this->send_trainy_email($user_details, $bypassemail);
            }
            if ($bypassemail == 'EMACRQ'){ //Email  Activation Required - send account activation mail with link and activation code	                                                                                  
                $user_details['link'] = base_url() . 'activate_user/index/' . $user_id . '/' . md5($activation_key);                                            
                $this->send_trainy_email($user_details,$bypassemail);                    
            }                
        }
        return TRUE;
    }
    /**
     * This method for sending account activation and creation mail to the trainee
     * @param type $bypassemail
     * @return type
     * Author: Bineesh.
     * Date: 23 Aug 2014.    * @param type $user
     */
    public function send_trainy_email($user, $bypassemail) { 
        $tenant_details=fetch_tenant_details($this->session->userdata('userDetails')->tenant_id);
        $footer_data=str_replace("<Tenant_Company_Name>", $tenant_details->tenant_name, MAIL_FOOTER);        
        $subject = NULL;
        $body = NULL;
        if ($user['gender'] == 'MALE'){
            $body ="Dear Mr.".$user['firstname'].' '.$user['lastname'].',';
        }else{
            $body .="Dear Ms.".$user['firstname'].' '.$user['lastname'].',';            
        }   
        
        if ($bypassemail == 'BPEMAC'){ //By-Pass Email Activation 	                    
                  $subject = 'Your Account Creation Acknowledgment'; 
                  $body .=  '<br/><br/>&nbsp;&nbsp;Thank you for registering with us. Your account has been successfully created.<br/><br/>';
        }
         if ($bypassemail == 'EMACRQ'){//Email  Activation Required 
                  $subject = 'Your Account Activation Acknowledgment';
                  $body .=  '<br/><br/>&nbsp;&nbsp;Thank you for registering with us. <br/><br/>';
                    if ($user['link']) {
                        $body .= '&nbsp;&nbsp;To activate your account, please click on the url link given below: <br/>';
                        $body .= '&nbsp;&nbsp;<a target="_blank" href="'. $user['link'] . '">'.$user['link'].'</a><br/><br/>';
                    }
          }
        $body .= "<strong>&nbsp;&nbsp;Your username:</strong> ". $user['username'] ."<br/>";
        $body .= "<strong>&nbsp;&nbsp;Your password:</strong> ". $user['password']."<br/><br/>";
        $body .= $footer_data;        
        return send_mail($user['email'], '', $subject, $body);
    }
    /**
     * for activating trainee
     * @param int $user_id
     * @param string $activation_key md5 of the activation code
     * 
     * @return boolean
     */
    public function verify_trainee_user($user_id, $activation_key) {
        if($user_id && $activation_key){
            $this->db->select('activation_key');
            $this->db->from('tms_users');
            $this->db->where('user_id',$user_id);
            $db_activation_key=md5($this->db->get()->row('activation_key'));            
            if($db_activation_key == $activation_key){
                $user_data=array('account_status' => 'ACTIVE');
                $this->db->where('user_id',$user_id);
                $status=$this->db->update('tms_users',$user_data);
                if($status){
                    $company_data=array('user_acct_status' => 'ACTIVE');
                    $this->db->where('user_id',$user_id);
                    $this->db->update('tenant_company_users',$company_data);
                    return TRUE;
                }else{
                    return FALSE;
                }
            }else{
                return FALSE;
            }
        }else{
            return FALSE;
        }
        
    }


/*
    function to save trainee data from bulk file
    */
public function save_bulk_user_data($data){
            
            foreach($data as $key=>$value) {
                $$key = $value;
            }
            //Get random encrypted password
            $random_encrypted_password = '1234'; //generateEncryptedPwd();
            $dateTime = date('Y-m-d H:i:s');
            $activate_user = 'ACITVE';

            if($data['ByPassActivation'] != 'BPEMAC'){
                $activate_user = 'INACTIVE';
            }

            $tms_users_data = array(
            'tenant_id' => $this->session->userdata('userDetails')->tenant_id,
            'account_type' => 'TRAINE',
            'registration_mode' => 'INTUSR',
            'friend_id' => NULL,
            'registration_date' => $dateTime,
            'user_name' => $username,
            'tenant_org_id' => $CompanyCode,
            'password' => $random_encrypted_password,
            'acc_activation_type' => $bypassemail,
            'activation_key' => NULL,
            'registered_email_id' => $EmailId,
            'country_of_residence' => $countryofresidence,
            'tax_code_type' => $taxcodetype,
            'tax_code' => $taxcode,
            'other_identi_type' => NULL,
            'other_identi_code' => NULL,
            'other_identi_upload' => '',
            'acct_acti_date_time' => $dateTime,
            'acct_deacti_date_time' => NULL,
            'account_status' => $activate_user,
            'deacti_reason' => NULL,
            'deacti_reason_oth' => NULL,
            'deacti_by' => NULL,
            'created_by' => $this->session->userdata('userDetails')->user_id,
            'created_on' => $dateTime,
            'last_modified_by' => NULL,
            'last_modified_on' => NULL,
            'last_login_date_time' => NULL,
            'last_ip_used' => NULL,
            'pwd_last_chgd_on' => NULL
            );

            $this->db->insert('tms_users', $tms_users_data);
            $user_id = $this->db->insert_id();

            if($CompanyCode){
                
                $company_data = array(
                    'company_id' => $CompanyCode,
                    'tenant_id' =>  $this->session->userdata('userDetails')->tenant_id,
                    'user_id' =>  $user_id,
                    'user_acct_status' => $activate_user,
                    'acct_acti_date_time' => $dateTime,
                    'acct_deacti_date_time' => '',
                    'deacti_reason' => '',
                    'deacti_reason_oth' => '',
                    'deacti_by' => '',
                    'assigned_by' =>  $this->session->userdata('userDetails')->user_id,
                    'assigned_on'  => $dateTime,
                    'last_modified_by' =>  '',
                    'last_modified_on' => ''
                    );
                   $this->db->insert('tenant_company_users', $company_data);
            }
         
            $tms_users_pers_data = array(
            'tenant_id' => $this->session->userdata('userDetails')->tenant_id,
            'user_id' => $user_id,
            'first_name' => $data["firstname"],
            'last_name' => $data['lastname'],
            'gender' => '',
            'dob' => $data['dob'],
            'alternate_email_id' => '',
            'contact_number' => $data['ContactNumber'],
            'alternate_contact_number' => '',
            'race' => $data['RaceCode'],
            'salary_range' => $data['SalaryRangeCode'],
            'personal_address_bldg' => '',
            'personal_address_city' => $data['City'],
            'personal_address_state' => $data['State'],
            'personal_address_country' => $data['Country'],
            'personal_address_zip' => $data['ZipCode'],
            'photo_upload_path' => NULL,
            'individual_discount' => $data['Discount'],
            'certificate_pick_pref' => $data['CertificatePickupCode'],
            'indi_setting_list_size' => NULL
            );
            $this->db->insert('tms_users_pers', $tms_users_pers_data);
                
        return true;
    }

/*
    function to deactivate trainee
    */
    public function deactivate_trainee(){

                     foreach($this->input->post() as $key=>$value) {
                        $$key = $value;
                    }
                    $tenant_id = $this->session->userdata('userDetails')->tenant_id;
                    $deactive = array(                        
                        'acct_deacti_date_time' => $deactiv_date,
                        'deacti_reason' => $deact_reason,
                        'deacti_reason_oth' => $reson_other,
                        'account_status' => 'INACTIV',
                        'deacti_by' => $this->session->userdata('userDetails')->tenant_id
                    );
                    $user_id = $this->input->post('userid');
                    $this->db->where('user_id', $user_id);
                    //$this->db->where('tenant_id', $tenant_id);
                    $this->db->update('tms_users', $deactive);
                    $this->db->last_query();
    }

/*
    function to update trainee data
    */
    public function update_trainee(){

               foreach($this->input->post() as $key=>$value) {
                $$key = $value;
                }            
                $dateTime = date('Y-m-d H:i:s');

                if($country_of_residence == 'IND'){
                    $tax_code_type = 'PAN';
                    $tax_code = $PAN;
                }
                if($country_of_residence == 'SGP'){
                    $tax_code_type = 'NRIC';
                    $tax_code = $NRIC;
                }
                if($country_of_residence == 'USA'){
                    $tax_code_type = 'SSN';
                    $tax_code = $SSN;
                } 
            
                $date = date('Y-m-d H:i:s');
                $data = array(
                    'country_of_residence' => $country_of_residence,
                    'tax_code_type' => $tax_code_type,
                    'tax_code' => $tax_code,
                    'tenant_org_id' => $assign_company,
                    'acc_activation_type' => $bypassemail,
                    'registered_email_id' => $user_registered_email,
                    'other_identi_type' => $other_identi_type,
                    'other_identi_code' => $other_identi_code,
                    'other_identi_upload' => '',
                    'last_modified_by' => $this->session->userdata('userDetails')->tenant_id,
                    'last_modified_on' => $date,
                );
                             
                $user_id = $this->input->post('userid');
                $this->db->where('user_id', $user_id);
                $this->db->update('tms_users', $data);
                
                $pers = array(
                    'first_name' => $this->input->post('pers_first_name', TRUE),
                    'last_name' => $this->input->post('pers_last_name', TRUE),
                    'gender' => $this->input->post('gender', TRUE),
                    'dob' => date('Y-m-d', strtotime($this->input->post('personal_dob'))),
                    'alternate_email_id' => $this->input->post('pers_alt_email', TRUE),
                    'contact_number' => $this->input->post('pers_contact_phone', TRUE),
                    'alternate_contact_number' => $pers_contact_mobile,
                    'race' => $race,
                    'salary_range' => $sal_range,
                    'personal_address_bldg' => $pers_personal_address,
                    'personal_address_city' => $pers_city,
                    'personal_address_state' => $pers_states,
                    'personal_address_country' => $pers_country,
                    'personal_address_zip' => $personal_address_zip,
                    'photo_upload_path' => NULL,
                    'individual_discount' => $individual_discount,
                    'certificate_pick_pref' => $certificate_pick_pref,
                    'indi_setting_list_size' => NULL,
                );
                
                $this->db->where('user_id', $user_id);
                $this->db->update('tms_users_pers', $pers);

            if($assign_company){
                
                $company_data = array(
                    'company_id' => $assign_company,
                    'tenant_id' =>  $this->session->userdata('userDetails')->tenant_id,
                    'user_id' =>  $user_id,
                    'user_acct_status' => $activate_user,
                    'acct_acti_date_time' => $dateTime,
                    'acct_deacti_date_time' => '',
                    'deacti_reason' => '',
                    'deacti_reason_oth' => '',
                    'deacti_by' => '',
                    'assigned_by' =>  $this->session->userdata('userDetails')->user_id,
                    'assigned_on'  => $dateTime,
                    'last_modified_by' =>  '',
                    'last_modified_on' => ''
                    );
                $this->db->where('user_id', $user_id);
                $this->db->update('tenant_company_users', $company_data);
            }
               
              
                $update_edu_array = explode(',', $update_edu);
                 foreach($update_edu_array  as $edu_id){
                    $this->db->where('educ_id', $edu_id); 
                     $this->db->delete('tms_users_educ'); 
                 }   
                 
                 $update_other_array = explode(',', $update_other);
                 foreach($update_other_array  as $other_id){
                    $this->db->where('othr_cert_id', $other_id); 
                     $this->db->delete('tms_users_othr_cert'); 
                 }

                 $update_work_array = explode(',', $update_work);
                 foreach($update_work_array  as $work_id){
                    $this->db->where('wrk_exp_id', $work_id); 
                    $this->db->delete('tms_users_wrk_exp'); 
                 }             

                for($i=0;$i<count($edu_level);$i++){
                $edu = array(
                         'tenant_id' => $this->session->userdata('userDetails')->tenant_id,
                         'user_id' => $user_id,
                         'educ_id' => '', //$this->input->post('0', TRUE),
                         'educ_level' => $edu_level[$i],
                         'educ_yr_completion' => $edu_year_of_comp[$i],
                         'educ_score' => $edu_score_grade[$i],
                         'educ_remarks' => $edu_remarks[$i],
                     );
                $this->db->insert('tms_users_educ', $edu);
            }
           
            for($i=0;$i<count($oth_certi_name);$i++){
                $other = array(
                        'tenant_id' => $this->session->userdata('userDetails')->tenant_id,
                         'user_id' => $user_id,
                         'othr_cert_id' => '', //$this->input->post('0', TRUE),
                         'cert_name' => $oth_certi_name[$i],
                         'yr_completion' => $oth_year_of_certi[$i],
                         'valid_till' => date('Y-m-d', strtotime($oth_validity[$i])),
                         'oth_remarks' => $oth_remarks[$i],
                     );
                $this->db->insert('tms_users_othr_cert', $other);
            }

            for($i=0;$i<count($work_org_name);$i++){
                $other = array(
                                 'tenant_id' => $this->session->userdata('userDetails')->tenant_id,
                                 'user_id' => $user_id,
                                 'wrk_exp_id' => '', //$this->input->post('0', TRUE),
                                 'org_name' => $work_org_name[$i],
                                 'emp_from_date' => date('Y-m-d', strtotime($work_empfrom[$i])),
                                 'emp_to_date' => date('Y-m-d', strtotime($work_empto[$i])),
                                 'designation' => $work_designation[$i],
                             );
                        $this->db->insert('tms_users_wrk_exp', $other);                 
            }
                return true;
    }

/*
    function to get trainee list autocomplete
    */
    public function trainee_user_list_autocomplete($tax_code = NULL) {
        $matches = array();
        
        if (!empty($tax_code)) {

            $this->db->select('pers.user_id, usr.user_name, pers.first_name, pers.last_name, usr.tax_code');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr','usr.user_id=pers.user_id');
            $this->db->where('usr.account_type','TRAINE');
            $this->db->where('usr.tenant_id',$this->session->userdata('userDetails')->tenant_id);
            $this->db->like('usr.user_name', $tax_code, 'both');
            $results = $this->db->get()->result();
            //echo $this->db->last_query();
                       
            foreach ($results as $result) {
                $matches[$result->tax_code] = $result->user_name  . '('.$result->tax_code.')' ;
            }
        }
        return $matches;
    }

    /*
    function to get trainee autocomplete by name
    */
    public function trainee_traineelist_by_name_autocomplete($tax_code = NULL) {
        $matches = array();
        
        if (!empty($tax_code)) {

            $this->db->select('pers.user_id, usr.user_name, pers.first_name, pers.last_name, usr.tax_code');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr','usr.user_id=pers.user_id');
            $this->db->where('usr.account_type','TRAINE');
            $this->db->where("usr.account_status != 'INACTIV'");
            $this->db->where('usr.tenant_id',$this->session->userdata('userDetails')->tenant_id);
            $this->db->like('pers.first_name', $tax_code, 'both');
            $results = $this->db->get()->result();
            //echo $this->db->last_query();
                       
            foreach ($results as $result) {
                $matches[$result->tax_code] = $result->user_name  . '('.$result->tax_code.')' ;
            }
        }
        return $matches;
    }

    /*
    function to get trainee autocomplete by tax code
    */
        public function trainee_user_list_by_taxcode($tax_code = NULL) {
        $matches = array();
        
        if (!empty($tax_code)) {

            $this->db->select('pers.user_id, usr.user_name, pers.first_name, pers.last_name, usr.tax_code');
            $this->db->from('tms_users_pers pers');
            $this->db->join('tms_users usr','usr.user_id=pers.user_id');
            $this->db->where('usr.account_type','TRAINE');
            $this->db->where('usr.account_status', 'ACTIVE');
            $this->db->where('usr.tenant_id',$this->session->userdata('userDetails')->tenant_id);
            $this->db->like('usr.tax_code', $tax_code, 'both');
            $results = $this->db->get()->result();
            //echo $this->db->last_query();
                       
            foreach ($results as $result) {
                $matches[$result->tax_code] = $result->tax_code;
            }
        }
        return $matches;
    }
   

   /*
    function to check for duplicate taxcode
    */
   public function check_taxcode($taxcode){
        $this->db->select('tax_code');
        $this->db->from('tms_users');
        $this->db->where('tax_code', $taxcode);
        $query = $this->db->get();
        return $query->num_rows();   
    }

    public function search_trainee_by_name($name)
    {
        $sql = "select usr.user_id, first_name, last_name
        from tms_users usr, tms_users_pers pers
        where usr.tenant_id = pers.tenant_id
        AND usr.user_id = pers.user_id
        AND usr.account_type='TRAINE'
        AND (pers.first_name like ? OR pers.last_name like ?)";
        return $this->db->query($sql, array($name.'%', $name.'%'));

    }

    public function search_trainee_by_ids($ids)
    {
        $sql = "select usr.user_id, first_name, last_name
        from tms_users usr, tms_users_pers pers
        where usr.tenant_id = pers.tenant_id
        AND usr.user_id = pers.user_id
        AND usr.user_id in (".implode(",",$ids).")";
        return $this->db->query($sql);

    }

/*
    function for upload excel file
    */
    public function excelfile_upload() {
        $config['upload_path'] = './tmp/';
        $config['allowed_types'] = '*';

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload())
        {
            //die;
            $error = array('error' => $this->upload->display_errors());
                //$this->load->view('trainee/bulkregistration', $error);
        }
        else
        {
            $out = array();
            $data = array('upload_data' => $this->upload->data());
            $out['path'] = $data['upload_data']['full_path'];
            $out['name'] = $data['upload_data']['file_name'];
            return $out;
        }
    }
 }   

