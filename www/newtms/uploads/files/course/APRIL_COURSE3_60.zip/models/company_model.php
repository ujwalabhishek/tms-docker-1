<?php
/*
  * This is the Model class for Company
  * Author : Jaison Jose
  * Date created : 25 July 2014
  */

class Company_Model extends CI_Model {
    public function __construct() {
        parent::__construct();       
        $this->load->library('bcrypt');
        $this->load->helper('common');
    }
    /*
    * This method gets count for the company list for a tenant
    */    
    public function get_company_count_by_tenant_id($tenant_id)
    {
        
        if (empty($tenant_id)) {
            return 0;
        }
        $this->db->select('count(*) as totalrows');
        $this->db->from('tenant_company tc');
        $this->db->join('company_master cm','cm.company_id=tc.company_id');
        $this->db->where('tc.tenant_id', $tenant_id);
        
        //Search Part - Starts
        $search_company_name = $this->input->post('search_company_name');
        $business_type = $this->input->post('business_type');
        $filter_status = $this->input->post('filter_status');
            if($search_company_name != ''){
                $this->db->like('cm.company_name', $search_company_name);
            }
            if($business_type != ''){
                $this->db->like('cm.business_type', $business_type);
            }    
            if($filter_status != '' && $filter_status != 'All'){
                $this->db->where('cm.company_status', $filter_status);
            }            
        //Search Part - Ends  
        

        $result = $this->db->get()->result();

        return $result[0]->totalrows;        
    }
    
    
    /*
     * Function will retrieve the company list
     * @param - TenantId, Limit, Offset, SortBy, SortOrder
     */
    public function get_company_list($tenant_id, $limit, $offset, $sort_by, $sort_order, $gettotal=NULL) {

        if ($offset <= 0 || empty($tenant_id)) {
            return;
        }

        $this->db->select('cm.company_id');
        $this->db->select('cm.company_name');
        $this->db->select('cm.comp_scn SCN');
        $this->db->select('tc.comp_status');
        $this->db->select('cm.last_modified_by, cm.last_modified_on');
        $this->db->select('cm.comp_address, cm.comp_city, cm.comp_state, cm.comp_cntry, cm.comp_zip');
        $this->db->from('tenant_company tc');
        $this->db->join('company_master cm','cm.company_id=tc.company_id');
        $this->db->where('tc.tenant_id', $tenant_id);        


        //Search Part - Starts
        $search_company_name = $this->input->post('search_company_name');
        $business_type = $this->input->post('business_type');
        $filter_status = $this->input->post('filter_status');
            if($search_company_name != ''){
                $this->db->like('cm.company_name', $search_company_name);
            }
            if($business_type != ''){
                $this->db->like('cm.business_type', $business_type);
            }    
            if($filter_status != '' && $filter_status != 'All'){
                $this->db->where('tc.comp_status', $filter_status);
            }            
        //Search Part - Ends  

        
        if($sort_by) {  
           $this->db->order_by($sort_by, $sort_order);  
        }else {
           $this->db->order_by('cm.last_modified_on', 'DESC'); 
        }

        if ($limit == $offset) {
            $this->db->limit($offset); 
        }
        else if($limit > 0) {
            $limitvalue = $offset - $limit;
            $this->db->limit($limit, $limitvalue);  
        }
        $query = $this->db->get();

        

        return $query->result_array();        
    }
    
    /*
     * Author: JAISON
     * Function used to store company datas
     * Tables used: company_master, tenant_company, tms_users, tms_users_persa and tenant_company_users
     */
    public function save_company_details() {
        $user = $this->session->userdata('userDetails');
        $tenant_id = $user->tenant_id;
        extract($_POST);
            
        $curr_date_time = date('Y-m-d H:i:s');
        $acct_activation_date_time = '0000-00-00 00:00:00';
        if($activate_company == 'ACTIVE') {
            $acct_activation_date_time = $curr_date_time;
        }                        
        //Inserting into company_master starts here
        $companydata = array(
            'company_name' => $company_name,
            'comp_regist_num' => $regno,
            'business_type' => $business_type,
            'business_size' => $business_s,
            'comp_phone' => $phoneno,
            'comp_fax' => $faxno,
            'comp_address' => $street,
            'comp_city' => $city,
            'comp_state' => $pers_states,            
            'comp_cntry' => $company_country,
            'comp_zip' => $zipcode,
            'company_status' => $activate_company,
            'remarks' => $comments,
            'created_by' => $user->user_id,
            'created_on' => $curr_date_time,
            'last_modified_by' => $user->user_id,
            'last_modified_on' => $curr_date_time,
            'comp_scn' => $comp_scn,
            'comp_cntry_scn' => $country_of_residence
        );
        if($activate_company == 'ACTIVE') {
            $companydata['acct_activation_date_time'] = $acct_activation_date_time;
        }
        $this->db->trans_start();
        $this->db->insert('company_master', $companydata);
        $comp_id = $this->db->insert_id();        
        //Inserting into company_master ends here

        //Inserting into tenant_company starts here
        $tenantcompany = array(
            'tenant_id'=> $tenant_id,
            'company_id' => $comp_id,
            'comp_discount' => $localdiscount,
            'comp_frgn_discnt' => $foreigndiscount,
            'comp_status' => $activate_company,
            'assigned_by' => $user->user_id,
            'assigned_on' => $curr_date_time,
            'last_modified_by' => $user->user_id,
            'last_modified_on' => $curr_date_time,
        );
        if($activate_company == 'ACTIVE') {
            $tenantcompany['acct_acti_date_time'] = $acct_activation_date_time;
        }        
        $this->db->insert('tenant_company', $tenantcompany);
        //Inserting into tenant_company ends here

        //Inserting into tms_users, tms_users_pers, tenant_company_users starts here  
        $account_type = 'COMUSR';                 
        $registration_date = $curr_date_time;
        $registration_mode = 'INTUSR';
        $tenant_org_id = 1; // ??       
        $acc_activation_type = 'BPEMAC';
        
        for ($i = 0; $i < count($username); $i++) {
            //generateEncryptedPwd if acount is active - Added by Bineesh Aug 23 2014
            $encrypted_password = NULL;
            if($activate_company == 'ACTIVE'){                
                $password = random_key_generation();
                $encrypted_password = $this->bcrypt->hash_password($password);
            }
            $tms_users_data = array(
                'tenant_id' => $tenant_id,                
                'account_type' => $account_type,
                'registration_mode' => $registration_mode,
                'tenant_org_id' => $tenant_org_id,
                'password' => $encrypted_password,
                'registration_date' => $registration_date,
                'user_name' => $username[$i],
                'registered_email_id' => $email_01[$i],
                'country_of_residence' => $country_of_residence,
                'account_status' => $activate_company,
                'created_by' => $user->user_id,
                'created_on' => $curr_date_time,
                'last_modified_by' => $user->user_id,
                'last_modified_on' => $curr_date_time,
            );
            if($activate_company == 'ACTIVE') {
                $tms_users_data['acct_acti_date_time'] = $acct_activation_date_time;
            }            
            $this->db->insert('tms_users', $tms_users_data);        
            //Inserting into tms_users ends here
            $user_id = mysql_insert_id();            
            $tms_users_pers_data = array(
                'tenant_id' => $tenant_id,                  
                'user_id' => $user_id,                  
                'first_name' => $fname[$i],
                'last_name' => $lname[$i],
                'gender' => $gender[$i],
                'contact_number' => $contactno[$i],
                'alternate_contact_number' => $mobileno[$i],
                'alternate_email_id' => $email_02[$i],
            );
            $this->db->insert('tms_users_pers', $tms_users_pers_data);                        
            $internal_user_role_data = array(
                'tenant_id' => $tenant_id,                  
                'user_id' => $user_id,                  
                'role_id' => 'COMPACT'
            );
            $this->db->insert('internal_user_role', $internal_user_role_data);            
            $tenant_Comp_users=array(
                    'company_id'=>$comp_id,
                    'tenant_id'=>$tenant_id,
                    'user_id'=>$user_id,
                    'user_acct_status' => $activate_company,
                    'assigned_by' => $user->user_id,
                    'assigned_on' => $curr_date_time,
                    'last_modified_by' => $user->user_id,
                    'last_modified_on' => $curr_date_time,                
            );
            if($activate_company == 'ACTIVE') {
                $tenant_Comp_users['acct_acti_date_time'] = $acct_activation_date_time;
            }
            //Inserting into tms_users, tms_users_pers, tenant_company_users 
            $insert_result = $this->db->insert('tenant_company_users', $tenant_Comp_users);
            //Check if account creation mail needs to be sent - Bineesh Aug 23 2014
            if($activate_company == 'ACTIVE' && $insert_result) {
                //Send mail with Username and password.
                $user_details = array('username' => $username[$i], 
                        'email' => $email_01[$i], 'password' => $password,
                        'firstname' => $fname[$i],'lastname' => $lname[$i],
                        'gender' => $gender[$i]);
                $this->compnay_user_send_mail($user_details);
                
            }            
        }
        $this->db->trans_complete(); 
        if ($this->db->trans_status() === FALSE) {
            $this->session->set_flashdata('company_db_error', 'Oops! Sorry, it looks like something went wrong and an error has occurred');
            redirect('company');
        } 
        
        return;
    }
    /**
     * send mail to the company user containing password
     * @param array $user
     * Author: Bineesh
     * Date : 23 Aug 2014.
     * return boolean.
     */
    public function compnay_user_send_mail($user_details) {        
        if ($user_details['username'] && $user_details['password'] && $user_details['email']) {
            $user = $this->session->userdata('userDetails');
            $tenant_details=fetch_tenant_details($user->tenant_id);
            
            $footer_data=str_replace("<Tenant_Company_Name>", $tenant_details->tenant_name, MAIL_FOOTER);        
            $subject = 'Your Account Creation Acknowledgment'; 
            $body = NULL;
            if ($user_details['gender'] == 'MALE'){
                $body ="Dear Mr.".$user_details['firstname'].' '.$user_details['lastname'].',';
            }else{
                $body ="Dear Ms.".$user_details['firstname'].' '.$user_details['lastname'].',';            
            }                  
            $body .=  '<br/><br/>&nbsp;&nbsp;Thank you for registering with us. Your account has been successfully created.<br/><br/>';
            $body .= "<strong>&nbsp;&nbsp;Your username:</strong> ". $user_details['username'] ."<br/>";
            $body .= "<strong>&nbsp;&nbsp;Your password:</strong> ". $user_details['password']."<br/><br/>";
            $body .= $footer_data;            
            return send_mail($user_details['email'], '', $subject, $body);            
        }        
        return FALSE;
    }
    
    
    /*
     * This function will check the username exists on the db or not. (Add company)
     */
    public function check_username($user_name)
    {
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('user_name', $user_name);
        $query = $this->db->get();
        return $query->num_rows();   
    }
    
    
    
    /*
     * This function will check the username exists on the db or not. (Edit company)
     */
    public function check_username_edit($user_name, $curr_user_name)
    {
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('user_name', $user_name);
        $this->db->where('user_name !=', $curr_user_name);
        $query = $this->db->get();
        
        return $query->num_rows();   
    }    
       

    /*
     * This function will check the email id exists on the db or not. (Add company)
     */
    public function check_email($email_id)
    {
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('registered_email_id', $email_id);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    
    /*
     * This function will check the email id exists on the db or not. (Edit company)
     */
    public function check_email_edit($email_id, $curr_email_id)
    {
        $this->db->select('user_id');
        $this->db->from('tms_users');
        $this->db->where('registered_email_id', $email_id);
        $this->db->where('registered_email_id !=', $curr_email_id);
        $query = $this->db->get();
      
        return $query->num_rows();
    }    
    
    
    /*
     * This function will check the registration number exists on the db or not. (ADD Company)
     */
    public function check_registration_number($reg_num)
    {
        $this->db->select('company_id');
        $this->db->from('company_master');
        $this->db->where('comp_regist_num', $reg_num);
        $query = $this->db->get();

        return $query->num_rows();
    }    
    
    /*
     * This function will check the registration number exists on the db or not. (Edit Company)
     */
    public function check_registration_number_edit($reg_num, $curr_reg_num)
    {
        $this->db->select('company_id');
        $this->db->from('company_master');
        $this->db->where('comp_regist_num', $reg_num);
        $this->db->where('comp_regist_num !=', $curr_reg_num);
        $query = $this->db->get();

        return $query->num_rows();
    }     


    /*
     * This method gets the company details
     * @param - Company Id
     * @param - Tenant Id
     */    
    public function get_company_users($tenant_id, $company_id){
        if ( (empty($tenant_id)) && (empty($company_id)) ) {
            return 0;
        }
        
        $this->db->select('tecomusr.user_id');
        $this->db->from('tenant_company_users tecomusr');
        
        $this->db->join('tms_users usr', 'usr.user_id = tecomusr.user_id');
        $this->db->where('usr.account_type', 'COMUSR');
        
        /*$this->db->join('tms_users_pers pers', 'pers.user_id = tecomusr.user_id');
        */
                
        $this->db->where('tecomusr.tenant_id', $tenant_id);
        $this->db->where('tecomusr.company_id', $company_id);
        //$this->db->where('tecomusr.user_acct_status', 'ACTIVE');
        
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $comp_user_deatails = array();
            foreach ($query->result() as $row)
            {
                $comp_user_deatails[] = $row->user_id;
                //$comp_user_deatails[] = $row;
            }
        }
        return $comp_user_deatails;
    }
    

    /*
     * This method gets the company details
     * @param - Company Id
     */
    
    public function get_company_users_details($tenant_id, $company_id){
        $this->db->select('usr.user_id,usr.registered_email_id,usr.user_name,usr.account_type, tecomusr.user_acct_status, pers.first_name, pers.last_name, pers.gender, pers.contact_number, pers.alternate_contact_number, pers.alternate_email_id');
        $this->db->from('tenant_company_users tecomusr');
        $this->db->join('tms_users_pers pers', 'pers.user_id = tecomusr.user_id');
        $this->db->join('tms_users usr', 'usr.user_id = tecomusr.user_id');
        $this->db->where('usr.account_type', 'COMUSR');
        $this->db->where('tecomusr.tenant_id', $tenant_id);
        $this->db->where('tecomusr.company_id', $company_id);
        
        $query = $this->db->get();

        if ($query->num_rows() > 0){
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }
        }
        
        return $data;
    }
    

    
    /*
     * This method gets the company details
     * @param - Company Id, Tenant Id
     * Tables used: company_master, tenant_company, tms_users, tms_users_persa and tenant_company_users
     */
    public function get_company_details($tenant_id, $company_id){
        
        $this->db->select('*');
        $this->db->from('tenant_company company');
        $this->db->join('company_master companymaster', 'company.company_id = companymaster.company_id');
        $this->db->where('company.tenant_id', $tenant_id);
        $this->db->where('company.company_id', $company_id);
        
        $qry = $this->db->get();
        
        if($qry->num_rows()>0){
            $comp_details = array();
            foreach ($qry->result() as $row)
            {
                $comp_details[] = $row;
            }
        }
        return $comp_details;
    }
    
    
   public function internal_company_list_autocomplete($name_startsWith) {
        //$name_startsWith = $this->input->get('name_startsWith');
        $results = array();
        if (!empty($name_startsWith)) {
            $this->db->select('cm.company_id, cm.company_name');
            $this->db->from('company_master cm');
            $this->db->join('tenant_company tc','tc.company_id=cm.company_id');            
            $this->db->where('tc.tenant_id', $this->session->userdata('userDetails')->tenant_id);
            $this->db->like('cm.company_name', $name_startsWith, 'both');
            $results = $this->db->get()->result();            
           
        }
        
        return $results;        
    }
    
    
   public function internal_company_trainee_list_autocomplete($name_startsWith) {
        //$name_startsWith = $this->input->get('name_startsWith');
        $name = explode(' ', $name_startsWith);
        $results = array();
        if (!empty($name_startsWith)) {
            $this->db->select('tup.user_id, tup.first_name, tup.last_name');
            $this->db->from('tms_users tu');
            $this->db->join('tms_users_pers tup','tup.user_id=tu.user_id');            
            $this->db->where('tup.tenant_id', $this->session->userdata('userDetails')->tenant_id);
            $this->db->where('tu.account_type', 'TRAINE');
            $this->db->like('tup.first_name', $name[0], 'both');
            $this->db->like('tup.last_name', $name[1], 'both');
            $results = $this->db->get()->result();
        }
        return $results;        
    }
    
    

   public function internal_company_trainee_taxcode_autocomplete($name_startsWith) {
        //$name_startsWith = $this->input->get('name_startsWith');
        $results = array();
        if (!empty($name_startsWith)) {
            $this->db->select('tu.tax_code');
            $this->db->from('tms_users tu');
            $this->db->join('tms_users_pers tup','tup.user_id=tu.user_id');            
            $this->db->where('tup.tenant_id', $this->session->userdata('userDetails')->tenant_id);
            $this->db->where('tu.account_type', 'TRAINE');
            $this->db->like('tu.tax_code', $name_startsWith, 'both');
            $results = $this->db->get()->result();
        }
        return $results;        
    }    
    
    
    
    /*
     * Author : JAISON
     * This function is used to get the number of registered users based on tenant id and company id
     */
    public function get_company_registered_trainees_num($tenant_id, $company_id) {   
        $this->db->select('COUNT(*) AS registered_trainees_num');
        $this->db->from('tenant_company_users tcu');
        $this->db->join('tms_users tu', 'tu.user_id=tcu.user_id');
        $this->db->where('tcu.tenant_id', $tenant_id);
        $this->db->where('tcu.company_id', $company_id);
        $this->db->where('tu.account_type', 'TRAINE');
        
        $result = $this->db->get()->result();
     
        return $result[0]->registered_trainees_num;
    }
 
    
    /*
     * Author : JAISON
     * This function is used to get the number of active users based on tenant id and company id
     */
    public function get_company_active_trainees_num($tenant_id, $company_id) {
        $this->db->select('COUNT(*) AS active_trainees_num');
        $this->db->from('tenant_company_users tcu');
        $this->db->join('tms_users tu', 'tu.user_id=tcu.user_id');
        $this->db->where('tcu.tenant_id', $tenant_id);
        $this->db->where('tcu.company_id', $company_id);
        $this->db->where('tu.account_type', 'TRAINE');
        $this->db->where('tu.account_status', 'ACTIVE');
        
        $result = $this->db->get()->result();
        
        return $result[0]->active_trainees_num;    
    }  
    
    
    
    /*
     * Author: JAISON
     * Function used to update company datas
     * Tables used: company_master, tenant_company, tms_users, tms_users_persa and tenant_company_users
     */
    public function update_company_details($company_id) {
        $user = $this->session->userdata('userDetails');
        //$tenant_id = $user->tenant_id;
        
        $tenant_id = $user->tenant_id;
        extract($_POST);
            
        $curr_date_time = date('Y-m-d H:i:s');
        $acct_activation_date_time = '0000-00-00 00:00:00';
        if($activate_company == 'ACTIVE') {
            $acct_activation_date_time = $curr_date_time;
        }
        
                
        //Updating company_master starts here
        $companydata = array(
            'company_name' => $company_name,
            'comp_regist_num' => $regno,
            'business_type' => $business_type,
            'business_size' => $business_s,
            'comp_phone' => $phoneno,
            'comp_fax' => $faxno,
            'comp_address' => $street,
            'comp_city' => $city,
            'comp_state' => $pers_states,            
            'comp_cntry' => $company_country,
            'comp_zip' => $zipcode,
            'remarks' => $comments,
            'last_modified_by' => $user->user_id,
            'last_modified_on' => $curr_date_time,
            'comp_scn' => $comp_scn,
            'comp_cntry_scn' => $country_of_residence
        );
        if($activate_company == 'ACTIVE' || $activate_company == 'PENDACT') {
             $companydata['company_status'] = $activate_company;
        }        
        if($activate_company == 'ACTIVE') {
            $companydata['acct_activation_date_time'] = $acct_activation_date_time;
        } 
        $this->db->trans_start();
        $this->db->where('company_id', $company_id);
        $this->db->update('company_master', $companydata);
        
        //Updating company_master ends here

        //Updating tenant_company starts here
        
        $tenantcompany = array(
            'comp_discount' => $localdiscount,
            'comp_frgn_discnt' => $foreigndiscount,
            'last_modified_by' => $user->user_id,
            'last_modified_on' => $curr_date_time,
        );
        if($activate_company == 'ACTIVE' || $activate_company == 'PENDACT') {
             $tenantcompany['comp_status'] = $activate_company;
        }        
        if($activate_company == 'ACTIVE') {
            $tenantcompany['acct_acti_date_time'] = $acct_activation_date_time;
        }     
        $this->db->where('tenant_id', $tenant_id);
        $this->db->where('company_id', $company_id);
        $this->db->update('tenant_company', $tenantcompany);
        //Updating tenant_company ends here

        //Updating tms_users, tms_users_pers, tenant_company_users starts here  
        $account_type = 'COMUSR';                 
        $registration_date = $curr_date_time;
        $registration_mode = 'INTUSR';
        $tenant_org_id = 1; // ??
        
        $acc_activation_type = 'BPEMAC';
        
        for ($i = 0; $i < count($username); $i++) {
            if($username_userids[$i] != '') {    
                $tms_users_data = array(
                    'tenant_org_id' => $tenant_org_id,
                    'registered_email_id' => $email_01[$i],
                    'country_of_residence' => $country_of_residence,
                    'last_modified_by' => $user->user_id,
                    'last_modified_on' => $curr_date_time,
                );
                if($activate_company == 'ACTIVE' || $activate_company == 'PENDACT') {
                     $tenantcompany['account_status'] = $activate_company;
                }              
                if($activate_company == 'ACTIVE') {
                    $tms_users_data['acct_acti_date_time'] = $acct_activation_date_time;
                } 
                
                //generateEncryptedPwd if acount is active - Added by Bineesh Aug 23 2014 - Existing Users
                $encrypted_password = NULL;
                $password = NULL;
                if($activate_company == 'ACTIVE' && $username_status[$i] == ''){  // Was pending activation has now been changed to ACTIVE              
                    $password = random_key_generation();
                    $encrypted_password = $this->bcrypt->hash_password($password);
                    $tms_users_data['password'] =  $encrypted_password;  // setting password for the user 
                }
                
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('user_id', $username_userids[$i]);
                $this->db->update('tms_users', $tms_users_data);        
                //Updating tms_users ends here

                $tms_users_pers_data = array(
                    'first_name' => $fname[$i],
                    'last_name' => $lname[$i],
                    'gender' => $gender[$i],
                    'contact_number' => $contactno[$i],
                    'alternate_contact_number' => $mobileno[$i],
                    'alternate_email_id' => $email_02[$i],
                );
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('user_id', $username_userids[$i]);
                $this->db->update('tms_users_pers', $tms_users_pers_data);


                $tenant_Comp_users=array(
                        'user_acct_status' => $activate_company,
                        'last_modified_by' => $user->user_id,
                        'last_modified_on' => $curr_date_time,                
                );
                if($activate_company == 'ACTIVE' || $activate_company == 'PENDACT') {
                     $tenant_Comp_users['user_acct_status'] = $activate_company;
                }            
                if($activate_company == 'ACTIVE') {
                    $tenant_Comp_users['acct_acti_date_time'] = $acct_activation_date_time;
                }
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('user_id', $username_userids[$i]);
                $this->db->where('company_id', $company_id);
                $this->db->update('tenant_company_users', $tenant_Comp_users);
                //Added by Bineesh - Aug 23 2014
                if($activate_company == 'ACTIVE' && $username_status[$i] == ''){   // Was pending activation has now been changed to ACTIVE
                        //Send mail with Username and password.
                        $user_details = array('username' => $username[$i], 
                                'email' => $email_01[$i], 'password' => $password,
                                'firstname' => $fname[$i],'lastname' => $lname[$i],
                                'gender' => $gender[$i]);
                        $this->compnay_user_send_mail($user_details);
                }
            }
        }
        //Updating tms_users, tms_users_pers, tenant_company_users ends here
        
        //Inserting new users
        for ($i = 0; $i < count($username); $i++) {
            if($username_userids[$i] == '') {
                $tms_users_data = array(
                    'tenant_id' => $tenant_id,                
                    'account_type' => $account_type,
                    'registration_mode' => $registration_mode,
                    'tenant_org_id' => $tenant_org_id,                    
                    'registration_date' => $registration_date,
                    'user_name' => $username[$i],
                    'registered_email_id' => $email_01[$i],
                    'country_of_residence' => $country_of_residence,
                    'account_status' => $activate_company,
                    'created_by' => $user->user_id,
                    'created_on' => $curr_date_time,
                    'last_modified_by' => $user->user_id,
                    'last_modified_on' => $curr_date_time,
                );
                if($activate_company == 'ACTIVE') {
                    $tms_users_data['acct_acti_date_time'] = $acct_activation_date_time;
                }
                //generateEncryptedPwd if acount is active - Added by Bineesh Aug 23 2014 - New Users
                $encrypted_password = NULL;
                if($activate_company == 'ACTIVE' && $username_status[$i] == ''){   // Was pending activation has now been changed to ACTIVE              
                    $password = random_key_generation();
                    $encrypted_password = $this->bcrypt->hash_password($password);
                    $tms_users_data['password'] = $encrypted_password;  // setting password for the user 
                }
                
                $this->db->insert('tms_users', $tms_users_data);        
                //Inserting into tms_users ends here
                $user_id = mysql_insert_id();

                $tms_users_pers_data = array(
                    'tenant_id' => $tenant_id,                  
                    'user_id' => $user_id,                  
                    'first_name' => $fname[$i],
                    'last_name' => $lname[$i],
                    'gender' => $gender[$i],
                    'contact_number' => $contactno[$i],
                    'alternate_contact_number' => $mobileno[$i],
                    'alternate_email_id' => $email_02[$i],
                );
                $this->db->insert('tms_users_pers', $tms_users_pers_data);


                $internal_user_role_data = array(
                    'tenant_id' => $tenant_id,                  
                    'user_id' => $user_id,                  
                    'role_id' => 'COMPACT'
                );
                $this->db->insert('internal_user_role', $internal_user_role_data);


                $tenant_Comp_users=array(
                        'company_id'=>$company_id,
                        'tenant_id'=>$tenant_id,
                        'user_id'=>$user_id,
                        'user_acct_status' => $activate_company,
                        'assigned_by' => $user->user_id,
                        'assigned_on' => $curr_date_time,
                        'last_modified_by' => $user->user_id,
                        'last_modified_on' => $curr_date_time,                
                );
                if($activate_company == 'ACTIVE') {
                    $tenant_Comp_users['acct_acti_date_time'] = $acct_activation_date_time;
                }
                $this->db->insert('tenant_company_users', $tenant_Comp_users);
                
                //Added by Bineesh - Aug 23 2014
                if($activate_company == 'ACTIVE' && $username_status[$i] == ''){   // Was pending activation has now been changed to ACTIVE
                        //Send mail with Username and password.
                        $user_details = array('username' => $username[$i], 
                                'email' => $email_01[$i], 'password' => $password,
                                'firstname' => $fname[$i],'lastname' => $lname[$i],
                                'gender' => $gender[$i]);
                        $this->compnay_user_send_mail($user_details);
                }
                
            }
        }
        $this->db->trans_complete(); 
        if ($this->db->trans_status() === FALSE) {
            $this->session->set_flashdata('company_db_error', 'Oops! Sorry, it looks like something went wrong and an error has occurred');
            redirect('company');
        } 

        return;
    }
    
    
    public function deactivate_company_contact($tenant_id, $company_id, $deactivate_user_id, $deactivate_reason, $deactivate_other_reason) {       
                $user = $this->session->userdata('userDetails');
                $curr_date_time = date('Y-m-d H:i:s');
                
                $tms_users_deactivate_data = array(
                    'account_status' => 'INACTIV',
                    'deacti_by' => $user->user_id,
                    'deacti_reason' => $deactivate_reason,
                    'acct_deacti_date_time' => $curr_date_time
                );
                if($deactivate_reason == 'OTHERS') {
                     $tms_users_deactivate_data['deacti_reason_oth'] = $deactivate_other_reason;
                }              
                $this->db->trans_start();
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('user_id', $deactivate_user_id);
                $this->db->update('tms_users', $tms_users_deactivate_data); 
                
                $tenant_comp_users_deactivate=array(
                        'user_acct_status' => 'INACTIV',
                        'deacti_by' => $user->user_id,
                        'acct_deacti_date_time' => $curr_date_time,
                        'deacti_reason' => $deactivate_reason,
                );
                if($deactivate_reason == 'OTHERS') {
                    $tenant_comp_users_deactivate['deacti_reason_oth'] = $deactivate_other_reason;
                }
                $this->db->where('company_id', $company_id);                
                $this->db->where('tenant_id', $tenant_id);
                $this->db->where('user_id', $deactivate_user_id);
                $this->db->update('tenant_company_users', $tenant_comp_users_deactivate);  
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    $this->session->set_flashdata('company_db_error', 'Oops! Sorry, it looks like something went wrong and an error has occurred');
                    redirect('company');
                } 
                
    }
    
    public function company_deactivate($tenant_id, $company_id, $reason_for_deactivation, $other_reason_for_deactivation) {
        $user = $this->session->userdata('userDetails');
        $logged_in_user_id = $user->user_id;
        $deactivation_date = date('Y-m-d H:i:s');
        
        if($reason_for_deactivation != 'OTHERS') {
            $other_reason_for_deactivation = '';
        }
        
        /*
        $company_master_deactivate = array(
            'company_status' => 'INACTIV',
            'acct_deactivation_date_time' => $deactivation_date,
            'deactivated_by' => $logged_in_user_id,
            'deactivation_reason' => $reason_for_deactivation,
            //'deactivation_reason_other' => $other_reason_for_deactivation
        );
        $this->db->where('company_id', $company_id);                
        $this->db->update('company_master', $company_master_deactivate);
        */
        
        $tenant_company_deactivate = array(
            'comp_status' => 'INACTIV',
            'acct_deacti_date_time' => $deactivation_date,
            'deacti_reason' => $reason_for_deactivation,
            'deacti_by' => $logged_in_user_id,
            'deacti_reason_oth' => $other_reason_for_deactivation
        );
        $this->db->trans_start();
        $this->db->where('tenant_id', $tenant_id); 
        $this->db->where('company_id', $company_id);                
        $this->db->update('tenant_company', $tenant_company_deactivate);        
          
        $tenant_company_users_deactivate = array(
            'user_acct_status' => 'INACTIV',
            'acct_deacti_date_time' => $deactivation_date,
            //'deacti_reason' => $reason_for_deactivation,
            //'deacti_by' => $logged_in_user_id,
            //'deacti_reason_oth' => $other_reason_for_deactivation
        );
        $this->db->where('tenant_id', $tenant_id); 
        $this->db->where('company_id', $company_id);                
        $this->db->update('tenant_company_users', $tenant_company_users_deactivate); 
        
        $sql = "UPDATE tms_users tu, tenant_company_users tcu  
                SET tu.account_status='INACTIV'  
                WHERE  tcu.tenant_id='$tenant_id' 
                AND tcu.company_id='$company_id' 
                AND tu.user_id=tcu.user_id";
        /*
, 
                tu.acct_deacti_date_time='$deactivation_date',
                tu.deacti_reason = '$reason_for_deactivation',
                tu.deacti_reason_oth = '$other_reason_for_deactivation',
                tu.deacti_by='$logged_in_user_id'         
         */
        $this->db->query($sql); 
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE) {
            $this->session->set_flashdata('company_db_error', 'Oops! Sorry, it looks like something went wrong and an error has occurred');
            redirect('company');
        } 
    }
    
    
    
        /*
        * Author : JAISON
        * To get company trainees count
        */
            public function get_company_trainees_count($tenant_id, $company_id)
            {

                if (empty($tenant_id)) {
                    return 0;
                }
                $this->db->select('count(*) as totalrows');
                $this->db->from('tenant_company_users tcu');
                $this->db->join('tms_users tu', "tu.user_id=tcu.user_id AND tu.account_type='TRAINE'");
                $this->db->join('tms_users_pers tup', "tup.user_id=tu.user_id");
                $this->db->where('tcu.tenant_id', $tenant_id);
                $this->db->where('tcu.company_id', $company_id);

                //Search Part - Starts
                $search_company_trainee_name = $this->input->post('search_company_trainee_name');
                $search_company_trainee_taxcode = $this->input->post('search_company_trainee_taxcode');
                    if($search_company_trainee_name != ''){
                        $this->db->like('tup.first_name', $search_company_trainee_name);
                    }
                    if($search_company_trainee_taxcode != ''){
                        $this->db->like('tu.tax_code', $search_company_trainee_taxcode);
                    }                
                //Search Part - Ends  


                $result = $this->db->get()->result();

                return $result[0]->totalrows;        
            }


        /*
        * Author : JAISON
        * To get company trainees list
        */
            public function get_company_trainees_list($tenant_id, $company_id, $limit, $offset, $sort_by, $sort_order, $gettotal=NULL) {

                if ($offset <= 0 || empty($tenant_id)) {
                    return;
                }

                $this->db->select('tu.user_id, DATE(tu.acct_acti_date_time) AS acct_acti_date_time, DATE(tu.registration_date) AS registration_date, tu.acc_activation_type, tup.first_name, tup.last_name, tu.country_of_residence, tu.tax_code, tup.dob');
                $this->db->from('tenant_company_users tcu');
                $this->db->join('tms_users tu', "tu.user_id=tcu.user_id AND tu.account_type='TRAINE'");
                $this->db->join('tms_users_pers tup', "tup.user_id=tu.user_id");
                $this->db->where('tcu.tenant_id', $tenant_id);
                $this->db->where('tcu.company_id', $company_id);        

                //Search Part - Starts
                $search_company_trainee_name = $this->input->post('search_company_trainee_name');
                $search_company_trainee_name_arr = explode(' ', $search_company_trainee_name);
                $search_company_trainee_taxcode = $this->input->post('search_company_trainee_taxcode');
                    if($search_company_trainee_name != ''){
                        $this->db->like('tup.first_name', $search_company_trainee_name_arr[0]);
                        $this->db->like('tup.last_name', $search_company_trainee_name_arr[1]);
                    }
                    if($search_company_trainee_taxcode != ''){
                        $this->db->like('tu.tax_code', $search_company_trainee_taxcode);
                    }                
                //Search Part - Ends  


                if($sort_by) {  
                   $this->db->order_by($sort_by, $sort_order);  
                }else {
                   $this->db->order_by('tu.last_modified_on', 'DESC'); 
                }

                if ($limit == $offset) {
                    $this->db->limit($offset); 
                }
                else if($limit > 0) {
                    $limitvalue = $offset - $limit;
                    $this->db->limit($limit, $limitvalue);  
                }
                $query = $this->db->get();
               

                return $query->result_array();        
            }    
        
 }  