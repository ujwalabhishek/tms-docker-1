<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Meta_Values extends CI_Model {

    const COUNTRIES = 'CAT05';
    const USER_ROLES = 'CAT09';
    const GENDER = 'CAT11';
    const BUSINESS_TYPE = 'CAT13';
    const BUSINESS_SIZE = 'CAT17';
    const LANGUAGE = 'CAT23';
    const LOCATION = 'CAT25'; ### ADDED BY SANKAR TO GET LOCATION DETAILS IN ADD NEW CLASS
    const CLASS_STATUS = 'CAT15'; ### ADDED BY SANKAR TO GET CLASS STATUS DETAILS IN CLASS lIST
    const COPY_REASON = 'CAT30'; ### ADDED BY SANKAR TO GET CLASS COPY REASONS IN CLASS
    const RESCH_REASON = 'CAT37'; ### ADDED BY SANKAR TO GET CLASS COPY REASONS IN CLASS
    const REFUND_REASON = 'CAT40'; ### ADDED BY SANKAR TO GET CLASS COPY REASONS IN CLASS
    const COURSE_TYPE = 'CAT22';
    const CLASS_TYPE = 'CAT24';
    const RACE = 'CAT12';
    const SAL_RANGE = 'CAT18';
    const EMAIL_ACT = 'CAT04';
    const EDU_LEVEL = 'CAT19';
    const DESIGNATION = 'CAT20';
    const DESIGNATIONS = 'CAT20';
    const STATUS = 'CAT02';
    const DEACTIVATE_REASONS = 'CAT08';
    const NOTIFICATION_TYPES = 'CAT28'; //Notification Types
    const BROADCAST_USER_TYPES = 'CAT28_01'; //Broadcast User Type
//added by Bineesh for sertification code and copy reason
    const CERTIFICATE_CODE = 'CAT29'; 
    const COPY_REASONS = 'CAT30'; 
    const COMPANY_DEACTIVATE_REASONS = 'CAT35';
    const NRIC = 'CAT16';
    const NRIC_OTHER = 'CAT07';
    /**
     * function to get the information about the categories
     * @param array() $category_list
     * @param varchar $category_id
     *
     * @return array meta_data information of all the categories
     */

    public function get_metavalues($category_list = array(), $category_id = NULL) {
        $category_name = '';
        $meta_data = array();
        if (empty($category_list) && empty($category_id)) {
            return array();
        } else if (empty($category_list) && $category_id) {
            $category_list = array($category_id);
            $category_name = 'result';
        }
        $this->db->select('category_id, child_category_id, parameter_id,
                        category_name, description');
        $this->db->from('metadata_values');
        $this->db->where_in('category_id', $category_list);
        $query = $this->db->get();
        if (!$category_name) {
            $category_name = $this->get_main_category_name($category_id);
        }
        foreach ($query->result() as $row) {
            $meta_data[$row->parameter_id] = array('parameter_id' => $row->parameter_id,
                'child_category_id' => $row->child_category_id,
                'category_id' => $row->category_id,
                'category_name' => $row->category_name,
                'description' => $row->description);
        }

        return $meta_data;
    }

    /**
     * fetch the child category from the parent category
     * @param varchar $category_id
     *
     * @return varchar child_category_id
     */
    public function fetch_child_category_by_category_id($category_id = NULL) {
        if (empty($category_id)) {
            return NULL;
        }
        $this->db->select('child_category_id, category_name');
        $this->db->from('metadata_values');
        $this->db->where('category_id', $category_id);
        $this->db->limit(1);
        $query = $this->db->get();
        $result = $query->result();
        $child_category_id = NULL;
        if ($result) {
            $child_category_id = $result[0]->child_category_id;
        }
        return $child_category_id;
    }

    /**
     * get the name of the category
     * @param int category_id
     * 
     * return string category_name
     */
    public function get_main_category_name($category_id = NULL) {
        if (empty($category_id)) {
            return NULL;
        }
        $this->db = $this->load->database('default', TRUE);
        $this->db->select('category_name');
        $this->db->from('metadata_values');
        $this->db->where('category_id', $category_id);
        $this->db->limit(1);
        $query = $this->db->get();
        $result = $query->result();
        $category_name = NULL;
        if ($result) {
            $category_name = $result[0]->category_name;
        }
        return $category_name;
    }

//Ukraine Code
    /**
     * get all meta values as map
     */
    public function get_param_map() {
        $query = $this->db->select('category_name, parameter_id')->get('metadata_values');
        $result = array();
        foreach ($query->result() as $row) {
            if (!empty($row->parameter_id)) {
                $result[$row->parameter_id] = $row->category_name;
            }
        }
        return $result;
    }

}
