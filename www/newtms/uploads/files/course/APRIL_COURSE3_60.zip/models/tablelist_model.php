<?php 
class Tablelist_Model extends CI_Model {

    var $title   = '';
    var $content = '';
    var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

   public function record_count($table){

        $query = $this->db->query($table);
        return $total_result =  $query->num_rows();       
//        $total_result = $this->db->count_all_results($table);
    }
    
   // public function get_table($table, $limit, $start, $sort_by, $sort_order)
    public function get_table($table, $limit, $offset, $sort_by, $sort_order)
                {

                    $limitstart = $offset - $limit;
                     $query = $table;
                  if($sort_by) {  
                         $query .= ' ORDER BY '.$sort_by; 
                         $query .= ' '.$sort_order;
                     }                 
                   if($limit > 1){
                       $limitvalue = $offset - $limit;
                 $query .= ' LIMIT '.$limitvalue;
                   }
                   if($offset)
                 $query .= ', '.$limit;   
                  // echo $query;
                   return $this->db->query($query);

        }
}